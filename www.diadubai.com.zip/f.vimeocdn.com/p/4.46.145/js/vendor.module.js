/* VimeoPlayer - v4.46.145 - 2026-11-09 - https://player.vimeo.com/NOTICE.txt */

! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : {},
            n = (new e.Error).stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "513f0d98-cddc-5210-b652-1b17a142037f")
    } catch (e) {}
}();
var e = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};

function t(e, t, r) {
    return e(r = {
        path: t,
        exports: {},
        require: function(e, t) {
            return function() {
                throw new Error("Dynamic requires are not currently supported by @rollup/plugin-commonjs")
            }(null == t && r.path)
        }
    }, r.exports), r.exports
}

function r(e) {
    return e && e.default || e
}
var n, o, i = function(e) {
        return e && e.Math === Math && e
    },
    a = i("object" == typeof globalThis && globalThis) || i("object" == typeof window && window) || i("object" == typeof self && self) || i("object" == typeof e && e) || i("object" == typeof e && e) || function() {
        return this
    }() || Function("return this")(),
    u = a,
    s = function(e) {
        try {
            return !!e()
        } catch (e) {
            return !0
        }
    },
    c = !s(function() {
        var e = function() {}.bind();
        return "function" != typeof e || e.hasOwnProperty("prototype")
    }),
    f = Function.prototype,
    l = f.call,
    d = c && f.bind.bind(l, l),
    h = c ? d : function(e) {
        return function() {
            return l.apply(e, arguments)
        }
    },
    p = function(e) {
        return null == e
    },
    v = TypeError,
    y = function(e) {
        if (p(e)) throw new v("Can't call method on " + e);
        return e
    },
    g = Object,
    b = function(e) {
        return g(y(e))
    },
    m = h({}.hasOwnProperty),
    w = Object.hasOwn || function(e, t) {
        return m(b(e), t)
    },
    E = !1,
    _ = Object.defineProperty,
    T = function(e, t) {
        try {
            _(a, e, {
                value: t,
                configurable: !0,
                writable: !0
            })
        } catch (r) {
            a[e] = t
        }
        return t
    },
    S = t(function(e) {
        var t = "__core-js_shared__",
            r = e.exports = a[t] || T(t, {});
        (r.versions || (r.versions = [])).push({
            version: "3.47.0",
            mode: "global",
            copyright: "© 2014-2025 Denis Pushkarev (zloirock.ru), 2025 CoreJS Company (core-js.io)",
            license: "https://github.com/zloirock/core-js/blob/v3.47.0/LICENSE",
            source: "https://github.com/zloirock/core-js"
        })
    }),
    A = function(e, t) {
        return S[e] || (S[e] = t || {})
    },
    I = 0,
    O = Math.random(),
    R = h(1.1.toString),
    N = function(e) {
        return "Symbol(" + (void 0 === e ? "" : e) + ")_" + R(++I + O, 36)
    },
    P = a.navigator,
    M = P && P.userAgent,
    D = M ? String(M) : "",
    x = a.process,
    C = a.Deno,
    k = x && x.versions || C && C.version,
    L = k && k.v8;
L && (o = (n = L.split("."))[0] > 0 && n[0] < 4 ? 1 : +(n[0] + n[1])), !o && D && (!(n = D.match(/Edge\/(\d+)/)) || n[1] >= 74) && (n = D.match(/Chrome\/(\d+)/)) && (o = +n[1]);
var j = o,
    X = a.String,
    U = !!Object.getOwnPropertySymbols && !s(function() {
        var e = Symbol("symbol detection");
        return !X(e) || !(Object(e) instanceof Symbol) || !Symbol.sham && j && j < 41
    }),
    B = U && !Symbol.sham && "symbol" == typeof Symbol.iterator,
    F = a.Symbol,
    V = A("wks"),
    z = B ? F.for || F : F && F.withoutSetter || N,
    H = function(e) {
        return w(V, e) || (V[e] = U && w(F, e) ? F[e] : z("Symbol." + e)), V[e]
    },
    W = H,
    Y = !s(function() {
        return 7 !== Object.defineProperty({}, 1, {
            get: function() {
                return 7
            }
        })[1]
    }),
    G = "object" == typeof document && document.all,
    K = void 0 === G && void 0 !== G ? function(e) {
        return "function" == typeof e || e === G
    } : function(e) {
        return "function" == typeof e
    },
    q = function(e) {
        return "object" == typeof e ? null !== e : K(e)
    },
    $ = a.document,
    Q = q($) && q($.createElement),
    J = function(e) {
        return Q ? $.createElement(e) : {}
    },
    Z = !Y && !s(function() {
        return 7 !== Object.defineProperty(J("div"), "a", {
            get: function() {
                return 7
            }
        }).a
    }),
    ee = Y && s(function() {
        return 42 !== Object.defineProperty(function() {}, "prototype", {
            value: 42,
            writable: !1
        }).prototype
    }),
    te = String,
    re = TypeError,
    ne = function(e) {
        if (q(e)) return e;
        throw new re(te(e) + " is not an object")
    },
    oe = Function.prototype.call,
    ie = c ? oe.bind(oe) : function() {
        return oe.apply(oe, arguments)
    },
    ae = function(e, t) {
        return arguments.length < 2 ? function(e) {
            return K(e) ? e : void 0
        }(a[e]) : a[e] && a[e][t]
    },
    ue = h({}.isPrototypeOf),
    se = Object,
    ce = B ? function(e) {
        return "symbol" == typeof e
    } : function(e) {
        var t = ae("Symbol");
        return K(t) && ue(t.prototype, se(e))
    },
    fe = String,
    le = function(e) {
        try {
            return fe(e)
        } catch (e) {
            return "Object"
        }
    },
    de = TypeError,
    he = function(e) {
        if (K(e)) return e;
        throw new de(le(e) + " is not a function")
    },
    pe = function(e, t) {
        var r = e[t];
        return p(r) ? void 0 : he(r)
    },
    ve = TypeError,
    ye = TypeError,
    ge = H("toPrimitive"),
    be = function(e, t) {
        if (!q(e) || ce(e)) return e;
        var r, n = pe(e, ge);
        if (n) {
            if (void 0 === t && (t = "default"), r = ie(n, e, t), !q(r) || ce(r)) return r;
            throw new ye("Can't convert object to primitive value")
        }
        return void 0 === t && (t = "number"),
            function(e, t) {
                var r, n;
                if ("string" === t && K(r = e.toString) && !q(n = ie(r, e))) return n;
                if (K(r = e.valueOf) && !q(n = ie(r, e))) return n;
                if ("string" !== t && K(r = e.toString) && !q(n = ie(r, e))) return n;
                throw new ve("Can't convert object to primitive value")
            }(e, t)
    },
    me = function(e) {
        var t = be(e, "string");
        return ce(t) ? t : t + ""
    },
    we = TypeError,
    Ee = Object.defineProperty,
    _e = Object.getOwnPropertyDescriptor,
    Te = "enumerable",
    Se = "configurable",
    Ae = "writable",
    Ie = Y ? ee ? function(e, t, r) {
        if (ne(e), t = me(t), ne(r), "function" == typeof e && "prototype" === t && "value" in r && Ae in r && !r[Ae]) {
            var n = _e(e, t);
            n && n[Ae] && (e[t] = r.value, r = {
                configurable: Se in r ? r[Se] : n[Se],
                enumerable: Te in r ? r[Te] : n[Te],
                writable: !1
            })
        }
        return Ee(e, t, r)
    } : Ee : function(e, t, r) {
        if (ne(e), t = me(t), ne(r), Z) try {
            return Ee(e, t, r)
        } catch (e) {}
        if ("get" in r || "set" in r) throw new we("Accessors not supported");
        return "value" in r && (e[t] = r.value), e
    },
    Oe = {
        f: Ie
    },
    Re = Oe.f,
    Ne = function(e) {
        var t = u.Symbol || (u.Symbol = {});
        w(t, e) || Re(t, e, {
            value: W(e)
        })
    },
    Pe = {}.propertyIsEnumerable,
    Me = Object.getOwnPropertyDescriptor,
    De = Me && !Pe.call({
        1: 2
    }, 1) ? function(e) {
        var t = Me(this, e);
        return !!t && t.enumerable
    } : Pe,
    xe = {
        f: De
    },
    Ce = function(e, t) {
        return {
            enumerable: !(1 & e),
            configurable: !(2 & e),
            writable: !(4 & e),
            value: t
        }
    },
    ke = h({}.toString),
    Le = h("".slice),
    je = function(e) {
        return Le(ke(e), 8, -1)
    },
    Xe = Object,
    Ue = h("".split),
    Be = s(function() {
        return !Xe("z").propertyIsEnumerable(0)
    }) ? function(e) {
        return "String" === je(e) ? Ue(e, "") : Xe(e)
    } : Xe,
    Fe = function(e) {
        return Be(y(e))
    },
    Ve = Object.getOwnPropertyDescriptor,
    ze = Y ? Ve : function(e, t) {
        if (e = Fe(e), t = me(t), Z) try {
            return Ve(e, t)
        } catch (e) {}
        if (w(e, t)) return Ce(!ie(xe.f, e, t), e[t])
    },
    He = {
        f: ze
    },
    We = Oe.f,
    Ye = He.f,
    Ge = a.Symbol;
if (Ne("asyncDispose"), Ge) {
    var Ke = Ye(Ge, "asyncDispose");
    Ke.enumerable && Ke.configurable && Ke.writable && We(Ge, "asyncDispose", {
        value: Ke.value,
        enumerable: !1,
        configurable: !1,
        writable: !1
    })
}
var qe = Oe.f,
    $e = He.f,
    Qe = a.Symbol;
if (Ne("dispose"), Qe) {
    var Je = $e(Qe, "dispose");
    Je.enumerable && Je.configurable && Je.writable && qe(Qe, "dispose", {
        value: Je.value,
        enumerable: !1,
        configurable: !1,
        writable: !1
    })
}
var Ze = Y ? function(e, t, r) {
        return Oe.f(e, t, Ce(1, r))
    } : function(e, t, r) {
        return e[t] = r, e
    },
    et = Function.prototype,
    tt = Y && Object.getOwnPropertyDescriptor,
    rt = w(et, "name"),
    nt = {
        EXISTS: rt,
        PROPER: rt && "something" === function() {}.name,
        CONFIGURABLE: rt && (!Y || Y && tt(et, "name").configurable)
    },
    ot = h(Function.toString);
K(S.inspectSource) || (S.inspectSource = function(e) {
    return ot(e)
});
var it, at, ut, st = S.inspectSource,
    ct = a.WeakMap,
    ft = K(ct) && /native code/.test(String(ct)),
    lt = A("keys"),
    dt = function(e) {
        return lt[e] || (lt[e] = N(e))
    },
    ht = {},
    pt = "Object already initialized",
    vt = a.TypeError,
    yt = a.WeakMap;
if (ft || S.state) {
    var gt = S.state || (S.state = new yt);
    gt.get = gt.get, gt.has = gt.has, gt.set = gt.set, it = function(e, t) {
        if (gt.has(e)) throw new vt(pt);
        return t.facade = e, gt.set(e, t), t
    }, at = function(e) {
        return gt.get(e) || {}
    }, ut = function(e) {
        return gt.has(e)
    }
} else {
    var bt = dt("state");
    ht[bt] = !0, it = function(e, t) {
        if (w(e, bt)) throw new vt(pt);
        return t.facade = e, Ze(e, bt, t), t
    }, at = function(e) {
        return w(e, bt) ? e[bt] : {}
    }, ut = function(e) {
        return w(e, bt)
    }
}
var mt = {
        set: it,
        get: at,
        has: ut,
        enforce: function(e) {
            return ut(e) ? at(e) : it(e, {})
        },
        getterFor: function(e) {
            return function(t) {
                var r;
                if (!q(t) || (r = at(t)).type !== e) throw new vt("Incompatible receiver, " + e + " required");
                return r
            }
        }
    },
    wt = t(function(e) {
        var t = nt.CONFIGURABLE,
            r = mt.enforce,
            n = mt.get,
            o = String,
            i = Object.defineProperty,
            a = h("".slice),
            u = h("".replace),
            c = h([].join),
            f = Y && !s(function() {
                return 8 !== i(function() {}, "length", {
                    value: 8
                }).length
            }),
            l = String(String).split("String"),
            d = e.exports = function(e, n, s) {
                "Symbol(" === a(o(n), 0, 7) && (n = "[" + u(o(n), /^Symbol\(([^)]*)\).*$/, "$1") + "]"), s && s.getter && (n = "get " + n), s && s.setter && (n = "set " + n), (!w(e, "name") || t && e.name !== n) && (Y ? i(e, "name", {
                    value: n,
                    configurable: !0
                }) : e.name = n), f && s && w(s, "arity") && e.length !== s.arity && i(e, "length", {
                    value: s.arity
                });
                try {
                    s && w(s, "constructor") && s.constructor ? Y && i(e, "prototype", {
                        writable: !1
                    }) : e.prototype && (e.prototype = void 0)
                } catch (e) {}
                var d = r(e);
                return w(d, "source") || (d.source = c(l, "string" == typeof n ? n : "")), e
            };
        Function.prototype.toString = d(function() {
            return K(this) && n(this).source || st(this)
        }, "toString")
    }),
    Et = function(e, t, r, n) {
        n || (n = {});
        var o = n.enumerable,
            i = void 0 !== n.name ? n.name : t;
        if (K(r) && wt(r, i, n), n.global) o ? e[t] = r : T(t, r);
        else {
            try {
                n.unsafe ? e[t] && (o = !0) : delete e[t]
            } catch (e) {}
            o ? e[t] = r : Oe.f(e, t, {
                value: r,
                enumerable: !1,
                configurable: !n.nonConfigurable,
                writable: !n.nonWritable
            })
        }
        return e
    },
    _t = Math.ceil,
    Tt = Math.floor,
    St = Math.trunc || function(e) {
        var t = +e;
        return (t > 0 ? Tt : _t)(t)
    },
    At = function(e) {
        var t = +e;
        return t != t || 0 === t ? 0 : St(t)
    },
    It = Math.max,
    Ot = Math.min,
    Rt = function(e, t) {
        var r = At(e);
        return r < 0 ? It(r + t, 0) : Ot(r, t)
    },
    Nt = Math.min,
    Pt = function(e) {
        var t = At(e);
        return t > 0 ? Nt(t, 9007199254740991) : 0
    },
    Mt = function(e) {
        return Pt(e.length)
    },
    Dt = function(e) {
        return function(t, r, n) {
            var o = Fe(t),
                i = Mt(o);
            if (0 === i) return !e && -1;
            var a, u = Rt(n, i);
            if (e && r != r) {
                for (; i > u;)
                    if ((a = o[u++]) != a) return !0
            } else
                for (; i > u; u++)
                    if ((e || u in o) && o[u] === r) return e || u || 0;
            return !e && -1
        }
    },
    xt = {
        includes: Dt(!0),
        indexOf: Dt(!1)
    },
    Ct = xt.indexOf,
    kt = h([].push),
    Lt = function(e, t) {
        var r, n = Fe(e),
            o = 0,
            i = [];
        for (r in n) !w(ht, r) && w(n, r) && kt(i, r);
        for (; t.length > o;) w(n, r = t[o++]) && (~Ct(i, r) || kt(i, r));
        return i
    },
    jt = ["constructor", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "toLocaleString", "toString", "valueOf"],
    Xt = jt.concat("length", "prototype"),
    Ut = Object.getOwnPropertyNames || function(e) {
        return Lt(e, Xt)
    },
    Bt = {
        f: Ut
    },
    Ft = {
        f: Object.getOwnPropertySymbols
    },
    Vt = h([].concat),
    zt = ae("Reflect", "ownKeys") || function(e) {
        var t = Bt.f(ne(e)),
            r = Ft.f;
        return r ? Vt(t, r(e)) : t
    },
    Ht = function(e, t, r) {
        for (var n = zt(t), o = Oe.f, i = He.f, a = 0; a < n.length; a++) {
            var u = n[a];
            w(e, u) || r && w(r, u) || o(e, u, i(t, u))
        }
    },
    Wt = /#|\.prototype\./,
    Yt = function(e, t) {
        var r = Kt[Gt(e)];
        return r === $t || r !== qt && (K(t) ? s(t) : !!t)
    },
    Gt = Yt.normalize = function(e) {
        return String(e).replace(Wt, ".").toLowerCase()
    },
    Kt = Yt.data = {},
    qt = Yt.NATIVE = "N",
    $t = Yt.POLYFILL = "P",
    Qt = Yt,
    Jt = He.f,
    Zt = function(e, t) {
        var r, n, o, i, u, s = e.target,
            c = e.global,
            f = e.stat;
        if (r = c ? a : f ? a[s] || T(s, {}) : a[s] && a[s].prototype)
            for (n in t) {
                if (i = t[n], o = e.dontCallGetSet ? (u = Jt(r, n)) && u.value : r[n], !Qt(c ? n : s + (f ? "." : "#") + n, e.forced) && void 0 !== o) {
                    if (typeof i == typeof o) continue;
                    Ht(i, o)
                }(e.sham || o && o.sham) && Ze(i, "sham", !0), Et(r, n, i, e)
            }
    },
    er = {};
er[H("toStringTag")] = "z";
var tr = "[object z]" === String(er),
    rr = H("toStringTag"),
    nr = Object,
    or = "Arguments" === je(function() {
        return arguments
    }()),
    ir = tr ? je : function(e) {
        var t, r, n;
        return void 0 === e ? "Undefined" : null === e ? "Null" : "string" == typeof(r = function(e, t) {
            try {
                return e[t]
            } catch (e) {}
        }(t = nr(e), rr)) ? r : or ? je(t) : "Object" === (n = je(t)) && K(t.callee) ? "Arguments" : n
    },
    ar = "Error",
    ur = "DOMException",
    sr = Object.setPrototypeOf || {}.__proto__,
    cr = ae(ur),
    fr = Error,
    lr = fr.isError,
    dr = !lr || !sr || s(function() {
        return cr && !lr(new cr(ur)) || !lr(new fr(ar, {
            cause: function() {}
        })) || lr(ae("Object", "create")(fr.prototype))
    });
Zt({
    target: "Error",
    stat: !0,
    sham: !0,
    forced: dr
}, {
    isError: function(e) {
        if (!q(e)) return !1;
        var t = ir(e);
        return t === ar || t === ur
    }
});
var hr, pr = !s(function() {
        function e() {}
        return e.prototype.constructor = null, Object.getPrototypeOf(new e) !== e.prototype
    }),
    vr = dt("IE_PROTO"),
    yr = Object,
    gr = yr.prototype,
    br = pr ? yr.getPrototypeOf : function(e) {
        var t = b(e);
        if (w(t, vr)) return t[vr];
        var r = t.constructor;
        return K(r) && t instanceof r ? r.prototype : t instanceof yr ? gr : null
    },
    mr = function(e, t, r) {
        try {
            return h(he(Object.getOwnPropertyDescriptor(e, t)[r]))
        } catch (e) {}
    },
    wr = String,
    Er = TypeError,
    _r = Object.setPrototypeOf || ("__proto__" in {} ? function() {
        var e, t = !1,
            r = {};
        try {
            (e = mr(Object.prototype, "__proto__", "set"))(r, []), t = r instanceof Array
        } catch (e) {}
        return function(r, n) {
            return y(r),
                function(e) {
                    if (function(e) {
                            return q(e) || null === e
                        }(e)) return e;
                    throw new Er("Can't set " + wr(e) + " as a prototype")
                }(n), q(r) ? (t ? e(r, n) : r.__proto__ = n, r) : r
        }
    }() : void 0),
    Tr = Object.keys || function(e) {
        return Lt(e, jt)
    },
    Sr = Y && !ee ? Object.defineProperties : function(e, t) {
        ne(e);
        for (var r, n = Fe(t), o = Tr(t), i = o.length, a = 0; i > a;) Oe.f(e, r = o[a++], n[r]);
        return e
    },
    Ar = {
        f: Sr
    },
    Ir = ae("document", "documentElement"),
    Or = "prototype",
    Rr = "script",
    Nr = dt("IE_PROTO"),
    Pr = function() {},
    Mr = function(e) {
        return "<" + Rr + ">" + e + "</" + Rr + ">"
    },
    Dr = function(e) {
        e.write(Mr("")), e.close();
        var t = e.parentWindow.Object;
        return e = null, t
    },
    xr = function() {
        try {
            hr = new ActiveXObject("htmlfile")
        } catch (e) {}
        xr = "undefined" != typeof document ? document.domain && hr ? Dr(hr) : function() {
            var e, t = J("iframe"),
                r = "java" + Rr + ":";
            return t.style.display = "none", Ir.appendChild(t), t.src = String(r), (e = t.contentWindow.document).open(), e.write(Mr("document.F=Object")), e.close(), e.F
        }() : Dr(hr);
        for (var e = jt.length; e--;) delete xr[Or][jt[e]];
        return xr()
    };
ht[Nr] = !0;
var Cr = Object.create || function(e, t) {
        var r;
        return null !== e ? (Pr[Or] = ne(e), r = new Pr, Pr[Or] = null, r[Nr] = e) : r = xr(), void 0 === t ? r : Ar.f(r, t)
    },
    kr = Error,
    Lr = h("".replace),
    jr = String(new kr("zxcasd").stack),
    Xr = /\n\s*at [^:]*:[^\n]*/,
    Ur = Xr.test(jr),
    Br = function(e, t) {
        if (Ur && "string" == typeof e && !kr.prepareStackTrace)
            for (; t--;) e = Lr(e, Xr, "");
        return e
    },
    Fr = !s(function() {
        var e = new Error("a");
        return !("stack" in e) || (Object.defineProperty(e, "stack", Ce(1, 7)), 7 !== e.stack)
    }),
    Vr = Error.captureStackTrace,
    zr = String,
    Hr = function(e) {
        if ("Symbol" === ir(e)) throw new TypeError("Cannot convert a Symbol value to a string");
        return zr(e)
    },
    Wr = function(e, t) {
        return void 0 === e ? arguments.length < 2 ? "" : t : Hr(e)
    },
    Yr = a.SuppressedError,
    Gr = H("toStringTag"),
    Kr = Error,
    qr = !!Yr && 3 !== Yr.length,
    $r = !!Yr && s(function() {
        return 4 === new Yr(1, 2, 3, {
            cause: 4
        }).cause
    }),
    Qr = qr || $r,
    Jr = function(e, t, r) {
        var n, o = ue(Zr, this);
        return _r ? n = !Qr || o && br(this) !== Zr ? _r(new Kr, o ? br(this) : Zr) : new Yr : (n = o ? this : Cr(Zr), Ze(n, Gr, "Error")), void 0 !== r && Ze(n, "message", Wr(r)),
            function(e, t, r) {
                Fr && (Vr ? Vr(e, t) : Ze(e, "stack", Br(r, 1)))
            }(n, Jr, n.stack), Ze(n, "error", e), Ze(n, "suppressed", t), n
    };
_r ? _r(Jr, Kr) : Ht(Jr, Kr, {
    name: !0
});
var Zr = Jr.prototype = Qr ? Yr.prototype : Cr(Kr.prototype, {
    constructor: Ce(1, Jr),
    message: Ce(1, ""),
    name: Ce(1, "SuppressedError")
});
Qr && (Zr.constructor = Jr), Zt({
    global: !0,
    constructor: !0,
    arity: 3,
    forced: Qr
}, {
    SuppressedError: Jr
});
var en = function(e) {
        if ("Function" === je(e)) return h(e)
    },
    tn = en(en.bind),
    rn = function(e, t) {
        return he(e), void 0 === t ? e : c ? tn(e, t) : function() {
            return e.apply(t, arguments)
        }
    },
    nn = function(e) {
        var t = 1 === e;
        return function(r, n, o) {
            for (var i, a = b(r), u = Be(a), s = Mt(u), c = rn(n, o); s-- > 0;)
                if (c(i = u[s], s, a)) switch (e) {
                    case 0:
                        return i;
                    case 1:
                        return s
                }
            return t ? -1 : void 0
        }
    },
    on = {
        findLast: nn(0),
        findLastIndex: nn(1)
    },
    an = Oe.f,
    un = H("unscopables"),
    sn = Array.prototype;
void 0 === sn[un] && an(sn, un, {
    configurable: !0,
    value: Cr(null)
});
var cn = function(e) {
        sn[un][e] = !0
    },
    fn = on.findLast;
Zt({
    target: "Array",
    proto: !0
}, {
    findLast: function(e) {
        return fn(this, e, arguments.length > 1 ? arguments[1] : void 0)
    }
}), cn("findLast");
var ln = on.findLastIndex;
Zt({
    target: "Array",
    proto: !0
}, {
    findLastIndex: function(e) {
        return ln(this, e, arguments.length > 1 ? arguments[1] : void 0)
    }
}), cn("findLastIndex");
var dn = xt.includes,
    hn = s(function() {
        return !Array(1).includes()
    });
Zt({
    target: "Array",
    proto: !0,
    forced: hn
}, {
    includes: function(e) {
        return dn(this, e, arguments.length > 1 ? arguments[1] : void 0)
    }
}), cn("includes");
var pn = Array.isArray || function(e) {
        return "Array" === je(e)
    },
    vn = TypeError,
    yn = Object.getOwnPropertyDescriptor,
    gn = Y && ! function() {
        if (void 0 !== this) return !0;
        try {
            Object.defineProperty([], "length", {
                writable: !1
            }).length = 1
        } catch (e) {
            return e instanceof TypeError
        }
    }() ? function(e, t) {
        if (pn(e) && !yn(e, "length").writable) throw new vn("Cannot set read only .length");
        return e.length = t
    } : function(e, t) {
        return e.length = t
    },
    bn = TypeError,
    mn = function(e) {
        if (e > 9007199254740991) throw bn("Maximum allowed index exceeded");
        return e
    },
    wn = s(function() {
        return 4294967297 !== [].push.call({
            length: 4294967296
        }, 1)
    }) || ! function() {
        try {
            Object.defineProperty([], "length", {
                writable: !1
            }).push()
        } catch (e) {
            return e instanceof TypeError
        }
    }();
Zt({
    target: "Array",
    proto: !0,
    arity: 1,
    forced: wn
}, {
    push: function(e) {
        var t = b(this),
            r = Mt(t),
            n = arguments.length;
        mn(r + n);
        for (var o = 0; o < n; o++) t[r] = arguments[o], r++;
        return gn(t, r), r
    }
});
var En = function(e, t) {
        for (var r = Mt(e), n = new t(r), o = 0; o < r; o++) n[o] = e[r - o - 1];
        return n
    },
    _n = Array;
Zt({
    target: "Array",
    proto: !0
}, {
    toReversed: function() {
        return En(Fe(this), _n)
    }
}), cn("toReversed");
var Tn = function(e, t, r) {
        for (var n = 0, o = arguments.length > 2 ? r : Mt(t), i = new e(o); o > n;) i[n] = t[n++];
        return i
    },
    Sn = function(e, t) {
        var r = a[e],
            n = r && r.prototype;
        return n && n[t]
    },
    An = Array,
    In = h(Sn("Array", "sort"));
Zt({
    target: "Array",
    proto: !0
}, {
    toSorted: function(e) {
        void 0 !== e && he(e);
        var t = Fe(this),
            r = Tn(An, t);
        return In(r, e)
    }
}), cn("toSorted");
var On = Array,
    Rn = Math.max,
    Nn = Math.min;
Zt({
    target: "Array",
    proto: !0
}, {
    toSpliced: function(e, t) {
        var r, n, o, i, a = Fe(this),
            u = Mt(a),
            s = Rt(e, u),
            c = arguments.length,
            f = 0;
        for (0 === c ? r = n = 0 : 1 === c ? (r = 0, n = u - s) : (r = c - 2, n = Nn(Rn(At(t), 0), u - s)), o = mn(u + r - n), i = On(o); f < s; f++) i[f] = a[f];
        for (; f < s + r; f++) i[f] = arguments[f - s + 2];
        for (; f < o; f++) i[f] = a[f + n - r];
        return i
    }
}), cn("toSpliced");
var Pn = TypeError,
    Mn = function(e, t) {
        if (!delete e[t]) throw new Pn("Cannot delete property " + le(t) + " of " + le(e))
    },
    Dn = 1 !== [].unshift(0) || ! function() {
        try {
            Object.defineProperty([], "length", {
                writable: !1
            }).unshift()
        } catch (e) {
            return e instanceof TypeError
        }
    }();
Zt({
    target: "Array",
    proto: !0,
    arity: 1,
    forced: Dn
}, {
    unshift: function(e) {
        var t = b(this),
            r = Mt(t),
            n = arguments.length;
        if (n) {
            mn(r + n);
            for (var o = r; o--;) {
                var i = o + n;
                o in t ? t[i] = t[o] : Mn(t, i)
            }
            for (var a = 0; a < n; a++) t[a] = arguments[a]
        }
        return gn(t, r + n)
    }
});
var xn = RangeError,
    Cn = function(e, t, r, n) {
        var o = Mt(e),
            i = At(r),
            a = i < 0 ? o + i : i;
        if (a >= o || a < 0) throw new xn("Incorrect index");
        for (var u = new t(o), s = 0; s < o; s++) u[s] = s === a ? n : e[s];
        return u
    },
    kn = Array,
    Ln = function() {
        try {
            [].with({
                valueOf: function() {
                    throw 4
                }
            }, null)
        } catch (e) {
            return 4 !== e
        }
    }();
Zt({
    target: "Array",
    proto: !0,
    forced: Ln
}, {
    with: function(e, t) {
        return Cn(Fe(this), kn, e, t)
    }
});
var jn = Math.pow,
    Xn = jn(2, -24),
    Un = .0009765625,
    Bn = h(DataView.prototype.getUint16);
Zt({
    target: "DataView",
    proto: !0
}, {
    getFloat16: function(e) {
        return function(e) {
            var t = e >>> 15,
                r = e >>> 10 & 31,
                n = 1023 & e;
            return 31 === r ? 0 === n ? 0 === t ? 1 / 0 : -1 / 0 : NaN : 0 === r ? n * (0 === t ? Xn : -Xn) : jn(2, r - 15) * (0 === t ? 1 + n * Un : -1 - n * Un)
        }(Bn(this, e, arguments.length > 1 && arguments[1]))
    }
});
var Fn = TypeError,
    Vn = function(e) {
        if ("DataView" === ir(e)) return e;
        throw new Fn("Argument is not a DataView")
    },
    zn = RangeError,
    Hn = function(e) {
        if (void 0 === e) return 0;
        var t = At(e),
            r = Pt(t);
        if (t !== r) throw new zn("Wrong length or index");
        return r
    },
    Wn = Math.log,
    Yn = Math.LN2,
    Gn = Math.log2 || function(e) {
        return Wn(e) / Yn
    },
    Kn = 4503599627370496,
    qn = function(e) {
        return e + Kn - Kn
    },
    $n = Math.pow,
    Qn = 1024,
    Jn = h(DataView.prototype.setUint16);
Zt({
    target: "DataView",
    proto: !0
}, {
    setFloat16: function(e, t) {
        Jn(Vn(this), Hn(e), function(e) {
            if (e != e) return 32256;
            if (0 === e) return (1 / e == -1 / 0) << 15;
            var t = e < 0;
            if (t && (e = -e), e >= 65520) return t << 15 | 31744;
            if (e < 61005353927612305e-21) return t << 15 | qn(16777216 * e);
            var r = 0 | Gn(e);
            if (-15 === r) return t << 15 | Qn;
            var n = qn((e * $n(2, -r) - 1) * Qn);
            return n === Qn ? t << 15 | r + 16 << 10 : t << 15 | r + 15 << 10 | n
        }(+t), arguments.length > 2 && arguments[2])
    }
});
var Zn = function(e, t, r) {
        return r.get && wt(r.get, t, {
            getter: !0
        }), r.set && wt(r.set, t, {
            setter: !0
        }), Oe.f(e, t, r)
    },
    eo = "undefined" != typeof ArrayBuffer && "undefined" != typeof DataView,
    to = a.ArrayBuffer,
    ro = a.TypeError,
    no = to && mr(to.prototype, "byteLength", "get") || function(e) {
        if ("ArrayBuffer" !== je(e)) throw new ro("ArrayBuffer expected");
        return e.byteLength
    },
    oo = a.DataView,
    io = function(e) {
        if (!eo || 0 !== no(e)) return !1;
        try {
            return new oo(e), !1
        } catch (e) {
            return !0
        }
    },
    ao = ArrayBuffer.prototype;
Y && !("detached" in ao) && Zn(ao, "detached", {
    configurable: !0,
    get: function() {
        return io(this)
    }
});
var uo, so, co, fo, lo = TypeError,
    ho = function(e) {
        if (io(e)) throw new lo("ArrayBuffer is detached");
        return e
    },
    po = function(e) {
        return D.slice(0, e.length) === e
    },
    vo = po("Bun/") ? "BUN" : po("Cloudflare-Workers") ? "CLOUDFLARE" : po("Deno/") ? "DENO" : po("Node.js/") ? "NODE" : a.Bun && "string" == typeof Bun.version ? "BUN" : a.Deno && "object" == typeof Deno.version ? "DENO" : "process" === je(a.process) ? "NODE" : a.window && a.document ? "BROWSER" : "REST",
    yo = "NODE" === vo,
    go = a.structuredClone,
    bo = !!go && !s(function() {
        if ("DENO" === vo && j > 92 || "NODE" === vo && j > 94 || "BROWSER" === vo && j > 97) return !1;
        var e = new ArrayBuffer(8),
            t = go(e, {
                transfer: [e]
            });
        return 0 !== e.byteLength || 8 !== t.byteLength
    }),
    mo = a.structuredClone,
    wo = a.ArrayBuffer,
    Eo = a.MessageChannel,
    _o = !1;
if (bo) _o = function(e) {
    mo(e, {
        transfer: [e]
    })
};
else if (wo) try {
    Eo || (uo = function(e) {
        if (yo) {
            try {
                return a.process.getBuiltinModule(e)
            } catch (e) {}
            try {
                return Function('return require("' + e + '")')()
            } catch (e) {}
        }
    }("worker_threads")) && (Eo = uo.MessageChannel), Eo && (so = new Eo, co = new wo(2), fo = function(e) {
        so.port1.postMessage(null, [e])
    }, 2 === co.byteLength && (fo(co), 0 === co.byteLength && (_o = fo)))
} catch (e) {}
var To = _o,
    So = a.structuredClone,
    Ao = a.ArrayBuffer,
    Io = a.DataView,
    Oo = Math.min,
    Ro = Ao.prototype,
    No = Io.prototype,
    Po = h(Ro.slice),
    Mo = mr(Ro, "resizable", "get"),
    Do = mr(Ro, "maxByteLength", "get"),
    xo = h(No.getInt8),
    Co = h(No.setInt8),
    ko = (bo || To) && function(e, t, r) {
        var n, o = no(e),
            i = void 0 === t ? o : Hn(t),
            a = !Mo || !Mo(e);
        if (ho(e), bo && (e = So(e, {
                transfer: [e]
            }), o === i && (r || a))) return e;
        if (o >= i && (!r || a)) n = Po(e, 0, i);
        else {
            var u = r && !a && Do ? {
                maxByteLength: Do(e)
            } : void 0;
            n = new Ao(i, u);
            for (var s = new Io(e), c = new Io(n), f = Oo(i, o), l = 0; l < f; l++) Co(c, l, xo(s, l))
        }
        return bo || To(e), n
    };
ko && Zt({
    target: "ArrayBuffer",
    proto: !0
}, {
    transfer: function() {
        return ko(this, arguments.length ? arguments[0] : void 0, !0)
    }
}), ko && Zt({
    target: "ArrayBuffer",
    proto: !0
}, {
    transferToFixedLength: function() {
        return ko(this, arguments.length ? arguments[0] : void 0, !1)
    }
});
var Lo = TypeError,
    jo = function(e, t) {
        if (ue(t, e)) return e;
        throw new Lo("Incorrect invocation")
    },
    Xo = function(e, t, r) {
        for (var n in t) Et(e, n, t[n], r);
        return e
    },
    Uo = H("asyncDispose"),
    Bo = H("dispose"),
    Fo = h([].push),
    Vo = function(e, t, r) {
        return arguments.length < 3 && !p(e) && (r = he(function(e, t) {
            if ("async-dispose" === t) {
                var r = pe(e, Uo);
                return void 0 !== r || void 0 === (r = pe(e, Bo)) ? r : function() {
                    var e = this;
                    return new(ae("Promise"))(function(t) {
                        ie(r, e), t(void 0)
                    })
                }
            }
            return pe(e, Bo)
        }(ne(e), t))), void 0 === r ? function() {} : rn(r, e)
    },
    zo = function(e, t, r, n) {
        var o;
        if (arguments.length < 4) {
            if (p(t) && "sync-dispose" === r) return;
            o = Vo(t, r)
        } else o = Vo(void 0, r, n);
        Fo(e.stack, o)
    },
    Ho = ae("SuppressedError"),
    Wo = ReferenceError,
    Yo = H("dispose"),
    Go = H("toStringTag"),
    Ko = "DisposableStack",
    qo = mt.set,
    $o = mt.getterFor(Ko),
    Qo = "sync-dispose",
    Jo = "disposed",
    Zo = function(e) {
        var t = $o(e);
        if (t.state === Jo) throw new Wo(Ko + " already disposed");
        return t
    },
    ei = function() {
        qo(jo(this, ti), {
            type: Ko,
            state: "pending",
            stack: []
        }), Y || (this.disposed = !1)
    },
    ti = ei.prototype;
Xo(ti, {
    dispose: function() {
        var e = $o(this);
        if (e.state !== Jo) {
            e.state = Jo, Y || (this.disposed = !0);
            for (var t, r = e.stack, n = r.length, o = !1; n;) {
                var i = r[--n];
                r[n] = null;
                try {
                    i()
                } catch (e) {
                    o ? t = new Ho(e, t) : (o = !0, t = e)
                }
            }
            if (e.stack = null, o) throw t
        }
    },
    use: function(e) {
        return zo(Zo(this), e, Qo), e
    },
    adopt: function(e, t) {
        var r = Zo(this);
        return he(t), zo(r, void 0, Qo, function() {
            t(e)
        }), e
    },
    defer: function(e) {
        var t = Zo(this);
        he(e), zo(t, void 0, Qo, e)
    },
    move: function() {
        var e = Zo(this),
            t = new ei;
        return $o(t).stack = e.stack, e.stack = [], e.state = Jo, Y || (this.disposed = !0), t
    }
}), Y && Zn(ti, "disposed", {
    configurable: !0,
    get: function() {
        return $o(this).state === Jo
    }
}), Et(ti, Yo, ti.dispose, {
    name: "dispose"
}), Et(ti, Go, Ko, {
    nonWritable: !0
}), Zt({
    global: !0,
    constructor: !0
}, {
    DisposableStack: ei
});
var ri, ni, oi, ii = function(e, t, r) {
        Y ? Oe.f(e, t, Ce(0, r)) : e[t] = r
    },
    ai = H("iterator"),
    ui = !1;
[].keys && ("next" in (oi = [].keys()) ? (ni = br(br(oi))) !== Object.prototype && (ri = ni) : ui = !0);
var si = !q(ri) || s(function() {
    var e = {};
    return ri[ai].call(e) !== e
});
si && (ri = {}), K(ri[ai]) || Et(ri, ai, function() {
    return this
});
var ci = {
        IteratorPrototype: ri,
        BUGGY_SAFARI_ITERATORS: ui
    },
    fi = ci.IteratorPrototype,
    li = "constructor",
    di = "Iterator",
    hi = H("toStringTag"),
    pi = TypeError,
    vi = a[di],
    yi = !K(vi) || vi.prototype !== fi || !s(function() {
        vi({})
    }),
    gi = function() {
        if (jo(this, fi), br(this) === fi) throw new pi("Abstract class Iterator not directly constructable")
    },
    bi = function(e, t) {
        Y ? Zn(fi, e, {
            configurable: !0,
            get: function() {
                return t
            },
            set: function(t) {
                if (ne(this), this === fi) throw new pi("You can't redefine this property");
                w(this, e) ? this[e] = t : ii(this, e, t)
            }
        }) : fi[e] = t
    };
w(fi, hi) || bi(hi, di), !yi && w(fi, li) && fi[li] !== Object || bi(li, gi), gi.prototype = fi, Zt({
    global: !0,
    constructor: !0,
    forced: yi
}, {
    Iterator: gi
});
var mi = {},
    wi = H("iterator"),
    Ei = function(e) {
        if (!p(e)) return pe(e, wi) || pe(e, "@@iterator") || mi[ir(e)]
    },
    _i = function(e, t) {
        return {
            value: e,
            done: t
        }
    },
    Ti = function(e, t, r) {
        var n, o;
        ne(e);
        try {
            if (!(n = pe(e, "return"))) {
                if ("throw" === t) throw r;
                return r
            }
            n = ie(n, e)
        } catch (e) {
            o = !0, n = e
        }
        if ("throw" === t) throw r;
        if (o) throw n;
        return ne(n), r
    },
    Si = function(e, t, r) {
        for (var n = e.length - 1; n >= 0; n--)
            if (void 0 !== e[n]) try {
                r = Ti(e[n].iterator, t, r)
            } catch (e) {
                t = "throw", r = e
            }
        if ("throw" === t) throw r;
        return r
    },
    Ai = ci.IteratorPrototype,
    Ii = H("toStringTag"),
    Oi = "IteratorHelper",
    Ri = "WrapForValidIterator",
    Ni = "normal",
    Pi = "throw",
    Mi = mt.set,
    Di = function(e) {
        var t = mt.getterFor(e ? Ri : Oi);
        return Xo(Cr(Ai), {
            next: function() {
                var r = t(this);
                if (e) return r.nextHandler();
                if (r.done) return _i(void 0, !0);
                try {
                    var n = r.nextHandler();
                    return r.returnHandlerResult ? n : _i(n, r.done)
                } catch (e) {
                    throw r.done = !0, e
                }
            },
            return: function() {
                var r = t(this),
                    n = r.iterator;
                if (r.done = !0, e) {
                    var o = pe(n, "return");
                    return o ? ie(o, n) : _i(void 0, !0)
                }
                if (r.inner) try {
                    Ti(r.inner.iterator, Ni)
                } catch (e) {
                    return Ti(n, Pi, e)
                }
                if (r.openIters) try {
                    Si(r.openIters, Ni)
                } catch (e) {
                    return Ti(n, Pi, e)
                }
                return n && Ti(n, Ni), _i(void 0, !0)
            }
        })
    },
    xi = Di(!0),
    Ci = Di(!1);
Ze(Ci, Ii, "Iterator Helper");
var ki = function(e, t, r) {
        var n = function(n, o) {
            o ? (o.iterator = n.iterator, o.next = n.next) : o = n, o.type = t ? Ri : Oi, o.returnHandlerResult = !!r, o.nextHandler = e, o.counter = 0, o.done = !1, Mi(this, o)
        };
        return n.prototype = t ? xi : Ci, n
    },
    Li = Array,
    ji = ki(function() {
        for (;;) {
            var e = this.iterator;
            if (!e) {
                var t = this.nextIterableIndex++,
                    r = this.iterables;
                if (t >= r.length) return void(this.done = !0);
                var n = r[t];
                this.iterables[t] = null, e = this.iterator = ie(n.method, n.iterable), this.next = e.next
            }
            var o = ne(ie(this.next, e));
            if (!o.done) return o.value;
            this.iterator = null, this.next = null
        }
    });
Zt({
    target: "Iterator",
    stat: !0
}, {
    concat: function() {
        for (var e = arguments.length, t = Li(e), r = 0; r < e; r++) {
            var n = ne(arguments[r]);
            t[r] = {
                iterable: n,
                method: he(Ei(n))
            }
        }
        return new ji({
            iterables: t,
            nextIterableIndex: 0,
            iterator: null,
            next: null
        })
    }
});
var Xi = ci.IteratorPrototype,
    Ui = H("dispose");
w(Xi, Ui) || Et(Xi, Ui, function() {
    var e = pe(this, "return");
    e && ie(e, this)
});
var Bi = function(e) {
        return {
            iterator: e,
            next: e.next,
            done: !1
        }
    },
    Fi = RangeError,
    Vi = function(e) {
        if (e == e) return e;
        throw new Fi("NaN is not allowed")
    },
    zi = RangeError,
    Hi = function(e) {
        var t = At(e);
        if (t < 0) throw new zi("The argument can't be less than 0");
        return t
    },
    Wi = function(e, t) {
        var r = "function" == typeof Iterator && Iterator.prototype[e];
        if (r) try {
            r.call({
                next: null
            }, t).next()
        } catch (e) {
            return !0
        }
    },
    Yi = function(e, t) {
        var r = a.Iterator,
            n = r && r.prototype,
            o = n && n[e],
            i = !1;
        if (o) try {
            o.call({
                next: function() {
                    return {
                        done: !0
                    }
                },
                return: function() {
                    i = !0
                }
            }, -1)
        } catch (e) {
            e instanceof t || (i = !1)
        }
        if (!i) return o
    },
    Gi = !Wi("drop", 0),
    Ki = !Gi && Yi("drop", RangeError),
    qi = Gi || Ki,
    $i = ki(function() {
        for (var e, t = this.iterator, r = this.next; this.remaining;)
            if (this.remaining--, e = ne(ie(r, t)), this.done = !!e.done) return;
        if (e = ne(ie(r, t)), !(this.done = !!e.done)) return e.value
    });
Zt({
    target: "Iterator",
    proto: !0,
    real: !0,
    forced: qi
}, {
    drop: function(e) {
        var t;
        ne(this);
        try {
            t = Hi(Vi(+e))
        } catch (e) {
            Ti(this, "throw", e)
        }
        return Ki ? ie(Ki, this, t) : new $i(Bi(this), {
            remaining: t
        })
    }
});
var Qi = H("iterator"),
    Ji = Array.prototype,
    Zi = TypeError,
    ea = function(e, t) {
        var r = arguments.length < 2 ? Ei(e) : t;
        if (he(r)) return ne(ie(r, e));
        throw new Zi(le(e) + " is not iterable")
    },
    ta = TypeError,
    ra = function(e, t) {
        this.stopped = e, this.result = t
    },
    na = ra.prototype,
    oa = function(e, t, r) {
        var n, o, i, a, u, s, c, f = r && r.that,
            l = !(!r || !r.AS_ENTRIES),
            d = !(!r || !r.IS_RECORD),
            h = !(!r || !r.IS_ITERATOR),
            p = !(!r || !r.INTERRUPTED),
            v = rn(t, f),
            y = function(e) {
                return n && Ti(n, "normal"), new ra(!0, e)
            },
            g = function(e) {
                return l ? (ne(e), p ? v(e[0], e[1], y) : v(e[0], e[1])) : p ? v(e, y) : v(e)
            };
        if (d) n = e.iterator;
        else if (h) n = e;
        else {
            if (!(o = Ei(e))) throw new ta(le(e) + " is not iterable");
            if (function(e) {
                    return void 0 !== e && (mi.Array === e || Ji[Qi] === e)
                }(o)) {
                for (i = 0, a = Mt(e); a > i; i++)
                    if ((u = g(e[i])) && ue(na, u)) return u;
                return new ra(!1)
            }
            n = ea(e, o)
        }
        for (s = d ? e.next : n.next; !(c = ie(s, n)).done;) {
            try {
                u = g(c.value)
            } catch (e) {
                Ti(n, "throw", e)
            }
            if ("object" == typeof u && u && ue(na, u)) return u
        }
        return new ra(!1)
    },
    ia = Yi("every", TypeError);
Zt({
    target: "Iterator",
    proto: !0,
    real: !0,
    forced: ia
}, {
    every: function(e) {
        ne(this);
        try {
            he(e)
        } catch (e) {
            Ti(this, "throw", e)
        }
        if (ia) return ie(ia, this, e);
        var t = Bi(this),
            r = 0;
        return !oa(t, function(t, n) {
            if (!e(t, r++)) return n()
        }, {
            IS_RECORD: !0,
            INTERRUPTED: !0
        }).stopped
    }
});
var aa = function(e, t, r, n) {
        try {
            return n ? t(ne(r)[0], r[1]) : t(r)
        } catch (t) {
            Ti(e, "throw", t)
        }
    },
    ua = !Wi("filter", function() {}),
    sa = !ua && Yi("filter", TypeError),
    ca = ua || sa,
    fa = ki(function() {
        for (var e, t, r = this.iterator, n = this.predicate, o = this.next;;) {
            if (e = ne(ie(o, r)), this.done = !!e.done) return;
            if (t = e.value, aa(r, n, [t, this.counter++], !0)) return t
        }
    });
Zt({
    target: "Iterator",
    proto: !0,
    real: !0,
    forced: ca
}, {
    filter: function(e) {
        ne(this);
        try {
            he(e)
        } catch (e) {
            Ti(this, "throw", e)
        }
        return sa ? ie(sa, this, e) : new fa(Bi(this), {
            predicate: e
        })
    }
});
var la = Yi("find", TypeError);
Zt({
    target: "Iterator",
    proto: !0,
    real: !0,
    forced: la
}, {
    find: function(e) {
        ne(this);
        try {
            he(e)
        } catch (e) {
            Ti(this, "throw", e)
        }
        if (la) return ie(la, this, e);
        var t = Bi(this),
            r = 0;
        return oa(t, function(t, n) {
            if (e(t, r++)) return n(t)
        }, {
            IS_RECORD: !0,
            INTERRUPTED: !0
        }).result
    }
});
var da = function(e, t) {
        t && "string" == typeof e || ne(e);
        var r = Ei(e);
        return Bi(ne(void 0 !== r ? ie(r, e) : e))
    },
    ha = !Wi("flatMap", function() {}),
    pa = !ha && Yi("flatMap", TypeError),
    va = ha || pa,
    ya = ki(function() {
        for (var e, t, r = this.iterator, n = this.mapper;;) {
            if (t = this.inner) try {
                if (!(e = ne(ie(t.next, t.iterator))).done) return e.value;
                this.inner = null
            } catch (e) {
                Ti(r, "throw", e)
            }
            if (e = ne(ie(this.next, r)), this.done = !!e.done) return;
            try {
                this.inner = da(n(e.value, this.counter++), !1)
            } catch (e) {
                Ti(r, "throw", e)
            }
        }
    });
Zt({
    target: "Iterator",
    proto: !0,
    real: !0,
    forced: va
}, {
    flatMap: function(e) {
        ne(this);
        try {
            he(e)
        } catch (e) {
            Ti(this, "throw", e)
        }
        return pa ? ie(pa, this, e) : new ya(Bi(this), {
            mapper: e,
            inner: null
        })
    }
});
var ga = Yi("forEach", TypeError);
Zt({
    target: "Iterator",
    proto: !0,
    real: !0,
    forced: ga
}, {
    forEach: function(e) {
        ne(this);
        try {
            he(e)
        } catch (e) {
            Ti(this, "throw", e)
        }
        if (ga) return ie(ga, this, e);
        var t = Bi(this),
            r = 0;
        oa(t, function(t) {
            e(t, r++)
        }, {
            IS_RECORD: !0
        })
    }
});
var ba = ci.IteratorPrototype,
    ma = function() {
        try {
            Iterator.from({
                return: null
            }).return()
        } catch (e) {
            return !0
        }
    }(),
    wa = ki(function() {
        return ie(this.next, this.iterator)
    }, !0);
Zt({
    target: "Iterator",
    stat: !0,
    forced: ma
}, {
    from: function(e) {
        var t = da("string" == typeof e ? b(e) : e, !0);
        return ue(ba, t.iterator) ? t.iterator : new wa(t)
    }
});
var Ea = !Wi("map", function() {}),
    _a = !Ea && Yi("map", TypeError),
    Ta = Ea || _a,
    Sa = ki(function() {
        var e = this.iterator,
            t = ne(ie(this.next, e));
        if (!(this.done = !!t.done)) return aa(e, this.mapper, [t.value, this.counter++], !0)
    });
Zt({
    target: "Iterator",
    proto: !0,
    real: !0,
    forced: Ta
}, {
    map: function(e) {
        ne(this);
        try {
            he(e)
        } catch (e) {
            Ti(this, "throw", e)
        }
        return _a ? ie(_a, this, e) : new Sa(Bi(this), {
            mapper: e
        })
    }
});
var Aa = Function.prototype,
    Ia = Aa.apply,
    Oa = Aa.call,
    Ra = "object" == typeof Reflect && Reflect.apply || (c ? Oa.bind(Ia) : function() {
        return Oa.apply(Ia, arguments)
    }),
    Na = TypeError,
    Pa = s(function() {
        [].keys().reduce(function() {}, void 0)
    }),
    Ma = !Pa && Yi("reduce", Na);
Zt({
    target: "Iterator",
    proto: !0,
    real: !0,
    forced: Pa || Ma
}, {
    reduce: function(e) {
        ne(this);
        try {
            he(e)
        } catch (e) {
            Ti(this, "throw", e)
        }
        var t = arguments.length < 2,
            r = t ? void 0 : arguments[1];
        if (Ma) return Ra(Ma, this, t ? [e] : [e, r]);
        var n = Bi(this),
            o = 0;
        if (oa(n, function(n) {
                t ? (t = !1, r = n) : r = e(r, n, o), o++
            }, {
                IS_RECORD: !0
            }), t) throw new Na("Reduce of empty iterator with no initial value");
        return r
    }
});
var Da = Yi("some", TypeError);
Zt({
    target: "Iterator",
    proto: !0,
    real: !0,
    forced: Da
}, {
    some: function(e) {
        ne(this);
        try {
            he(e)
        } catch (e) {
            Ti(this, "throw", e)
        }
        if (Da) return ie(Da, this, e);
        var t = Bi(this),
            r = 0;
        return oa(t, function(t, n) {
            if (e(t, r++)) return n()
        }, {
            IS_RECORD: !0,
            INTERRUPTED: !0
        }).stopped
    }
});
var xa = Yi("take", RangeError),
    Ca = ki(function() {
        var e = this.iterator;
        if (!this.remaining--) return this.done = !0, Ti(e, "normal", void 0);
        var t = ne(ie(this.next, e));
        return (this.done = !!t.done) ? void 0 : t.value
    });
Zt({
    target: "Iterator",
    proto: !0,
    real: !0,
    forced: xa
}, {
    take: function(e) {
        var t;
        ne(this);
        try {
            t = Hi(Vi(+e))
        } catch (e) {
            Ti(this, "throw", e)
        }
        return xa ? ie(xa, this, t) : new Ca(Bi(this), {
            remaining: t
        })
    }
});
var ka = [].push;
Zt({
    target: "Iterator",
    proto: !0,
    real: !0
}, {
    toArray: function() {
        var e = [];
        return oa(Bi(ne(this)), ka, {
            that: e,
            IS_RECORD: !0
        }), e
    }
});
var La = !s(function() {
        var e = "9007199254740993",
            t = JSON.rawJSON(e);
        return !JSON.isRawJSON(t) || JSON.stringify(t) !== e
    }),
    ja = mt.get,
    Xa = function(e) {
        if (!q(e)) return !1;
        var t = ja(e);
        return !!t && "RawJSON" === t.type
    };
Zt({
    target: "JSON",
    stat: !0,
    forced: !La
}, {
    isRawJSON: Xa
});
var Ua = SyntaxError,
    Ba = parseInt,
    Fa = String.fromCharCode,
    Va = h("".charAt),
    za = h("".slice),
    Ha = h(/./.exec),
    Wa = {
        '\\"': '"',
        "\\\\": "\\",
        "\\/": "/",
        "\\b": "\b",
        "\\f": "\f",
        "\\n": "\n",
        "\\r": "\r",
        "\\t": "\t"
    },
    Ya = /^[\da-f]{4}$/i,
    Ga = /^[\u0000-\u001F]$/,
    Ka = function(e, t) {
        for (var r = !0, n = ""; t < e.length;) {
            var o = Va(e, t);
            if ("\\" === o) {
                var i = za(e, t, t + 2);
                if (w(Wa, i)) n += Wa[i], t += 2;
                else {
                    if ("\\u" !== i) throw new Ua('Unknown escape sequence: "' + i + '"');
                    var a = za(e, t += 2, t + 4);
                    if (!Ha(Ya, a)) throw new Ua("Bad Unicode escape at: " + t);
                    n += Fa(Ba(a, 16)), t += 4
                }
            } else {
                if ('"' === o) {
                    r = !1, t++;
                    break
                }
                if (Ha(Ga, o)) throw new Ua("Bad control character in string literal at: " + t);
                n += o, t++
            }
        }
        if (r) throw new Ua("Unterminated string at: " + t);
        return {
            value: n,
            end: t
        }
    },
    qa = a.JSON,
    $a = a.Number,
    Qa = a.SyntaxError,
    Ja = qa && qa.parse,
    Za = ae("Object", "keys"),
    eu = Object.getOwnPropertyDescriptor,
    tu = h("".charAt),
    ru = h("".slice),
    nu = h(/./.exec),
    ou = h([].push),
    iu = /^\d$/,
    au = /^[1-9]$/,
    uu = /^[\d-]$/,
    su = /^[\t\n\r ]$/,
    cu = function(e, t, r, n) {
        var o, i, a, u, s, c = e[t],
            f = n && c === n.value,
            l = f && "string" == typeof n.source ? {
                source: n.source
            } : {};
        if (q(c)) {
            var d = pn(c),
                h = f ? n.nodes : d ? [] : {};
            if (d)
                for (o = h.length, a = Mt(c), u = 0; u < a; u++) fu(c, u, cu(c, "" + u, r, u < o ? h[u] : void 0));
            else
                for (i = Za(c), a = Mt(i), u = 0; u < a; u++) s = i[u], fu(c, s, cu(c, s, r, w(h, s) ? h[s] : void 0))
        }
        return ie(r, e, t, c, l)
    },
    fu = function(e, t, r) {
        if (Y) {
            var n = eu(e, t);
            if (n && !n.configurable) return
        }
        void 0 === r ? delete e[t] : ii(e, t, r)
    },
    lu = function(e, t, r, n) {
        this.value = e, this.end = t, this.source = r, this.nodes = n
    },
    du = function(e, t) {
        this.source = e, this.index = t
    };
du.prototype = {
    fork: function(e) {
        return new du(this.source, e)
    },
    parse: function() {
        var e = this.source,
            t = this.skip(su, this.index),
            r = this.fork(t),
            n = tu(e, t);
        if (nu(uu, n)) return r.number();
        switch (n) {
            case "{":
                return r.object();
            case "[":
                return r.array();
            case '"':
                return r.string();
            case "t":
                return r.keyword(!0);
            case "f":
                return r.keyword(!1);
            case "n":
                return r.keyword(null)
        }
        throw new Qa('Unexpected character: "' + n + '" at: ' + t)
    },
    node: function(e, t, r, n, o) {
        return new lu(t, n, e ? null : ru(this.source, r, n), o)
    },
    object: function() {
        for (var e = this.source, t = this.index + 1, r = !1, n = {}, o = {}; t < e.length;) {
            if (t = this.until(['"', "}"], t), "}" === tu(e, t) && !r) {
                t++;
                break
            }
            var i = this.fork(t).string(),
                a = i.value;
            t = i.end, t = this.until([":"], t) + 1, t = this.skip(su, t), i = this.fork(t).parse(), ii(o, a, i), ii(n, a, i.value), t = this.until([",", "}"], i.end);
            var u = tu(e, t);
            if ("," === u) r = !0, t++;
            else if ("}" === u) {
                t++;
                break
            }
        }
        return this.node(1, n, this.index, t, o)
    },
    array: function() {
        for (var e = this.source, t = this.index + 1, r = !1, n = [], o = []; t < e.length;) {
            if (t = this.skip(su, t), "]" === tu(e, t) && !r) {
                t++;
                break
            }
            var i = this.fork(t).parse();
            if (ou(o, i), ou(n, i.value), t = this.until([",", "]"], i.end), "," === tu(e, t)) r = !0, t++;
            else if ("]" === tu(e, t)) {
                t++;
                break
            }
        }
        return this.node(1, n, this.index, t, o)
    },
    string: function() {
        var e = this.index,
            t = Ka(this.source, this.index + 1);
        return this.node(0, t.value, e, t.end)
    },
    number: function() {
        var e = this.source,
            t = this.index,
            r = t;
        if ("-" === tu(e, r) && r++, "0" === tu(e, r)) r++;
        else {
            if (!nu(au, tu(e, r))) throw new Qa("Failed to parse number at: " + r);
            r = this.skip(iu, r + 1)
        }
        if (!("." === tu(e, r) && (r = this.skip(iu, r + 1)), "e" !== tu(e, r) && "E" !== tu(e, r) || (r++, "+" !== tu(e, r) && "-" !== tu(e, r) || r++, r !== (r = this.skip(iu, r))))) throw new Qa("Failed to parse number's exponent value at: " + r);
        return this.node(0, $a(ru(e, t, r)), t, r)
    },
    keyword: function(e) {
        var t = "" + e,
            r = this.index,
            n = r + t.length;
        if (ru(this.source, r, n) !== t) throw new Qa("Failed to parse value at: " + r);
        return this.node(0, e, r, n)
    },
    skip: function(e, t) {
        for (var r = this.source; t < r.length && nu(e, tu(r, t)); t++);
        return t
    },
    until: function(e, t) {
        t = this.skip(su, t);
        for (var r = tu(this.source, t), n = 0; n < e.length; n++)
            if (e[n] === r) return t;
        throw new Qa('Unexpected character: "' + r + '" at: ' + t)
    }
};
var hu = s(function() {
        var e, t = "9007199254740993";
        return Ja(t, function(t, r, n) {
            e = n.source
        }), e !== t
    }),
    pu = U && !s(function() {
        return 1 / Ja("-0 \t") != -1 / 0
    });
Zt({
    target: "JSON",
    stat: !0,
    forced: hu
}, {
    parse: function(e, t) {
        return pu && !K(t) ? Ja(e) : function(e, t) {
            e = Hr(e);
            var r = new du(e, 0, ""),
                n = r.parse(),
                o = n.value,
                i = r.skip(su, n.end);
            if (i < e.length) throw new Qa('Unexpected extra character: "' + tu(e, i) + '" after the parsed data at: ' + i);
            return K(t) ? cu({
                "": o
            }, "", t, n) : o
        }(e, t)
    }
});
var vu = !s(function() {
        return Object.isExtensible(Object.preventExtensions({}))
    }),
    yu = mt.set,
    gu = SyntaxError,
    bu = ae("JSON", "parse"),
    mu = ae("Object", "create"),
    wu = ae("Object", "freeze"),
    Eu = h("".charAt),
    _u = "Unacceptable as raw JSON",
    Tu = function(e) {
        return " " === e || "\t" === e || "\n" === e || "\r" === e
    };
Zt({
    target: "JSON",
    stat: !0,
    forced: !La
}, {
    rawJSON: function(e) {
        var t = Hr(e);
        if ("" === t || Tu(Eu(t, 0)) || Tu(Eu(t, t.length - 1))) throw new gu(_u);
        var r = bu(t);
        if ("object" == typeof r && null !== r) throw new gu(_u);
        var n = mu(null);
        return yu(n, {
            type: "RawJSON"
        }), ii(n, "rawJSON", t), vu ? wu(n) : n
    }
});
var Su = h([].slice),
    Au = String,
    Iu = ae("JSON", "stringify"),
    Ou = h(/./.exec),
    Ru = h("".charAt),
    Nu = h("".charCodeAt),
    Pu = h("".replace),
    Mu = h("".slice),
    Du = h([].push),
    xu = h(1.1.toString),
    Cu = /[\uD800-\uDFFF]/g,
    ku = /^[\uD800-\uDBFF]$/,
    Lu = /^[\uDC00-\uDFFF]$/,
    ju = N(),
    Xu = ju.length,
    Uu = !U || s(function() {
        var e = ae("Symbol")("stringify detection");
        return "[null]" !== Iu([e]) || "{}" !== Iu({
            a: e
        }) || "{}" !== Iu(Object(e))
    }),
    Bu = s(function() {
        return '"\\udf06\\ud834"' !== Iu("\udf06\ud834") || '"\\udead"' !== Iu("\udead")
    }),
    Fu = Uu ? function(e, t) {
        var r = Su(arguments),
            n = zu(t);
        if (K(n) || void 0 !== e && !ce(e)) return r[1] = function(e, t) {
            if (K(n) && (t = ie(n, this, Au(e), t)), !ce(t)) return t
        }, Ra(Iu, null, r)
    } : Iu,
    Vu = function(e, t, r) {
        var n = Ru(r, t - 1),
            o = Ru(r, t + 1);
        return Ou(ku, e) && !Ou(Lu, o) || Ou(Lu, e) && !Ou(ku, n) ? "\\u" + xu(Nu(e, 0), 16) : e
    },
    zu = function(e) {
        if (K(e)) return e;
        if (pn(e)) {
            for (var t = e.length, r = [], n = 0; n < t; n++) {
                var o = e[n];
                "string" == typeof o ? Du(r, o) : "number" != typeof o && "Number" !== je(o) && "String" !== je(o) || Du(r, Hr(o))
            }
            var i = r.length,
                a = !0;
            return function(e, t) {
                if (a) return a = !1, t;
                if (pn(this)) return t;
                for (var n = 0; n < i; n++)
                    if (r[n] === e) return t
            }
        }
    };
Iu && Zt({
    target: "JSON",
    stat: !0,
    arity: 3,
    forced: Uu || Bu || !La
}, {
    stringify: function(e, t, r) {
        var n = zu(t),
            o = [],
            i = Fu(e, function(e, t) {
                var r = K(n) ? ie(n, this, Au(e), t) : t;
                return !La && Xa(r) ? ju + (Du(o, r.rawJSON) - 1) : r
            }, r);
        if ("string" != typeof i) return i;
        if (Bu && (i = Pu(i, Cu, Vu)), La) return i;
        for (var a = "", u = i.length, s = 0; s < u; s++) {
            var c = Ru(i, s);
            if ('"' === c) {
                var f = Ka(i, ++s).end - 1,
                    l = Mu(i, s, f);
                a += Mu(l, 0, Xu) === ju ? o[Mu(l, Xu)] : '"' + l + '"', s = f
            } else a += c
        }
        return a
    }
});
var Hu = Map.prototype,
    Wu = {
        Map: Map,
        set: h(Hu.set),
        get: h(Hu.get),
        has: h(Hu.has),
        remove: h(Hu.delete),
        proto: Hu
    },
    Yu = Wu.Map,
    Gu = Wu.has,
    Ku = Wu.get,
    qu = Wu.set,
    $u = h([].push),
    Qu = s(function() {
        return 1 !== Yu.groupBy("ab", function(e) {
            return e
        }).get("a").length
    });
Zt({
    target: "Map",
    stat: !0,
    forced: Qu
}, {
    groupBy: function(e, t) {
        y(e), he(t);
        var r = new Yu,
            n = 0;
        return oa(e, function(e) {
            var o = t(e, n++);
            Gu(r, o) ? $u(Ku(r, o), e) : qu(r, o, [e])
        }), r
    }
});
var Ju = Math.sign || function(e) {
        var t = +e;
        return 0 === t || t != t ? t : t < 0 ? -1 : 1
    },
    Zu = Math.abs,
    es = function(e, t, r, n) {
        var o = +e,
            i = Zu(o),
            a = Ju(o);
        if (i < n) return a * qn(i / n / t) * n * t;
        var u = (1 + t / 2220446049250313e-31) * i,
            s = u - (u - i);
        return s > r || s != s ? a * (1 / 0) : a * s
    };
Zt({
    target: "Math",
    stat: !0
}, {
    f16round: function(e) {
        return es(e, .0009765625, 65504, 6103515625e-14)
    }
});
var ts = RangeError,
    rs = TypeError,
    ns = 1 / 0,
    os = Math.abs,
    is = Math.pow,
    as = h([].push),
    us = is(2, 1023),
    ss = is(2, 53) - 1,
    cs = Number.MAX_VALUE,
    fs = is(2, 971),
    ls = {},
    ds = {},
    hs = {},
    ps = {},
    vs = {},
    ys = function(e, t) {
        var r = e + t;
        return {
            hi: r,
            lo: t - (r - e)
        }
    };
Zt({
    target: "Math",
    stat: !0
}, {
    sumPrecise: function(e) {
        var t = [],
            r = 0,
            n = ps;
        switch (oa(e, function(e) {
            if (++r >= ss) throw new ts("Maximum allowed index exceeded");
            if ("number" != typeof e) throw new rs("Value is not a number");
            n !== ls && (e != e ? n = ls : e === ns ? n = n === ds ? ls : hs : e === -1 / 0 ? n = n === hs ? ls : ds : 0 === e && 1 / e !== ns || n !== ps && n !== vs || (n = vs, as(t, e)))
        }), n) {
            case ls:
                return NaN;
            case ds:
                return -1 / 0;
            case hs:
                return ns;
            case ps:
                return -0
        }
        for (var o, i, a, u, s, c, f = [], l = 0, d = 0; d < t.length; d++) {
            o = t[d];
            for (var h = 0, p = 0; p < f.length; p++) {
                if (i = f[p], os(o) < os(i) && (c = o, o = i, i = c), u = (a = ys(o, i)).hi, s = a.lo, os(u) === ns) {
                    var v = u === ns ? 1 : -1;
                    l += v, os(o = o - v * us - v * us) < os(i) && (c = o, o = i, i = c), u = (a = ys(o, i)).hi, s = a.lo
                }
                0 !== s && (f[h++] = s), o = u
            }
            f.length = h, 0 !== o && as(f, o)
        }
        var y = f.length - 1;
        if (u = 0, s = 0, 0 !== l) {
            var g = y >= 0 ? f[y] : 0;
            if (y--, os(l) > 1 || l > 0 && g > 0 || l < 0 && g < 0) return l > 0 ? ns : -1 / 0;
            if (u = (a = ys(l * us, g / 2)).hi, s = a.lo, s *= 2, os(2 * u) === ns) return u > 0 ? u === us && s === -fs / 2 && y >= 0 && f[y] < 0 ? cs : ns : u === -us && s === fs / 2 && y >= 0 && f[y] > 0 ? -cs : -1 / 0;
            0 !== s && (f[++y] = s, s = 0), u *= 2
        }
        for (; y >= 0 && (u = (a = ys(u, f[y--])).hi, 0 === (s = a.lo)););
        return y >= 0 && (s < 0 && f[y] < 0 || s > 0 && f[y] > 0) && (i = 2 * s) === (o = u + i) - u && (u = o), u
    }
});
var gs = Object.groupBy,
    bs = ae("Object", "create"),
    ms = h([].push),
    ws = !gs || s(function() {
        return 1 !== gs("ab", function(e) {
            return e
        }).a.length
    });
Zt({
    target: "Object",
    stat: !0,
    forced: ws
}, {
    groupBy: function(e, t) {
        y(e), he(t);
        var r = bs(null),
            n = 0;
        return oa(e, function(e) {
            var o = me(t(e, n++));
            o in r ? ms(r[o], e) : ii(r, o, [e])
        }), r
    }
});
var Es = TypeError,
    _s = function(e) {
        var t, r;
        this.promise = new e(function(e, n) {
            if (void 0 !== t || void 0 !== r) throw new Es("Bad Promise constructor");
            t = e, r = n
        }), this.resolve = he(t), this.reject = he(r)
    },
    Ts = function(e) {
        return new _s(e)
    },
    Ss = function(e) {
        try {
            return {
                error: !1,
                value: e()
            }
        } catch (e) {
            return {
                error: !0,
                value: e
            }
        }
    },
    As = a.Promise,
    Is = !1,
    Os = !As || !As.try || Ss(function() {
        As.try(function(e) {
            Is = 8 === e
        }, 8)
    }).error || !Is;
Zt({
    target: "Promise",
    stat: !0,
    forced: Os
}, {
    try: function(e) {
        var t = arguments.length > 1 ? Su(arguments, 1) : [],
            r = Ts(this),
            n = Ss(function() {
                return Ra(he(e), void 0, t)
            });
        return (n.error ? r.reject : r.resolve)(n.value), r.promise
    }
}), Zt({
    target: "Promise",
    stat: !0
}, {
    withResolvers: function() {
        var e = Ts(this);
        return {
            promise: e.promise,
            resolve: e.resolve,
            reject: e.reject
        }
    }
});
var Rs = function() {},
    Ns = ae("Reflect", "construct"),
    Ps = /^\s*(?:class|function)\b/,
    Ms = h(Ps.exec),
    Ds = !Ps.test(Rs),
    xs = function(e) {
        if (!K(e)) return !1;
        try {
            return Ns(Rs, [], e), !0
        } catch (e) {
            return !1
        }
    },
    Cs = function(e) {
        if (!K(e)) return !1;
        switch (ir(e)) {
            case "AsyncFunction":
            case "GeneratorFunction":
            case "AsyncGeneratorFunction":
                return !1
        }
        try {
            return Ds || !!Ms(Ps, st(e))
        } catch (e) {
            return !0
        }
    };
Cs.sham = !0;
var ks, Ls, js = !Ns || s(function() {
        var e;
        return xs(xs.call) || !xs(Object) || !xs(function() {
            e = !0
        }) || e
    }) ? Cs : xs,
    Xs = "USE_FUNCTION_CONSTRUCTOR",
    Us = H("asyncIterator"),
    Bs = a.AsyncIterator,
    Fs = S.AsyncIteratorPrototype;
if (Fs) ks = Fs;
else if (K(Bs)) ks = Bs.prototype;
else if (S[Xs] || a[Xs]) try {
    Ls = br(br(br(Function("return async function*(){}()")()))), br(Ls) === Object.prototype && (ks = Ls)
} catch (e) {}
ks || (ks = {}), K(ks[Us]) || Et(ks, Us, function() {
    return this
});
var Vs = ks,
    zs = ae("Promise"),
    Hs = "AsyncFromSyncIterator",
    Ws = mt.set,
    Ys = mt.getterFor(Hs),
    Gs = function(e, t, r, n, o) {
        var i = e.done;
        zs.resolve(e.value).then(function(e) {
            t(_i(e, i))
        }, function(e) {
            if (!i && o) try {
                Ti(n, "throw", e)
            } catch (t) {
                e = t
            }
            r(e)
        })
    },
    Ks = function(e) {
        e.type = Hs, Ws(this, e)
    };
Ks.prototype = Xo(Cr(Vs), {
    next: function() {
        var e = Ys(this);
        return new zs(function(t, r) {
            var n = ne(ie(e.next, e.iterator));
            Gs(n, t, r, e.iterator, !0)
        })
    },
    return: function() {
        var e = Ys(this).iterator;
        return new zs(function(t, r) {
            var n = pe(e, "return");
            if (void 0 === n) return t(_i(void 0, !0));
            var o = ne(ie(n, e));
            Gs(o, t, r, e)
        })
    }
});
var qs = Ks,
    $s = H("asyncIterator"),
    Qs = function(e, t, r, n) {
        try {
            var o = pe(e, "return");
            if (o) return ae("Promise").resolve(ie(o, e)).then(function() {
                t(r)
            }, function(e) {
                n(e)
            })
        } catch (e) {
            return n(e)
        }
        t(r)
    },
    Js = function(e) {
        var t = 0 === e,
            r = 1 === e,
            n = 2 === e,
            o = 3 === e;
        return function(e, i, a) {
            ne(e);
            var u = void 0 !== i;
            !u && t || he(i);
            var s = Bi(e),
                c = ae("Promise"),
                f = s.iterator,
                l = s.next,
                d = 0;
            return new c(function(e, s) {
                var h = function(e) {
                        Qs(f, s, e, s)
                    },
                    p = function() {
                        try {
                            if (u) try {
                                mn(d)
                            } catch (e) {
                                h(e)
                            }
                            c.resolve(ne(ie(l, f))).then(function(l) {
                                try {
                                    if (ne(l).done) t ? (a.length = d, e(a)) : e(!o && (n || void 0));
                                    else {
                                        var v = l.value;
                                        try {
                                            if (u) {
                                                var y = i(v, d),
                                                    g = function(i) {
                                                        if (r) p();
                                                        else if (n) i ? p() : Qs(f, e, !1, s);
                                                        else if (t) try {
                                                            a[d++] = i, p()
                                                        } catch (e) {
                                                            h(e)
                                                        } else i ? Qs(f, e, o || v, s) : p()
                                                    };
                                                q(y) ? c.resolve(y).then(g, h) : g(y)
                                            } else a[d++] = v, p()
                                        } catch (e) {
                                            h(e)
                                        }
                                    }
                                } catch (e) {
                                    s(e)
                                }
                            }, s)
                        } catch (e) {
                            s(e)
                        }
                    };
                p()
            })
        }
    },
    Zs = {
        toArray: Js(0),
        forEach: Js(1),
        every: Js(2),
        some: Js(3),
        find: Js(4)
    },
    ec = Zs.toArray,
    tc = H("asyncIterator"),
    rc = h(Sn("Array", "values")),
    nc = h(rc([]).next),
    oc = function() {
        return new ic(this)
    },
    ic = function(e) {
        this.iterator = rc(e)
    };
ic.prototype.next = function() {
    return nc(this.iterator)
};
var ac = function(e) {
        var t = this,
            r = arguments.length,
            n = r > 1 ? arguments[1] : void 0,
            o = r > 2 ? arguments[2] : void 0;
        return new(ae("Promise"))(function(r) {
            var i = b(e);
            void 0 !== n && (n = rn(n, o));
            var a = pe(i, tc),
                u = a ? void 0 : Ei(i) || oc,
                s = js(t) ? new t : [],
                c = a ? function(e, t) {
                    var r = arguments.length < 2 ? pe(e, $s) : t;
                    return r ? ne(ie(r, e)) : new qs(Bi(ea(e)))
                }(i, a) : new qs(Bi(ea(i, u)));
            r(ec(c, n, s))
        })
    },
    uc = Array.fromAsync,
    sc = !uc || s(function() {
        var e = 0;
        return uc.call(function() {
            return e++, []
        }, {
            length: 0
        }), 1 !== e
    });
Zt({
    target: "Array",
    stat: !0,
    forced: sc
}, {
    fromAsync: ac
});
var cc = ae("Promise"),
    fc = ae("SuppressedError"),
    lc = ReferenceError,
    dc = H("asyncDispose"),
    hc = H("toStringTag"),
    pc = "AsyncDisposableStack",
    vc = mt.set,
    yc = mt.getterFor(pc),
    gc = "async-dispose",
    bc = "disposed",
    mc = function(e) {
        var t = yc(e);
        if (t.state === bc) throw new lc(pc + " already disposed");
        return t
    },
    wc = function() {
        vc(jo(this, Ec), {
            type: pc,
            state: "pending",
            stack: []
        }), Y || (this.disposed = !1)
    },
    Ec = wc.prototype;
Xo(Ec, {
    disposeAsync: function() {
        var e = this;
        return new cc(function(t, r) {
            var n = yc(e);
            if (n.state === bc) return t(void 0);
            n.state = bc, Y || (e.disposed = !0);
            var o, i = n.stack,
                a = i.length,
                u = !1,
                s = function(e) {
                    u ? o = new fc(e, o) : (u = !0, o = e), c()
                },
                c = function() {
                    if (a) {
                        var e = i[--a];
                        i[a] = null;
                        try {
                            cc.resolve(e()).then(c, s)
                        } catch (e) {
                            s(e)
                        }
                    } else n.stack = null, u ? r(o) : t(void 0)
                };
            c()
        })
    },
    use: function(e) {
        return zo(mc(this), e, gc), e
    },
    adopt: function(e, t) {
        var r = mc(this);
        return he(t), zo(r, void 0, gc, function() {
            return t(e)
        }), e
    },
    defer: function(e) {
        var t = mc(this);
        he(e), zo(t, void 0, gc, e)
    },
    move: function() {
        var e = mc(this),
            t = new wc;
        return yc(t).stack = e.stack, e.stack = [], e.state = bc, Y || (this.disposed = !0), t
    }
}), Y && Zn(Ec, "disposed", {
    configurable: !0,
    get: function() {
        return yc(this).state === bc
    }
}), Et(Ec, dc, Ec.disposeAsync, {
    name: "disposeAsync"
}), Et(Ec, hc, pc, {
    nonWritable: !0
}), Zt({
    global: !0,
    constructor: !0,
    forced: j && j < 136
}, {
    AsyncDisposableStack: wc
});
var _c = H("asyncDispose"),
    Tc = ae("Promise");
w(Vs, _c) || Et(Vs, _c, function() {
    var e = this;
    return new Tc(function(t, r) {
        var n = pe(e, "return");
        n ? Tc.resolve(ie(n, e)).then(function() {
            t(void 0)
        }, r) : t(void 0)
    })
});
var Sc = TypeError,
    Ac = function(e) {
        if ("string" == typeof e) return e;
        throw new Sc("Argument is not a string")
    },
    Ic = RangeError,
    Oc = h(function(e) {
        var t = Hr(y(this)),
            r = "",
            n = At(e);
        if (n < 0 || n === 1 / 0) throw new Ic("Wrong number of repetitions");
        for (; n > 0;
            (n >>>= 1) && (t += t)) 1 & n && (r += t);
        return r
    }),
    Rc = h("".slice),
    Nc = Math.ceil,
    Pc = function(e) {
        return function(t, r, n) {
            var o, i, a = Hr(y(t)),
                u = Pt(r),
                s = a.length,
                c = void 0 === n ? " " : Hr(n);
            return u <= s || "" === c ? a : ((i = Oc(c, Nc((o = u - s) / c.length))).length > o && (i = Rc(i, 0, o)), e ? a + i : i + a)
        }
    },
    Mc = "\t\n\v\f\r                　\u2028\u2029\ufeff",
    Dc = [Pc(!1), Pc(!0)][0],
    xc = Array,
    Cc = RegExp.escape,
    kc = h("".charAt),
    Lc = h("".charCodeAt),
    jc = h(1.1.toString),
    Xc = h([].join),
    Uc = /^[0-9a-z]/i,
    Bc = /^[$()*+./?[\\\]^{|}]/,
    Fc = RegExp("^[!\"#%&',\\-:;<=>@`~" + Mc + "]"),
    Vc = h(Uc.exec),
    zc = {
        "\t": "t",
        "\n": "n",
        "\v": "v",
        "\f": "f",
        "\r": "r"
    },
    Hc = function(e) {
        var t = jc(Lc(e, 0), 16);
        return t.length < 3 ? "\\x" + Dc(t, 2, "0") : "\\u" + Dc(t, 4, "0")
    },
    Wc = !Cc || "\\x61b" !== Cc("ab");
Zt({
    target: "RegExp",
    stat: !0,
    forced: Wc
}, {
    escape: function(e) {
        Ac(e);
        for (var t = e.length, r = xc(t), n = 0; n < t; n++) {
            var o = kc(e, n);
            if (0 === n && Vc(Uc, o)) r[n] = Hc(o);
            else if (w(zc, o)) r[n] = "\\" + zc[o];
            else if (Vc(Bc, o)) r[n] = "\\" + o;
            else if (Vc(Fc, o)) r[n] = Hc(o);
            else {
                var i = Lc(o, 0);
                55296 != (63488 & i) ? r[n] = o : i >= 56320 || n + 1 >= t || 56320 != (64512 & Lc(e, n + 1)) ? r[n] = Hc(o) : (r[n] = o, r[++n] = kc(e, n))
            }
        }
        return Xc(r, "")
    }
});
var Yc = a.RegExp,
    Gc = !s(function() {
        var e = !0;
        try {
            Yc(".", "d")
        } catch (t) {
            e = !1
        }
        var t = {},
            r = "",
            n = e ? "dgimsy" : "gimsy",
            o = function(e, n) {
                Object.defineProperty(t, e, {
                    get: function() {
                        return r += n, !0
                    }
                })
            },
            i = {
                dotAll: "s",
                global: "g",
                ignoreCase: "i",
                multiline: "m",
                sticky: "y"
            };
        for (var a in e && (i.hasIndices = "d"), i) o(a, i[a]);
        return Object.getOwnPropertyDescriptor(Yc.prototype, "flags").get.call(t) !== n || r !== n
    }),
    Kc = {
        correct: Gc
    },
    qc = function() {
        var e = ne(this),
            t = "";
        return e.hasIndices && (t += "d"), e.global && (t += "g"), e.ignoreCase && (t += "i"), e.multiline && (t += "m"), e.dotAll && (t += "s"), e.unicode && (t += "u"), e.unicodeSets && (t += "v"), e.sticky && (t += "y"), t
    };
Y && !Kc.correct && (Zn(RegExp.prototype, "flags", {
    configurable: !0,
    get: qc
}), Kc.correct = !0);
var $c = Set.prototype,
    Qc = {
        Set: Set,
        add: h($c.add),
        has: h($c.has),
        remove: h($c.delete),
        proto: $c
    },
    Jc = Qc.has,
    Zc = function(e) {
        return Jc(e), e
    },
    ef = function(e, t, r) {
        for (var n, o, i = r ? e : e.iterator, a = e.next; !(n = ie(a, i)).done;)
            if (void 0 !== (o = t(n.value))) return o
    },
    tf = Qc.Set,
    rf = Qc.proto,
    nf = h(rf.forEach),
    of = h(rf.keys),
    af = of (new tf).next,
    uf = function(e, t, r) {
        return r ? ef({
            iterator: of (e),
            next: af
        }, t) : nf(e, t)
    },
    sf = Qc.Set,
    cf = Qc.add,
    ff = function(e) {
        var t = new sf;
        return uf(e, function(e) {
            cf(t, e)
        }), t
    },
    lf = mr(Qc.proto, "size", "get") || function(e) {
        return e.size
    },
    df = "Invalid size",
    hf = RangeError,
    pf = TypeError,
    vf = Math.max,
    yf = function(e, t) {
        this.set = e, this.size = vf(t, 0), this.has = he(e.has), this.keys = he(e.keys)
    };
yf.prototype = {
    getIterator: function() {
        return Bi(ne(ie(this.keys, this.set)))
    },
    includes: function(e) {
        return ie(this.has, this.set, e)
    }
};
var gf = function(e) {
        ne(e);
        var t = +e.size;
        if (t != t) throw new pf(df);
        var r = At(t);
        if (r < 0) throw new hf(df);
        return new yf(e, r)
    },
    bf = Qc.has,
    mf = Qc.remove,
    wf = function(e) {
        var t = Zc(this),
            r = gf(e),
            n = ff(t);
        return lf(t) <= r.size ? uf(t, function(e) {
            r.includes(e) && mf(n, e)
        }) : ef(r.getIterator(), function(e) {
            bf(n, e) && mf(n, e)
        }), n
    },
    Ef = function(e) {
        return {
            size: e,
            has: function() {
                return !1
            },
            keys: function() {
                return {
                    next: function() {
                        return {
                            done: !0
                        }
                    }
                }
            }
        }
    },
    _f = function(e) {
        return {
            size: e,
            has: function() {
                return !0
            },
            keys: function() {
                throw new Error("e")
            }
        }
    },
    Tf = function(e, t) {
        var r = ae("Set");
        try {
            (new r)[e](Ef(0));
            try {
                return (new r)[e](Ef(-1)), !1
            } catch (n) {
                if (!t) return !0;
                try {
                    return (new r)[e](_f(-1 / 0)), !1
                } catch (n) {
                    return t(new r([1, 2])[e](_f(1 / 0)))
                }
            }
        } catch (e) {
            return !1
        }
    },
    Sf = !Tf("difference", function(e) {
        return 0 === e.size
    }),
    Af = Sf || s(function() {
        var e = {
                size: 1,
                has: function() {
                    return !0
                },
                keys: function() {
                    var e = 0;
                    return {
                        next: function() {
                            var r = e++ > 1;
                            return t.has(1) && t.clear(), {
                                done: r,
                                value: 2
                            }
                        }
                    }
                }
            },
            t = new Set([1, 2, 3, 4]);
        return 3 !== t.difference(e).size
    });
Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: Af
}, {
    difference: wf
});
var If = Qc.Set,
    Of = Qc.add,
    Rf = Qc.has,
    Nf = function(e) {
        var t = Zc(this),
            r = gf(e),
            n = new If;
        return lf(t) > r.size ? ef(r.getIterator(), function(e) {
            Rf(t, e) && Of(n, e)
        }) : uf(t, function(e) {
            r.includes(e) && Of(n, e)
        }), n
    },
    Pf = !Tf("intersection", function(e) {
        return 2 === e.size && e.has(1) && e.has(2)
    }) || s(function() {
        return "3,2" !== String(Array.from(new Set([1, 2, 3]).intersection(new Set([3, 2]))))
    });
Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: Pf
}, {
    intersection: Nf
});
var Mf = Qc.has,
    Df = function(e) {
        var t = Zc(this),
            r = gf(e);
        if (lf(t) <= r.size) return !1 !== uf(t, function(e) {
            if (r.includes(e)) return !1
        }, !0);
        var n = r.getIterator();
        return !1 !== ef(n, function(e) {
            if (Mf(t, e)) return Ti(n, "normal", !1)
        })
    },
    xf = !Tf("isDisjointFrom", function(e) {
        return !e
    });
Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: xf
}, {
    isDisjointFrom: Df
});
var Cf = function(e) {
        var t = Zc(this),
            r = gf(e);
        return !(lf(t) > r.size) && !1 !== uf(t, function(e) {
            if (!r.includes(e)) return !1
        }, !0)
    },
    kf = !Tf("isSubsetOf", function(e) {
        return e
    });
Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: kf
}, {
    isSubsetOf: Cf
});
var Lf = Qc.has,
    jf = function(e) {
        var t = Zc(this),
            r = gf(e);
        if (lf(t) < r.size) return !1;
        var n = r.getIterator();
        return !1 !== ef(n, function(e) {
            if (!Lf(t, e)) return Ti(n, "normal", !1)
        })
    },
    Xf = !Tf("isSupersetOf", function(e) {
        return !e
    });
Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: Xf
}, {
    isSupersetOf: jf
});
var Uf = Qc.add,
    Bf = Qc.has,
    Ff = Qc.remove,
    Vf = function(e) {
        var t = Zc(this),
            r = gf(e).getIterator(),
            n = ff(t);
        return ef(r, function(e) {
            Bf(t, e) ? Ff(n, e) : Uf(n, e)
        }), n
    },
    zf = function(e) {
        try {
            var t = new Set,
                r = {
                    size: 0,
                    has: function() {
                        return !0
                    },
                    keys: function() {
                        return Object.defineProperty({}, "next", {
                            get: function() {
                                return t.clear(), t.add(4),
                                    function() {
                                        return {
                                            done: !0
                                        }
                                    }
                            }
                        })
                    }
                },
                n = t[e](r);
            return 1 === n.size && 4 === n.values().next().value
        } catch (e) {
            return !1
        }
    },
    Hf = !Tf("symmetricDifference") || !zf("symmetricDifference");
Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: Hf
}, {
    symmetricDifference: Vf
});
var Wf = Qc.add,
    Yf = function(e) {
        var t = Zc(this),
            r = gf(e).getIterator(),
            n = ff(t);
        return ef(r, function(e) {
            Wf(n, e)
        }), n
    },
    Gf = !Tf("union") || !zf("union");
Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: Gf
}, {
    union: Yf
});
var Kf = h("".charCodeAt);
Zt({
    target: "String",
    proto: !0
}, {
    isWellFormed: function() {
        for (var e = Hr(y(this)), t = e.length, r = 0; r < t; r++) {
            var n = Kf(e, r);
            if (55296 == (63488 & n) && (n >= 56320 || ++r >= t || 56320 != (64512 & Kf(e, r)))) return !1
        }
        return !0
    }
});
var qf = Array,
    $f = h("".charAt),
    Qf = h("".charCodeAt),
    Jf = h([].join),
    Zf = "".toWellFormed,
    el = Zf && s(function() {
        return "1" !== ie(Zf, 1)
    });
Zt({
    target: "String",
    proto: !0,
    forced: el
}, {
    toWellFormed: function() {
        var e = Hr(y(this));
        if (el) return ie(Zf, e);
        for (var t = e.length, r = qf(t), n = 0; n < t; n++) {
            var o = Qf(e, n);
            55296 != (63488 & o) ? r[n] = $f(e, n) : o >= 56320 || n + 1 >= t || 56320 != (64512 & Qf(e, n + 1)) ? r[n] = "�" : (r[n] = $f(e, n), r[++n] = $f(e, n))
        }
        return Jf(r, "")
    }
});
var tl, rl, nl, ol = mt.enforce,
    il = mt.get,
    al = a.Int8Array,
    ul = al && al.prototype,
    sl = a.Uint8ClampedArray,
    cl = sl && sl.prototype,
    fl = al && br(al),
    ll = ul && br(ul),
    dl = Object.prototype,
    hl = a.TypeError,
    pl = H("toStringTag"),
    vl = N("TYPED_ARRAY_TAG"),
    yl = "TypedArrayConstructor",
    gl = eo && !!_r && "Opera" !== ir(a.opera),
    bl = !1,
    ml = {
        Int8Array: 1,
        Uint8Array: 1,
        Uint8ClampedArray: 1,
        Int16Array: 2,
        Uint16Array: 2,
        Int32Array: 4,
        Uint32Array: 4,
        Float32Array: 4,
        Float64Array: 8
    },
    wl = {
        BigInt64Array: 8,
        BigUint64Array: 8
    },
    El = function(e) {
        var t = br(e);
        if (q(t)) {
            var r = il(t);
            return r && w(r, yl) ? r[yl] : El(t)
        }
    },
    _l = function(e) {
        if (!q(e)) return !1;
        var t = ir(e);
        return w(ml, t) || w(wl, t)
    };
for (tl in ml)(nl = (rl = a[tl]) && rl.prototype) ? ol(nl)[yl] = rl : gl = !1;
for (tl in wl)(nl = (rl = a[tl]) && rl.prototype) && (ol(nl)[yl] = rl);
if ((!gl || !K(fl) || fl === Function.prototype) && (fl = function() {
        throw new hl("Incorrect invocation")
    }, gl))
    for (tl in ml) a[tl] && _r(a[tl], fl);
if ((!gl || !ll || ll === dl) && (ll = fl.prototype, gl))
    for (tl in ml) a[tl] && _r(a[tl].prototype, ll);
if (gl && br(cl) !== ll && _r(cl, ll), Y && !w(ll, pl))
    for (tl in bl = !0, Zn(ll, pl, {
            configurable: !0,
            get: function() {
                return q(this) ? this[vl] : void 0
            }
        }), ml) a[tl] && Ze(a[tl], vl, tl);
var Tl = {
        NATIVE_ARRAY_BUFFER_VIEWS: gl,
        TYPED_ARRAY_TAG: bl && vl,
        aTypedArray: function(e) {
            if (_l(e)) return e;
            throw new hl("Target is not a typed array")
        },
        aTypedArrayConstructor: function(e) {
            if (K(e) && (!_r || ue(fl, e))) return e;
            throw new hl(le(e) + " is not a typed array constructor")
        },
        exportTypedArrayMethod: function(e, t, r, n) {
            if (Y) {
                if (r)
                    for (var o in ml) {
                        var i = a[o];
                        if (i && w(i.prototype, e)) try {
                            delete i.prototype[e]
                        } catch (r) {
                            try {
                                i.prototype[e] = t
                            } catch (e) {}
                        }
                    }
                ll[e] && !r || Et(ll, e, r ? t : gl && ul[e] || t, n)
            }
        },
        exportTypedArrayStaticMethod: function(e, t, r) {
            var n, o;
            if (Y) {
                if (_r) {
                    if (r)
                        for (n in ml)
                            if ((o = a[n]) && w(o, e)) try {
                                delete o[e]
                            } catch (e) {}
                    if (fl[e] && !r) return;
                    try {
                        return Et(fl, e, r ? t : gl && fl[e] || t)
                    } catch (e) {}
                }
                for (n in ml) !(o = a[n]) || o[e] && !r || Et(o, e, t)
            }
        },
        getTypedArrayConstructor: El,
        isView: function(e) {
            if (!q(e)) return !1;
            var t = ir(e);
            return "DataView" === t || w(ml, t) || w(wl, t)
        },
        isTypedArray: _l,
        TypedArray: fl,
        TypedArrayPrototype: ll
    },
    Sl = on.findLast,
    Al = Tl.aTypedArray;
(0, Tl.exportTypedArrayMethod)("findLast", function(e) {
    return Sl(Al(this), e, arguments.length > 1 ? arguments[1] : void 0)
});
var Il = on.findLastIndex,
    Ol = Tl.aTypedArray;
(0, Tl.exportTypedArrayMethod)("findLastIndex", function(e) {
    return Il(Ol(this), e, arguments.length > 1 ? arguments[1] : void 0)
});
var Rl = Tl.aTypedArray,
    Nl = Tl.getTypedArrayConstructor;
(0, Tl.exportTypedArrayMethod)("toReversed", function() {
    return En(Rl(this), Nl(this))
});
var Pl = Tl.aTypedArray,
    Ml = Tl.getTypedArrayConstructor,
    Dl = Tl.exportTypedArrayMethod,
    xl = h(Tl.TypedArrayPrototype.sort);
Dl("toSorted", function(e) {
    void 0 !== e && he(e);
    var t = Pl(this),
        r = Tn(Ml(t), t);
    return xl(r, e)
});
var Cl = function(e) {
        var t = ir(e);
        return "BigInt64Array" === t || "BigUint64Array" === t
    },
    kl = TypeError,
    Ll = function(e) {
        var t = be(e, "number");
        if ("number" == typeof t) throw new kl("Can't convert number to bigint");
        return BigInt(t)
    },
    jl = Tl.aTypedArray,
    Xl = Tl.getTypedArrayConstructor,
    Ul = Tl.exportTypedArrayMethod,
    Bl = function() {
        try {
            new Int8Array(1).with(2, {
                valueOf: function() {
                    throw 8
                }
            })
        } catch (e) {
            return 8 === e
        }
    }(),
    Fl = Bl && function() {
        try {
            new Int8Array(1).with(-.5, 1)
        } catch (e) {
            return !0
        }
    }();
Ul("with", {
    with: function(e, t) {
        var r = jl(this),
            n = At(e),
            o = Cl(r) ? Ll(t) : +t;
        return Cn(r, Xl(r), n, o)
    }
}.with, !Bl || Fl);
var Vl = String,
    zl = TypeError,
    Hl = function(e) {
        if (void 0 === e || q(e)) return e;
        throw new zl(Vl(e) + " is not an object or undefined")
    },
    Wl = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
    Yl = Wl + "+/",
    Gl = Wl + "-_",
    Kl = function(e) {
        for (var t = {}, r = 0; r < 64; r++) t[e.charAt(r)] = r;
        return t
    },
    ql = {
        i2c: Yl,
        c2i: Kl(Yl),
        i2cUrl: Gl,
        c2iUrl: Kl(Gl)
    },
    $l = TypeError,
    Ql = function(e) {
        var t = e && e.alphabet;
        if (void 0 === t || "base64" === t || "base64url" === t) return t || "base64";
        throw new $l("Incorrect `alphabet` option")
    },
    Jl = ql.c2i,
    Zl = ql.c2iUrl,
    ed = a.SyntaxError,
    td = a.TypeError,
    rd = h("".charAt),
    nd = function(e, t) {
        for (var r = e.length; t < r; t++) {
            var n = rd(e, t);
            if (" " !== n && "\t" !== n && "\n" !== n && "\f" !== n && "\r" !== n) break
        }
        return t
    },
    od = function(e, t, r) {
        var n = e.length;
        n < 4 && (e += 2 === n ? "AA" : "A");
        var o = (t[rd(e, 0)] << 18) + (t[rd(e, 1)] << 12) + (t[rd(e, 2)] << 6) + t[rd(e, 3)],
            i = [o >> 16 & 255, o >> 8 & 255, 255 & o];
        if (2 === n) {
            if (r && 0 !== i[1]) throw new ed("Extra bits");
            return [i[0]]
        }
        if (3 === n) {
            if (r && 0 !== i[2]) throw new ed("Extra bits");
            return [i[0], i[1]]
        }
        return i
    },
    id = function(e, t, r) {
        for (var n = t.length, o = 0; o < n; o++) e[r + o] = t[o];
        return r + n
    },
    ad = function(e, t, r, n) {
        Ac(e), Hl(t);
        var o = "base64" === Ql(t) ? Jl : Zl,
            i = t ? t.lastChunkHandling : void 0;
        if (void 0 === i && (i = "loose"), "loose" !== i && "strict" !== i && "stop-before-partial" !== i) throw new td("Incorrect `lastChunkHandling` option");
        r && ho(r.buffer);
        var a = e.length,
            u = r || [],
            s = 0,
            c = 0,
            f = "",
            l = 0;
        if (n)
            for (;;) {
                if ((l = nd(e, l)) === a) {
                    if (f.length > 0) {
                        if ("stop-before-partial" === i) break;
                        if ("loose" !== i) throw new ed("Missing padding");
                        if (1 === f.length) throw new ed("Malformed padding: exactly one additional character");
                        s = id(u, od(f, o, !1), s)
                    }
                    c = a;
                    break
                }
                var d = rd(e, l);
                if (++l, "=" === d) {
                    if (f.length < 2) throw new ed("Padding is too early");
                    if (l = nd(e, l), 2 === f.length) {
                        if (l === a) {
                            if ("stop-before-partial" === i) break;
                            throw new ed("Malformed padding: only one =")
                        }
                        "=" === rd(e, l) && (++l, l = nd(e, l))
                    }
                    if (l < a) throw new ed("Unexpected character after padding");
                    s = id(u, od(f, o, "strict" === i), s), c = a;
                    break
                }
                if (!w(o, d)) throw new ed("Unexpected character");
                var h = n - s;
                if (1 === h && 2 === f.length || 2 === h && 3 === f.length) break;
                if (4 === (f += d).length && (s = id(u, od(f, o, !1), s), f = "", c = l, s === n)) break
            }
        return {
            bytes: u,
            read: c,
            written: s
        }
    },
    ud = a.Uint8Array,
    sd = !ud || !ud.fromBase64 || ! function() {
        try {
            return void ud.fromBase64("a")
        } catch (e) {}
        try {
            ud.fromBase64("", null)
        } catch (e) {
            return !0
        }
    }();
ud && Zt({
    target: "Uint8Array",
    stat: !0,
    forced: sd
}, {
    fromBase64: function(e) {
        var t = ad(e, arguments.length > 1 ? arguments[1] : void 0, null, 9007199254740991);
        return Tn(ud, t.bytes)
    }
});
var cd = a.Uint8Array,
    fd = a.SyntaxError,
    ld = a.parseInt,
    dd = Math.min,
    hd = /[^\da-f]/i,
    pd = h(hd.exec),
    vd = h("".slice),
    yd = function(e, t) {
        var r = e.length;
        if (r % 2 != 0) throw new fd("String should be an even number of characters");
        for (var n = t ? dd(t.length, r / 2) : r / 2, o = t || new cd(n), i = 0, a = 0; a < n;) {
            var u = vd(e, i, i += 2);
            if (pd(hd, u)) throw new fd("String should only contain hex characters");
            o[a++] = ld(u, 16)
        }
        return {
            bytes: o,
            read: i
        }
    };
a.Uint8Array && Zt({
    target: "Uint8Array",
    stat: !0
}, {
    fromHex: function(e) {
        return yd(Ac(e)).bytes
    }
});
var gd = TypeError,
    bd = function(e) {
        if ("Uint8Array" === ir(e)) return e;
        throw new gd("Argument is not an Uint8Array")
    },
    md = a.Uint8Array,
    wd = !md || !md.prototype.setFromBase64 || ! function() {
        var e = new md([255, 255, 255, 255, 255]);
        try {
            return void e.setFromBase64("", null)
        } catch (e) {}
        try {
            return void e.setFromBase64("a")
        } catch (e) {}
        try {
            e.setFromBase64("MjYyZg===")
        } catch (t) {
            return 50 === e[0] && 54 === e[1] && 50 === e[2] && 255 === e[3] && 255 === e[4]
        }
    }();
md && Zt({
    target: "Uint8Array",
    proto: !0,
    forced: wd
}, {
    setFromBase64: function(e) {
        bd(this);
        var t = ad(e, arguments.length > 1 ? arguments[1] : void 0, this, this.length);
        return {
            read: t.read,
            written: t.written
        }
    }
}), a.Uint8Array && Zt({
    target: "Uint8Array",
    proto: !0
}, {
    setFromHex: function(e) {
        bd(this), Ac(e), ho(this.buffer);
        var t = yd(e, this).read;
        return {
            read: t,
            written: t / 2
        }
    }
});
var Ed = ql.i2c,
    _d = ql.i2cUrl,
    Td = h("".charAt),
    Sd = a.Uint8Array,
    Ad = !Sd || !Sd.prototype.toBase64 || ! function() {
        try {
            (new Sd).toBase64(null)
        } catch (e) {
            return !0
        }
    }();
Sd && Zt({
    target: "Uint8Array",
    proto: !0,
    forced: Ad
}, {
    toBase64: function() {
        var e = bd(this),
            t = arguments.length ? Hl(arguments[0]) : void 0,
            r = "base64" === Ql(t) ? Ed : _d,
            n = !!t && !!t.omitPadding;
        ho(this.buffer);
        for (var o, i = "", a = 0, u = e.length, s = function(e) {
                return Td(r, o >> 6 * e & 63)
            }; a + 2 < u; a += 3) o = (e[a] << 16) + (e[a + 1] << 8) + e[a + 2], i += s(3) + s(2) + s(1) + s(0);
        return a + 2 === u ? (o = (e[a] << 16) + (e[a + 1] << 8), i += s(3) + s(2) + s(1) + (n ? "" : "=")) : a + 1 === u && (o = e[a] << 16, i += s(3) + s(2) + (n ? "" : "==")), i
    }
});
var Id = h(1.1.toString),
    Od = a.Uint8Array,
    Rd = !Od || !Od.prototype.toHex || ! function() {
        try {
            return "ffffffffffffffff" === new Od([255, 255, 255, 255, 255, 255, 255, 255]).toHex()
        } catch (e) {
            return !1
        }
    }();
Od && Zt({
    target: "Uint8Array",
    proto: !0,
    forced: Rd
}, {
    toHex: function() {
        bd(this), ho(this.buffer);
        for (var e = "", t = 0, r = this.length; t < r; t++) {
            var n = Id(this[t], 16);
            e += 1 === n.length ? "0" + n : n
        }
        return e
    }
});
var Nd = H("species"),
    Pd = Array,
    Md = function(e, t) {
        return new(function(e) {
            var t;
            return pn(e) && (t = e.constructor, (js(t) && (t === Pd || pn(t.prototype)) || q(t) && null === (t = t[Nd])) && (t = void 0)), void 0 === t ? Pd : t
        }(e))(0 === t ? 0 : t)
    },
    Dd = h([].push),
    xd = function(e) {
        var t = 1 === e,
            r = 2 === e,
            n = 3 === e,
            o = 4 === e,
            i = 6 === e,
            a = 7 === e,
            u = 5 === e || i;
        return function(s, c, f, l) {
            for (var d, h, p = b(s), v = Be(p), y = Mt(v), g = rn(c, f), m = 0, w = l || Md, E = t ? w(s, y) : r || a ? w(s, 0) : void 0; y > m; m++)
                if ((u || m in v) && (h = g(d = v[m], m, p), e))
                    if (t) E[m] = h;
                    else if (h) switch (e) {
                case 3:
                    return !0;
                case 5:
                    return d;
                case 6:
                    return m;
                case 2:
                    Dd(E, d)
            } else switch (e) {
                case 4:
                    return !1;
                case 7:
                    Dd(E, d)
            }
            return i ? -1 : n || o ? o : E
        }
    },
    Cd = {
        forEach: xd(0),
        map: xd(1),
        filter: xd(2),
        some: xd(3),
        every: xd(4),
        find: xd(5),
        findIndex: xd(6),
        filterReject: xd(7)
    },
    kd = Cd.filterReject;
Zt({
    target: "Array",
    proto: !0,
    forced: !0
}, {
    filterOut: function(e) {
        return kd(this, e, arguments.length > 1 ? arguments[1] : void 0)
    }
}), cn("filterOut");
var Ld = Cd.filterReject;
Zt({
    target: "Array",
    proto: !0,
    forced: !0
}, {
    filterReject: function(e) {
        return Ld(this, e, arguments.length > 1 ? arguments[1] : void 0)
    }
}), cn("filterReject");
var jd = Array,
    Xd = h([].push),
    Ud = function(e, t, r, n) {
        for (var o, i, a, u = b(e), s = Be(u), c = rn(t, r), f = Cr(null), l = Mt(s), d = 0; l > d; d++) a = s[d], (i = me(c(a, d, u))) in f ? Xd(f[i], a) : f[i] = [a];
        if (n && (o = n(u)) !== jd)
            for (i in f) f[i] = Tn(o, f[i]);
        return f
    };
Zt({
    target: "Array",
    proto: !0
}, {
    group: function(e) {
        return Ud(this, e, arguments.length > 1 ? arguments[1] : void 0)
    }
}), cn("group");
var Bd = function(e, t) {
    var r = [][e];
    return !!r && s(function() {
        r.call(null, t || function() {
            return 1
        }, 1)
    })
};
Zt({
    target: "Array",
    proto: !0,
    forced: !Bd("groupBy")
}, {
    groupBy: function(e) {
        return Ud(this, e, arguments.length > 1 ? arguments[1] : void 0)
    }
}), cn("groupBy");
var Fd = Wu.Map,
    Vd = Wu.get,
    zd = Wu.has,
    Hd = Wu.set,
    Wd = h([].push),
    Yd = function(e) {
        for (var t, r, n = b(this), o = Be(n), i = rn(e, arguments.length > 1 ? arguments[1] : void 0), a = new Fd, u = Mt(o), s = 0; u > s; s++) t = i(r = o[s], s, n), zd(a, t) ? Wd(Vd(a, t), r) : Hd(a, t, [r]);
        return a
    };
Zt({
    target: "Array",
    proto: !0,
    name: "groupToMap",
    forced: !Bd("groupByToMap")
}, {
    groupByToMap: Yd
}), cn("groupByToMap"), Zt({
    target: "Array",
    proto: !0,
    forced: E
}, {
    groupToMap: Yd
}), cn("groupToMap");
var Gd = Object.isFrozen,
    Kd = function(e, t) {
        if (!Gd || !pn(e) || !Gd(e)) return !1;
        for (var r, n = 0, o = e.length; n < o;)
            if (!("string" == typeof(r = e[n++]) || t && void 0 === r)) return !1;
        return 0 !== o
    };
Zt({
    target: "Array",
    stat: !0,
    sham: !0,
    forced: !0
}, {
    isTemplateObject: function(e) {
        if (!Kd(e, !0)) return !1;
        var t = e.raw;
        return t.length === e.length && Kd(t, !1)
    }
}), Y && (Zn(Array.prototype, "lastIndex", {
    configurable: !0,
    get: function() {
        var e = b(this),
            t = Mt(e);
        return 0 === t ? 0 : t - 1
    }
}), cn("lastIndex")), Y && (Zn(Array.prototype, "lastItem", {
    configurable: !0,
    get: function() {
        var e = b(this),
            t = Mt(e);
        return 0 === t ? void 0 : e[t - 1]
    },
    set: function(e) {
        var t = b(this),
            r = Mt(t);
        return t[0 === r ? 0 : r - 1] = e
    }
}), cn("lastItem"));
var qd = Wu.Map,
    $d = Wu.proto,
    Qd = h($d.forEach),
    Jd = h($d.entries),
    Zd = Jd(new qd).next,
    eh = function(e, t, r) {
        return r ? ef({
            iterator: Jd(e),
            next: Zd
        }, function(e) {
            return t(e[1], e[0])
        }) : Qd(e, t)
    },
    th = Wu.Map,
    rh = Wu.has,
    nh = Wu.set,
    oh = h([].push),
    ih = function(e) {
        var t, r, n, o = b(this),
            i = Mt(o),
            a = [],
            u = new th,
            s = p(e) ? function(e) {
                return e
            } : he(e);
        for (t = 0; t < i; t++) n = s(r = o[t]), rh(u, n) || nh(u, n, r);
        return eh(u, function(e) {
            oh(a, e)
        }), a
    };
Zt({
    target: "Array",
    proto: !0,
    forced: !0
}, {
    uniqueBy: ih
}), cn("uniqueBy");
var ah = H("toStringTag"),
    uh = TypeError,
    sh = function() {
        if (jo(this, Vs), br(this) === Vs) throw new uh("Abstract class AsyncIterator not directly constructable")
    };
sh.prototype = Vs, w(Vs, ah) || Ze(Vs, ah, "AsyncIterator"), w(Vs, "constructor") && Vs.constructor !== Object || Ze(Vs, "constructor", sh), Zt({
    global: !0,
    constructor: !0,
    forced: E
}, {
    AsyncIterator: sh
});
var ch = ae("Promise"),
    fh = H("toStringTag"),
    lh = "AsyncIteratorHelper",
    dh = "WrapForValidAsyncIterator",
    hh = mt.set,
    ph = function(e) {
        var t = !e,
            r = mt.getterFor(e ? dh : lh),
            n = function(e) {
                var n = Ss(function() {
                        return r(e)
                    }),
                    o = n.error,
                    i = n.value;
                return o || t && i.done ? {
                    exit: !0,
                    value: o ? ch.reject(i) : ch.resolve(_i(void 0, !0))
                } : {
                    exit: !1,
                    value: i
                }
            };
        return Xo(Cr(Vs), {
            next: function() {
                var e = n(this),
                    t = e.value;
                if (e.exit) return t;
                var r = Ss(function() {
                        return ne(t.nextHandler(ch))
                    }),
                    o = r.error,
                    i = r.value;
                return o && (t.done = !0), o ? ch.reject(i) : ch.resolve(i)
            },
            return: function() {
                var t = n(this),
                    r = t.value;
                if (t.exit) return r;
                r.done = !0;
                var o, i, a = r.iterator,
                    u = Ss(function() {
                        if (r.inner) try {
                            Ti(r.inner.iterator, "normal")
                        } catch (e) {
                            return Ti(a, "throw", e)
                        }
                        return pe(a, "return")
                    });
                return o = i = u.value, u.error ? ch.reject(i) : void 0 === o ? ch.resolve(_i(void 0, !0)) : (i = (u = Ss(function() {
                    return ie(o, a)
                })).value, u.error ? ch.reject(i) : e ? ch.resolve(i) : ch.resolve(i).then(function(e) {
                    return ne(e), _i(void 0, !0)
                }))
            }
        })
    },
    vh = ph(!0),
    yh = ph(!1);
Ze(yh, fh, "Async Iterator Helper");
var gh = function(e, t) {
        var r = function(r, n) {
            n ? (n.iterator = r.iterator, n.next = r.next) : n = r, n.type = t ? dh : lh, n.nextHandler = e, n.counter = 0, n.done = !1, hh(this, n)
        };
        return r.prototype = t ? vh : yh, r
    },
    bh = gh(function(e) {
        var t = this,
            r = t.iterator,
            n = t.mapper;
        return new e(function(o, i) {
            var a = function(e) {
                    t.done = !0, i(e)
                },
                u = function(e) {
                    Qs(r, a, e, a)
                };
            e.resolve(ne(ie(t.next, r))).then(function(r) {
                try {
                    if (ne(r).done) t.done = !0, o(_i(void 0, !0));
                    else {
                        var i = r.value;
                        try {
                            var s = n(i, t.counter++),
                                c = function(e) {
                                    o(_i(e, !1))
                                };
                            q(s) ? e.resolve(s).then(c, u) : c(s)
                        } catch (e) {
                            u(e)
                        }
                    }
                } catch (e) {
                    a(e)
                }
            }, a)
        })
    }),
    mh = function(e) {
        return ne(this), he(e), new bh(Bi(this), {
            mapper: e
        })
    },
    wh = function(e, t) {
        return [t, e]
    },
    Eh = function() {
        return ie(mh, this, wh)
    };
Zt({
    target: "AsyncIterator",
    name: "indexed",
    proto: !0,
    real: !0,
    forced: !0
}, {
    asIndexedPairs: Eh
});
var _h = gh(function(e) {
    var t = this;
    return new e(function(r, n) {
        var o = function(e) {
                t.done = !0, n(e)
            },
            i = function() {
                try {
                    e.resolve(ne(ie(t.next, t.iterator))).then(function(e) {
                        try {
                            ne(e).done ? (t.done = !0, r(_i(void 0, !0))) : t.remaining ? (t.remaining--, i()) : r(_i(e.value, !1))
                        } catch (e) {
                            o(e)
                        }
                    }, o)
                } catch (e) {
                    o(e)
                }
            };
        i()
    })
});
Zt({
    target: "AsyncIterator",
    proto: !0,
    real: !0,
    forced: !0
}, {
    drop: function(e) {
        ne(this);
        var t = Hi(Vi(+e));
        return new _h(Bi(this), {
            remaining: t
        })
    }
});
var Th = Zs.every;
Zt({
    target: "AsyncIterator",
    proto: !0,
    real: !0,
    forced: !0
}, {
    every: function(e) {
        return Th(this, e)
    }
});
var Sh = gh(function(e) {
    var t = this,
        r = t.iterator,
        n = t.predicate;
    return new e(function(o, i) {
        var a = function(e) {
                t.done = !0, i(e)
            },
            u = function(e) {
                Qs(r, a, e, a)
            },
            s = function() {
                try {
                    e.resolve(ne(ie(t.next, r))).then(function(r) {
                        try {
                            if (ne(r).done) t.done = !0, o(_i(void 0, !0));
                            else {
                                var i = r.value;
                                try {
                                    var c = n(i, t.counter++),
                                        f = function(e) {
                                            e ? o(_i(i, !1)) : s()
                                        };
                                    q(c) ? e.resolve(c).then(f, u) : f(c)
                                } catch (e) {
                                    u(e)
                                }
                            }
                        } catch (e) {
                            a(e)
                        }
                    }, a)
                } catch (e) {
                    a(e)
                }
            };
        s()
    })
});
Zt({
    target: "AsyncIterator",
    proto: !0,
    real: !0,
    forced: !0
}, {
    filter: function(e) {
        return ne(this), he(e), new Sh(Bi(this), {
            predicate: e
        })
    }
});
var Ah = Zs.find;
Zt({
    target: "AsyncIterator",
    proto: !0,
    real: !0,
    forced: !0
}, {
    find: function(e) {
        return Ah(this, e)
    }
});
var Ih = H("asyncIterator"),
    Oh = function(e) {
        var t, r = ne(e),
            n = !0,
            o = pe(r, Ih);
        return K(o) || (o = Ei(r), n = !1), void 0 !== o ? t = ie(o, r) : (t = r, n = !0), ne(t), Bi(n ? t : new qs(Bi(t)))
    },
    Rh = gh(function(e) {
        var t = this,
            r = t.iterator,
            n = t.mapper;
        return new e(function(o, i) {
            var a = function(e) {
                    t.done = !0, i(e)
                },
                u = function(e) {
                    Qs(r, a, e, a)
                },
                s = function() {
                    try {
                        e.resolve(ne(ie(t.next, r))).then(function(r) {
                            try {
                                if (ne(r).done) t.done = !0, o(_i(void 0, !0));
                                else {
                                    var i = r.value;
                                    try {
                                        var s = n(i, t.counter++),
                                            f = function(e) {
                                                try {
                                                    t.inner = Oh(e), c()
                                                } catch (e) {
                                                    u(e)
                                                }
                                            };
                                        q(s) ? e.resolve(s).then(f, u) : f(s)
                                    } catch (e) {
                                        u(e)
                                    }
                                }
                            } catch (e) {
                                a(e)
                            }
                        }, a)
                    } catch (e) {
                        a(e)
                    }
                },
                c = function() {
                    var r = t.inner;
                    if (r) try {
                        e.resolve(ne(ie(r.next, r.iterator))).then(function(e) {
                            try {
                                ne(e).done ? (t.inner = null, s()) : o(_i(e.value, !1))
                            } catch (e) {
                                u(e)
                            }
                        }, u)
                    } catch (e) {
                        u(e)
                    } else s()
                };
            c()
        })
    });
Zt({
    target: "AsyncIterator",
    proto: !0,
    real: !0,
    forced: !0
}, {
    flatMap: function(e) {
        return ne(this), he(e), new Rh(Bi(this), {
            mapper: e,
            inner: null
        })
    }
});
var Nh = Zs.forEach;
Zt({
    target: "AsyncIterator",
    proto: !0,
    real: !0,
    forced: !0
}, {
    forEach: function(e) {
        return Nh(this, e)
    }
});
var Ph = gh(function() {
    return ie(this.next, this.iterator)
}, !0);
Zt({
    target: "AsyncIterator",
    stat: !0,
    forced: !0
}, {
    from: function(e) {
        var t = Oh("string" == typeof e ? b(e) : e);
        return ue(Vs, t.iterator) ? t.iterator : new Ph(t)
    }
}), Zt({
    target: "AsyncIterator",
    proto: !0,
    real: !0,
    forced: !0
}, {
    indexed: Eh
}), Zt({
    target: "AsyncIterator",
    proto: !0,
    real: !0,
    forced: !0
}, {
    map: mh
});
var Mh = ae("Promise"),
    Dh = TypeError;
Zt({
    target: "AsyncIterator",
    proto: !0,
    real: !0,
    forced: !0
}, {
    reduce: function(e) {
        ne(this), he(e);
        var t = Bi(this),
            r = t.iterator,
            n = t.next,
            o = arguments.length < 2,
            i = o ? void 0 : arguments[1],
            a = 0;
        return new Mh(function(t, u) {
            var s = function(e) {
                    Qs(r, u, e, u)
                },
                c = function() {
                    try {
                        Mh.resolve(ne(ie(n, r))).then(function(r) {
                            try {
                                if (ne(r).done) o ? u(new Dh("Reduce of empty iterator with no initial value")) : t(i);
                                else {
                                    var n = r.value;
                                    if (o) o = !1, i = n, c();
                                    else try {
                                        var f = e(i, n, a),
                                            l = function(e) {
                                                i = e, c()
                                            };
                                        q(f) ? Mh.resolve(f).then(l, s) : l(f)
                                    } catch (e) {
                                        s(e)
                                    }
                                }
                                a++
                            } catch (e) {
                                u(e)
                            }
                        }, u)
                    } catch (e) {
                        u(e)
                    }
                };
            c()
        })
    }
});
var xh = Zs.some;
Zt({
    target: "AsyncIterator",
    proto: !0,
    real: !0,
    forced: !0
}, {
    some: function(e) {
        return xh(this, e)
    }
});
var Ch = gh(function(e) {
    var t, r = this,
        n = r.iterator;
    if (!r.remaining--) {
        var o = _i(void 0, !0);
        return r.done = !0, void 0 !== (t = n.return) ? e.resolve(ie(t, n, void 0)).then(function() {
            return o
        }) : o
    }
    return e.resolve(ie(r.next, n)).then(function(e) {
        return ne(e).done ? (r.done = !0, _i(void 0, !0)) : _i(e.value, !1)
    }).then(null, function(e) {
        throw r.done = !0, e
    })
});
Zt({
    target: "AsyncIterator",
    proto: !0,
    real: !0,
    forced: !0
}, {
    take: function(e) {
        ne(this);
        var t = Hi(Vi(+e));
        return new Ch(Bi(this), {
            remaining: t
        })
    }
});
var kh = Zs.toArray;
Zt({
    target: "AsyncIterator",
    proto: !0,
    real: !0,
    forced: !0
}, {
    toArray: function() {
        return kh(this, void 0, [])
    }
});
var Lh = Oe.f,
    jh = H("toStringTag"),
    Xh = function(e, t, r) {
        e && !r && (e = e.prototype), e && !w(e, jh) && Lh(e, jh, {
            configurable: !0,
            value: t
        })
    },
    Uh = ci.IteratorPrototype,
    Bh = function() {
        return this
    },
    Fh = function(e, t, r, n) {
        var o = t + " Iterator";
        return e.prototype = Cr(Uh, {
            next: Ce(+!n, r)
        }), Xh(e, o, !1), mi[o] = Bh, e
    },
    Vh = "Incorrect Iterator.range arguments",
    zh = "NumericRangeIterator",
    Hh = mt.set,
    Wh = mt.getterFor(zh),
    Yh = RangeError,
    Gh = TypeError,
    Kh = Fh(function(e, t, r, n, o, i) {
        if (typeof e != n || t !== 1 / 0 && t !== -1 / 0 && typeof t != n) throw new Gh(Vh);
        if (e === 1 / 0 || e === -1 / 0) throw new Yh(Vh);
        var a, u = t > e,
            s = !1;
        if (void 0 === r) a = void 0;
        else if (q(r)) a = r.step, s = !!r.inclusive;
        else {
            if (typeof r != n) throw new Gh(Vh);
            a = r
        }
        if (p(a) && (a = u ? i : -i), typeof a != n) throw new Gh(Vh);
        if (a === 1 / 0 || a === -1 / 0 || a === o && e !== t) throw new Yh(Vh);
        Hh(this, {
            type: zh,
            start: e,
            end: t,
            step: a,
            inclusive: s,
            hitsEnd: e != e || t != t || a != a || t > e != a > o,
            currentCount: o,
            zero: o
        }), Y || (this.start = e, this.end = t, this.step = a, this.inclusive = s)
    }, zh, function() {
        var e = Wh(this);
        if (e.hitsEnd) return _i(void 0, !0);
        var t = e.start,
            r = e.end,
            n = t + e.step * e.currentCount++;
        n === r && (e.hitsEnd = !0);
        var o = e.inclusive;
        return (r > t ? o ? n > r : n >= r : o ? r > n : r >= n) ? (e.hitsEnd = !0, _i(void 0, !0)) : _i(n, !1)
    }),
    qh = function(e) {
        Zn(Kh.prototype, e, {
            get: function() {
                return Wh(this)[e]
            },
            set: function() {},
            configurable: !0,
            enumerable: !1
        })
    };
Y && (qh("start"), qh("end"), qh("inclusive"), qh("step"));
var $h = Kh;
"function" == typeof BigInt && Zt({
    target: "BigInt",
    stat: !0,
    forced: !0
}, {
    range: function(e, t, r) {
        return new $h(e, t, r, "bigint", BigInt(0), BigInt(1))
    }
});
var Qh = Bt.f,
    Jh = "object" == typeof window && window && Object.getOwnPropertyNames ? Object.getOwnPropertyNames(window) : [],
    Zh = {
        f: function(e) {
            return Jh && "Window" === je(e) ? function(e) {
                try {
                    return Qh(e)
                } catch (e) {
                    return Su(Jh)
                }
            }(e) : Qh(Fe(e))
        }
    },
    ep = s(function() {
        if ("function" == typeof ArrayBuffer) {
            var e = new ArrayBuffer(8);
            Object.isExtensible(e) && Object.defineProperty(e, "a", {
                value: 8
            })
        }
    }),
    tp = Object.isExtensible,
    rp = s(function() {
        tp(1)
    }) || ep ? function(e) {
        return !!q(e) && (!ep || "ArrayBuffer" !== je(e)) && (!tp || tp(e))
    } : tp,
    np = t(function(e) {
        var t = Oe.f,
            r = !1,
            n = N("meta"),
            o = 0,
            i = function(e) {
                t(e, n, {
                    value: {
                        objectID: "O" + o++,
                        weakData: {}
                    }
                })
            },
            a = e.exports = {
                enable: function() {
                    a.enable = function() {}, r = !0;
                    var e = Bt.f,
                        t = h([].splice),
                        o = {};
                    o[n] = 1, e(o).length && (Bt.f = function(r) {
                        for (var o = e(r), i = 0, a = o.length; i < a; i++)
                            if (o[i] === n) {
                                t(o, i, 1);
                                break
                            }
                        return o
                    }, Zt({
                        target: "Object",
                        stat: !0,
                        forced: !0
                    }, {
                        getOwnPropertyNames: Zh.f
                    }))
                },
                fastKey: function(e, t) {
                    if (!q(e)) return "symbol" == typeof e ? e : ("string" == typeof e ? "S" : "P") + e;
                    if (!w(e, n)) {
                        if (!rp(e)) return "F";
                        if (!t) return "E";
                        i(e)
                    }
                    return e[n].objectID
                },
                getWeakData: function(e, t) {
                    if (!w(e, n)) {
                        if (!rp(e)) return !0;
                        if (!t) return !1;
                        i(e)
                    }
                    return e[n].weakData
                },
                onFreeze: function(e) {
                    return vu && r && rp(e) && !w(e, n) && i(e), e
                }
            };
        ht[n] = !0
    }),
    op = H("iterator"),
    ip = !1;
try {
    var ap = 0,
        up = {
            next: function() {
                return {
                    done: !!ap++
                }
            },
            return: function() {
                ip = !0
            }
        };
    up[op] = function() {
        return this
    }, Array.from(up, function() {
        throw 2
    })
} catch (e) {}
var sp = function(e, t, r) {
        var n, o;
        return _r && K(n = t.constructor) && n !== r && q(o = n.prototype) && o !== r.prototype && _r(e, o), e
    },
    cp = function(e, t, r) {
        var n = -1 !== e.indexOf("Map"),
            o = -1 !== e.indexOf("Weak"),
            i = n ? "set" : "add",
            u = a[e],
            c = u && u.prototype,
            f = u,
            l = {},
            d = function(e) {
                var t = h(c[e]);
                Et(c, e, "add" === e ? function(e) {
                    return t(this, 0 === e ? 0 : e), this
                } : "delete" === e ? function(e) {
                    return !(o && !q(e)) && t(this, 0 === e ? 0 : e)
                } : "get" === e ? function(e) {
                    return o && !q(e) ? void 0 : t(this, 0 === e ? 0 : e)
                } : "has" === e ? function(e) {
                    return !(o && !q(e)) && t(this, 0 === e ? 0 : e)
                } : function(e, r) {
                    return t(this, 0 === e ? 0 : e, r), this
                })
            };
        if (Qt(e, !K(u) || !(o || c.forEach && !s(function() {
                (new u).entries().next()
            })))) f = r.getConstructor(t, e, n, i), np.enable();
        else if (Qt(e, !0)) {
            var v = new f,
                y = v[i](o ? {} : -0, 1) !== v,
                g = s(function() {
                    v.has(1)
                }),
                b = function() {
                    try {
                        if (!ip) return !1
                    } catch (e) {
                        return !1
                    }
                    var e = !1;
                    try {
                        var t = {};
                        t[op] = function() {
                                return {
                                    next: function() {
                                        return {
                                            done: e = !0
                                        }
                                    }
                                }
                            },
                            function(e) {
                                new u(e)
                            }(t)
                    } catch (e) {}
                    return e
                }(),
                m = !o && s(function() {
                    for (var e = new u, t = 5; t--;) e[i](t, t);
                    return !e.has(-0)
                });
            b || ((f = t(function(e, t) {
                jo(e, c);
                var r = sp(new u, e, f);
                return p(t) || oa(t, r[i], {
                    that: r,
                    AS_ENTRIES: n
                }), r
            })).prototype = c, c.constructor = f), (g || m) && (d("delete"), d("has"), n && d("get")), (m || y) && d(i), o && c.clear && delete c.clear
        }
        return l[e] = f, Zt({
            global: !0,
            constructor: !0,
            forced: f !== u
        }, l), Xh(f, e), o || r.setStrong(f, e, n), f
    },
    fp = nt.PROPER,
    lp = nt.CONFIGURABLE,
    dp = ci.IteratorPrototype,
    hp = ci.BUGGY_SAFARI_ITERATORS,
    pp = H("iterator"),
    vp = "keys",
    yp = "values",
    gp = "entries",
    bp = function() {
        return this
    },
    mp = H("species"),
    wp = function(e) {
        var t = ae(e);
        Y && t && !t[mp] && Zn(t, mp, {
            configurable: !0,
            get: function() {
                return this
            }
        })
    },
    Ep = np.fastKey,
    _p = mt.set,
    Tp = mt.getterFor,
    Sp = {
        getConstructor: function(e, t, r, n) {
            var o = e(function(e, o) {
                    jo(e, i), _p(e, {
                        type: t,
                        index: Cr(null),
                        first: null,
                        last: null,
                        size: 0
                    }), Y || (e.size = 0), p(o) || oa(o, e[n], {
                        that: e,
                        AS_ENTRIES: r
                    })
                }),
                i = o.prototype,
                a = Tp(t),
                u = function(e, t, r) {
                    var n, o, i = a(e),
                        u = s(e, t);
                    return u ? u.value = r : (i.last = u = {
                        index: o = Ep(t, !0),
                        key: t,
                        value: r,
                        previous: n = i.last,
                        next: null,
                        removed: !1
                    }, i.first || (i.first = u), n && (n.next = u), Y ? i.size++ : e.size++, "F" !== o && (i.index[o] = u)), e
                },
                s = function(e, t) {
                    var r, n = a(e),
                        o = Ep(t);
                    if ("F" !== o) return n.index[o];
                    for (r = n.first; r; r = r.next)
                        if (r.key === t) return r
                };
            return Xo(i, {
                clear: function() {
                    for (var e = a(this), t = e.first; t;) t.removed = !0, t.previous && (t.previous = t.previous.next = null), t = t.next;
                    e.first = e.last = null, e.index = Cr(null), Y ? e.size = 0 : this.size = 0
                },
                delete: function(e) {
                    var t = this,
                        r = a(t),
                        n = s(t, e);
                    if (n) {
                        var o = n.next,
                            i = n.previous;
                        delete r.index[n.index], n.removed = !0, i && (i.next = o), o && (o.previous = i), r.first === n && (r.first = o), r.last === n && (r.last = i), Y ? r.size-- : t.size--
                    }
                    return !!n
                },
                forEach: function(e) {
                    for (var t, r = a(this), n = rn(e, arguments.length > 1 ? arguments[1] : void 0); t = t ? t.next : r.first;)
                        for (n(t.value, t.key, this); t && t.removed;) t = t.previous
                },
                has: function(e) {
                    return !!s(this, e)
                }
            }), Xo(i, r ? {
                get: function(e) {
                    var t = s(this, e);
                    return t && t.value
                },
                set: function(e, t) {
                    return u(this, 0 === e ? 0 : e, t)
                }
            } : {
                add: function(e) {
                    return u(this, e = 0 === e ? 0 : e, e)
                }
            }), Y && Zn(i, "size", {
                configurable: !0,
                get: function() {
                    return a(this).size
                }
            }), o
        },
        setStrong: function(e, t, r) {
            var n = t + " Iterator",
                o = Tp(t),
                i = Tp(n);
            ! function(e, t, r, n, o, a) {
                Fh(r, t, function() {
                    for (var e = i(this), t = e.kind, r = e.last; r && r.removed;) r = r.previous;
                    return e.target && (e.last = r = r ? r.next : e.state.first) ? _i("keys" === t ? r.key : "values" === t ? r.value : [r.key, r.value], !1) : (e.target = null, _i(void 0, !0))
                });
                var u, s, c, f = function(e) {
                        if (e === o && v) return v;
                        if (!hp && e && e in h) return h[e];
                        switch (e) {
                            case vp:
                            case yp:
                            case gp:
                                return function() {
                                    return new r(this, e)
                                }
                        }
                        return function() {
                            return new r(this)
                        }
                    },
                    l = t + " Iterator",
                    d = !1,
                    h = e.prototype,
                    p = h[pp] || h["@@iterator"] || o && h[o],
                    v = !hp && p || f(o),
                    y = "Array" === t && h.entries || p;
                if (y && (u = br(y.call(new e))) !== Object.prototype && u.next && (br(u) !== dp && (_r ? _r(u, dp) : K(u[pp]) || Et(u, pp, bp)), Xh(u, l, !0)), fp && o === yp && p && p.name !== yp && (lp ? Ze(h, "name", yp) : (d = !0, v = function() {
                        return ie(p, this)
                    })), o)
                    for (c in s = {
                            values: f(yp),
                            keys: a ? v : f(vp),
                            entries: f(gp)
                        })(hp || d || !(c in h)) && Et(h, c, s[c]);
                h[pp] !== v && Et(h, pp, v, {
                    name: o
                }), mi[t] = v
            }(e, t, function(e, t) {
                _p(this, {
                    type: n,
                    target: e,
                    state: o(e),
                    kind: t,
                    last: null
                })
            }, 0, r ? "entries" : "values", !r), wp(t)
        }
    };
cp("Map", function(e) {
    return function() {
        return e(this, arguments.length ? arguments[0] : void 0)
    }
}, Sp);
var Ap = np.getWeakData,
    Ip = mt.set,
    Op = mt.getterFor,
    Rp = Cd.find,
    Np = Cd.findIndex,
    Pp = h([].splice),
    Mp = 0,
    Dp = function(e) {
        return e.frozen || (e.frozen = new xp)
    },
    xp = function() {
        this.entries = []
    },
    Cp = function(e, t) {
        return Rp(e.entries, function(e) {
            return e[0] === t
        })
    };
xp.prototype = {
    get: function(e) {
        var t = Cp(this, e);
        if (t) return t[1]
    },
    has: function(e) {
        return !!Cp(this, e)
    },
    set: function(e, t) {
        var r = Cp(this, e);
        r ? r[1] = t : this.entries.push([e, t])
    },
    delete: function(e) {
        var t = Np(this.entries, function(t) {
            return t[0] === e
        });
        return ~t && Pp(this.entries, t, 1), !!~t
    }
};
var kp, Lp = {
        getConstructor: function(e, t, r, n) {
            var o = e(function(e, o) {
                    jo(e, i), Ip(e, {
                        type: t,
                        id: Mp++,
                        frozen: null
                    }), p(o) || oa(o, e[n], {
                        that: e,
                        AS_ENTRIES: r
                    })
                }),
                i = o.prototype,
                a = Op(t),
                u = function(e, t, r) {
                    var n = a(e),
                        o = Ap(ne(t), !0);
                    return !0 === o ? Dp(n).set(t, r) : o[n.id] = r, e
                };
            return Xo(i, {
                delete: function(e) {
                    var t = a(this);
                    if (!q(e)) return !1;
                    var r = Ap(e);
                    return !0 === r ? Dp(t).delete(e) : r && w(r, t.id) && delete r[t.id]
                },
                has: function(e) {
                    var t = a(this);
                    if (!q(e)) return !1;
                    var r = Ap(e);
                    return !0 === r ? Dp(t).has(e) : r && w(r, t.id)
                }
            }), Xo(i, r ? {
                get: function(e) {
                    var t = a(this);
                    if (q(e)) {
                        var r = Ap(e);
                        if (!0 === r) return Dp(t).get(e);
                        if (r) return r[t.id]
                    }
                },
                set: function(e, t) {
                    return u(this, e, t)
                }
            } : {
                add: function(e) {
                    return u(this, e, !0)
                }
            }), o
        }
    },
    jp = mt.enforce,
    Xp = Object,
    Up = Array.isArray,
    Bp = Xp.isExtensible,
    Fp = Xp.isFrozen,
    Vp = Xp.isSealed,
    zp = Xp.freeze,
    Hp = Xp.seal,
    Wp = !a.ActiveXObject && "ActiveXObject" in a,
    Yp = function(e) {
        return function() {
            return e(this, arguments.length ? arguments[0] : void 0)
        }
    },
    Gp = cp("WeakMap", Yp, Lp),
    Kp = Gp.prototype,
    qp = h(Kp.set);
if (ft)
    if (Wp) {
        kp = Lp.getConstructor(Yp, "WeakMap", !0), np.enable();
        var $p = h(Kp.delete),
            Qp = h(Kp.has),
            Jp = h(Kp.get);
        Xo(Kp, {
            delete: function(e) {
                if (q(e) && !Bp(e)) {
                    var t = jp(this);
                    return t.frozen || (t.frozen = new kp), $p(this, e) || t.frozen.delete(e)
                }
                return $p(this, e)
            },
            has: function(e) {
                if (q(e) && !Bp(e)) {
                    var t = jp(this);
                    return t.frozen || (t.frozen = new kp), Qp(this, e) || t.frozen.has(e)
                }
                return Qp(this, e)
            },
            get: function(e) {
                if (q(e) && !Bp(e)) {
                    var t = jp(this);
                    return t.frozen || (t.frozen = new kp), Qp(this, e) ? Jp(this, e) : t.frozen.get(e)
                }
                return Jp(this, e)
            },
            set: function(e, t) {
                if (q(e) && !Bp(e)) {
                    var r = jp(this);
                    r.frozen || (r.frozen = new kp), Qp(this, e) ? qp(this, e, t) : r.frozen.set(e, t)
                } else qp(this, e, t);
                return this
            }
        })
    } else vu && s(function() {
        var e = zp([]);
        return qp(new Gp, e, 1), !Fp(e)
    }) && Xo(Kp, {
        set: function(e, t) {
            var r;
            return Up(e) && (Fp(e) ? r = zp : Vp(e) && (r = Hp)), qp(this, e, t), r && r(e), this
        }
    });
var Zp = Object,
    ev = TypeError,
    tv = ae("Map"),
    rv = ae("WeakMap"),
    nv = function() {
        this.object = null, this.symbol = null, this.primitives = null, this.objectsByIndex = Cr(null)
    };
nv.prototype.get = function(e, t) {
    return this[e] || (this[e] = t())
}, nv.prototype.next = function(e, t, r) {
    var n = r ? this.objectsByIndex[e] || (this.objectsByIndex[e] = new rv) : this.primitives || (this.primitives = new tv),
        o = n.get(t);
    return o || n.set(t, o = new nv), o
};
var ov = new nv,
    iv = function() {
        var e, t, r = ov,
            n = arguments.length;
        for (e = 0; e < n; e++) q(t = arguments[e]) && (r = r.next(e, t, !0));
        if (this === Zp && r === ov) throw new ev("Composite keys must contain a non-primitive component");
        for (e = 0; e < n; e++) q(t = arguments[e]) || (r = r.next(e, t, !1));
        return r
    },
    av = Object,
    uv = function() {
        var e = ae("Object", "freeze");
        return e ? e(Cr(null)) : Cr(null)
    };
Zt({
    global: !0,
    forced: !0
}, {
    compositeKey: function() {
        return Ra(iv, av, arguments).get("object", uv)
    }
}), Zt({
    global: !0,
    forced: !0
}, {
    compositeSymbol: function() {
        return 1 === arguments.length && "string" == typeof arguments[0] ? ae("Symbol").for(arguments[0]) : Ra(iv, null, arguments).get("symbol", ae("Symbol"))
    }
});
var sv = h(DataView.prototype.getUint8);
Zt({
    target: "DataView",
    proto: !0,
    forced: !0
}, {
    getUint8Clamped: function(e) {
        return sv(this, e)
    }
});
var cv = Math.round,
    fv = h(DataView.prototype.setUint8);
Zt({
    target: "DataView",
    proto: !0,
    forced: !0
}, {
    setUint8Clamped: function(e, t) {
        fv(Vn(this), Hn(e), function(e) {
            var t = cv(e);
            return t < 0 ? 0 : t > 255 ? 255 : 255 & t
        }(t))
    }
});
var lv = function() {
    return h(he(this))
};
Zt({
    target: "Function",
    proto: !0,
    forced: !0
}, {
    demethodize: lv
});
var dv = Object.getOwnPropertyDescriptor,
    hv = /^\s*class\b/,
    pv = h(hv.exec);
Zt({
    target: "Function",
    stat: !0,
    sham: !0,
    forced: !0
}, {
    isCallable: function(e) {
        return K(e) && ! function(e) {
            try {
                if (!Y || !pv(hv, st(e))) return !1
            } catch (e) {}
            var t = dv(e, "prototype");
            return !!t && w(t, "writable") && !t.writable
        }(e)
    }
}), Zt({
    target: "Function",
    stat: !0,
    forced: !0
}, {
    isConstructor: js
});
var vv = Oe.f,
    yv = H("metadata"),
    gv = Function.prototype;
void 0 === gv[yv] && vv(gv, yv, {
    value: null
}), Zt({
    target: "Function",
    proto: !0,
    forced: !0,
    name: "demethodize"
}, {
    unThis: lv
});
var bv = ci.IteratorPrototype.map,
    mv = function(e, t) {
        return [t, e]
    },
    wv = function() {
        return ie(bv, this, mv)
    };
Zt({
    target: "Iterator",
    name: "indexed",
    proto: !0,
    real: !0,
    forced: !0
}, {
    asIndexedPairs: wv
});
var Ev = RangeError,
    _v = h([].push),
    Tv = ki(function() {
        for (var e, t = this.iterator, r = this.next, n = this.chunkSize, o = [];;) {
            if ((e = ne(ie(r, t))).done) return o.length ? o : void(this.done = !0);
            if (_v(o, e.value), o.length === n) return o
        }
    });
Zt({
    target: "Iterator",
    proto: !0,
    real: !0,
    forced: !0
}, {
    chunks: function(e) {
        var t = ne(this);
        return "number" == typeof e && e && e >>> 0 === e ? new Tv(Bi(t), {
            chunkSize: e
        }) : Ti(t, "throw", new Ev("chunkSize must be integer in [1, 2^32-1]"))
    }
}), Zt({
    target: "Iterator",
    proto: !0,
    real: !0,
    forced: !0
}, {
    indexed: wv
});
var Sv = TypeError;
Zt({
    target: "Iterator",
    stat: !0,
    forced: !0
}, {
    range: function(e, t, r) {
        if ("number" == typeof e) return new $h(e, t, r, "number", 0, 1);
        if ("bigint" == typeof e) return new $h(e, t, r, "bigint", BigInt(0), BigInt(1));
        throw new Sv("Incorrect Iterator.range arguments")
    }
});
var Av = RangeError,
    Iv = TypeError,
    Ov = h([].push),
    Rv = h([].slice),
    Nv = "allow-partial",
    Pv = ki(function() {
        for (var e, t, r = this.iterator, n = this.next, o = this.buffer, i = this.windowSize, a = this.allowPartial;;) {
            if (e = ne(ie(n, r)), t = this.done = !!e.done, a && t && o.length && o.length < i) return _i(o, !1);
            if (t) return _i(void 0, !0);
            if (o.length === i && (this.buffer = o = Rv(o, 1)), Ov(o, e.value), o.length === i) return _i(o, !1)
        }
    }, !1, !0),
    Mv = function(e, t, r) {
        return ne(e), "number" == typeof t && t && t >>> 0 === t ? void 0 !== r && "only-full" !== r && r !== Nv ? Ti(e, "throw", new Iv("Incorrect `undersized` argument")) : new Pv(Bi(e), {
            windowSize: t,
            buffer: [],
            allowPartial: r === Nv
        }) : Ti(e, "throw", new Av("`windowSize` must be integer in [1, 2^32-1]"))
    };
Zt({
    target: "Iterator",
    proto: !0,
    real: !0,
    forced: !0
}, {
    sliding: function(e) {
        return Mv(this, e, "allow-partial")
    }
}), Zt({
    target: "Iterator",
    proto: !0,
    real: !0,
    forced: !0
}, {
    toAsync: function() {
        return new Ph(Bi(new qs(Bi(ne(this)))))
    }
}), Zt({
    target: "Iterator",
    proto: !0,
    real: !0,
    forced: !0
}, {
    windows: function(e) {
        return Mv(this, e, arguments.length < 2 ? void 0 : arguments[1])
    }
});
var Dv = function(e) {
        return Bi(ea(e))
    },
    xv = TypeError,
    Cv = function(e) {
        var t = e && e.mode;
        if (void 0 === t || "shortest" === t || "longest" === t || "strict" === t) return t || "shortest";
        throw new xv("Incorrect `mode` option")
    },
    kv = TypeError,
    Lv = h([].slice),
    jv = h([].push),
    Xv = "Iterator is exhausted",
    Uv = "throw",
    Bv = ki(function() {
        var e = this.iterCount;
        if (e) {
            for (var t, r, n = this.openIters, o = this.iters, i = this.padding, a = this.mode, u = this.finishResults, s = [], c = 0; c < e; c++) {
                var f = o[c];
                if (null === f) t = i[c];
                else {
                    try {
                        r = (t = ie(f.next, f.iterator)).done, t = t.value
                    } catch (e) {
                        return n[c] = void 0, Si(n, Uv, e)
                    }
                    if (r) {
                        if (n[c] = void 0, this.openItersCount--, "shortest" === a) return this.done = !0, Si(n, "normal", void 0);
                        if ("strict" === a) {
                            if (c) return Si(n, Uv, new kv(Xv));
                            for (var l, d, h = 1; h < e; h++) {
                                try {
                                    d = (l = ie(o[h].next, o[h].iterator)).done, l = l.value
                                } catch (e) {
                                    return n[h] = void 0, Si(n, Uv, l)
                                }
                                if (!d) return Si(n, Uv, new kv(Xv));
                                n[h] = void 0, this.openItersCount--
                            }
                            return void(this.done = !0)
                        }
                        if (!this.openItersCount) return void(this.done = !0);
                        o[c] = null, t = i[c]
                    }
                }
                jv(s, t)
            }
            return u ? u(s) : s
        }
        this.done = !0
    }),
    Fv = function(e, t, r, n) {
        var o = e.length;
        return new Bv({
            iters: e,
            iterCount: o,
            openIters: Lv(e, 0),
            openItersCount: o,
            mode: t,
            padding: r,
            finishResults: n
        })
    },
    Vv = h([].concat),
    zv = h([].push),
    Hv = "throw";
Zt({
    target: "Iterator",
    stat: !0
}, {
    zip: function(e) {
        ne(e);
        for (var t, r, n, o = arguments.length > 1 ? Hl(arguments[1]) : void 0, i = Cv(o), a = "longest" === i ? Hl(o && o.padding) : void 0, u = [], s = [], c = Dv(e); !r;) {
            try {
                r = (n = ne(ie(c.next, c.iterator))).done
            } catch (e) {
                return Si(u, Hv, e)
            }
            if (!r) {
                try {
                    t = da(n.value, !0)
                } catch (e) {
                    return Si(Vv([c.iterator], u), Hv, e)
                }
                zv(u, t)
            }
        }
        var f, l, d, h = u.length;
        if ("longest" === i)
            if (void 0 === a)
                for (f = 0; f < h; f++) zv(s, void 0);
            else {
                try {
                    d = Dv(a)
                } catch (e) {
                    return Si(u, Hv, e)
                }
                var p = !0;
                for (f = 0; f < h; f++)
                    if (p) {
                        try {
                            l = (n = ne(ie(d.next, d.iterator))).done, n = n.value
                        } catch (e) {
                            return Si(u, Hv, e)
                        }
                        l ? p = !1 : zv(s, n)
                    } else zv(s, void 0);
                if (p) try {
                    Ti(d.iterator, "normal")
                } catch (e) {
                    return Si(u, Hv, e)
                }
            }
        return Fv(u, i, s)
    }
});
var Wv = ae("Object", "create"),
    Yv = ae("Reflect", "ownKeys"),
    Gv = h([].push),
    Kv = "throw";
Zt({
    target: "Iterator",
    stat: !0
}, {
    zipKeyed: function(e) {
        ne(e);
        var t, r, n, o = arguments.length > 1 ? Hl(arguments[1]) : void 0,
            i = Cv(o),
            a = "longest" === i ? Hl(o && o.padding) : void 0,
            u = [],
            s = [],
            c = Yv(e),
            f = [],
            l = xe.f;
        for (t = 0; t < c.length; t++) try {
            if (r = c[t], !ie(l, e, r)) continue;
            void 0 !== (n = e[r]) && (Gv(f, r), Gv(u, da(n, !0)))
        } catch (e) {
            return Si(u, Kv, e)
        }
        var d = u.length;
        if ("longest" === i)
            if (void 0 === a)
                for (t = 0; t < d; t++) Gv(s, void 0);
            else
                for (t = 0; t < f.length; t++) {
                    try {
                        n = a[f[t]]
                    } catch (e) {
                        return Si(u, Kv, e)
                    }
                    Gv(s, n)
                }
        return Fv(u, i, s, function(e) {
            for (var t = Wv(null), r = 0; r < d; r++) ii(t, f[r], e[r]);
            return t
        })
    }
});
var qv = Wu.has,
    $v = function(e) {
        return qv(e), e
    },
    Qv = Wu.remove;
Zt({
    target: "Map",
    proto: !0,
    real: !0,
    forced: !0
}, {
    deleteAll: function() {
        for (var e, t = $v(this), r = !0, n = 0, o = arguments.length; n < o; n++) e = Qv(t, arguments[n]), r = r && e;
        return !!r
    }
});
var Jv = Wu.get,
    Zv = Wu.has,
    ey = Wu.set;
Zt({
    target: "Map",
    proto: !0,
    real: !0,
    forced: !0
}, {
    emplace: function(e, t) {
        var r, n, o = $v(this);
        return Zv(o, e) ? (r = Jv(o, e), "update" in t && (r = t.update(r, e, o), ey(o, e, r)), r) : (n = t.insert(e, o), ey(o, e, n), n)
    }
}), Zt({
    target: "Map",
    proto: !0,
    real: !0,
    forced: !0
}, {
    every: function(e) {
        var t = $v(this),
            r = rn(e, arguments.length > 1 ? arguments[1] : void 0);
        return !1 !== eh(t, function(e, n) {
            if (!r(e, n, t)) return !1
        }, !0)
    }
});
var ty = Wu.Map,
    ry = Wu.set;
Zt({
    target: "Map",
    proto: !0,
    real: !0,
    forced: !0
}, {
    filter: function(e) {
        var t = $v(this),
            r = rn(e, arguments.length > 1 ? arguments[1] : void 0),
            n = new ty;
        return eh(t, function(e, o) {
            r(e, o, t) && ry(n, o, e)
        }), n
    }
}), Zt({
    target: "Map",
    proto: !0,
    real: !0,
    forced: !0
}, {
    find: function(e) {
        var t = $v(this),
            r = rn(e, arguments.length > 1 ? arguments[1] : void 0),
            n = eh(t, function(e, n) {
                if (r(e, n, t)) return {
                    value: e
                }
            }, !0);
        return n && n.value
    }
}), Zt({
    target: "Map",
    proto: !0,
    real: !0,
    forced: !0
}, {
    findKey: function(e) {
        var t = $v(this),
            r = rn(e, arguments.length > 1 ? arguments[1] : void 0),
            n = eh(t, function(e, n) {
                if (r(e, n, t)) return {
                    key: n
                }
            }, !0);
        return n && n.key
    }
});
var ny = function(e, t, r) {
    return function(n) {
        var o = b(n),
            i = arguments.length,
            a = i > 1 ? arguments[1] : void 0,
            u = void 0 !== a,
            s = u ? rn(a, i > 2 ? arguments[2] : void 0) : void 0,
            c = new e,
            f = 0;
        return oa(o, function(e) {
            var n = u ? s(e, f++) : e;
            r ? t(c, ne(n)[0], n[1]) : t(c, n)
        }), c
    }
};
Zt({
    target: "Map",
    stat: !0,
    forced: !0
}, {
    from: ny(Wu.Map, Wu.set, !0)
});
var oy = Wu.get,
    iy = Wu.has,
    ay = Wu.set;
Zt({
    target: "Map",
    proto: !0,
    real: !0,
    forced: E
}, {
    getOrInsert: function(e, t) {
        return iy($v(this), e) ? oy(this, e) : (ay(this, e, t), t)
    }
});
var uy = Wu.get,
    sy = Wu.has,
    cy = Wu.set;
Zt({
    target: "Map",
    proto: !0,
    real: !0,
    forced: E
}, {
    getOrInsertComputed: function(e, t) {
        if ($v(this), he(t), sy(this, e)) return uy(this, e);
        0 === e && 1 / e == -1 / 0 && (e = 0);
        var r = t(e);
        return cy(this, e, r), r
    }
}), Zt({
    target: "Map",
    proto: !0,
    real: !0,
    forced: !0
}, {
    includes: function(e) {
        return !0 === eh($v(this), function(t) {
            if (function(e, t) {
                    return e === t || e != e && t != t
                }(t, e)) return !0
        }, !0)
    }
});
var fy = Wu.Map;
Zt({
    target: "Map",
    stat: !0,
    forced: !0
}, {
    keyBy: function(e, t) {
        var r = new(K(this) ? this : fy);
        he(t);
        var n = he(r.set);
        return oa(e, function(e) {
            ie(n, r, t(e), e)
        }), r
    }
}), Zt({
    target: "Map",
    proto: !0,
    real: !0,
    forced: !0
}, {
    keyOf: function(e) {
        var t = eh($v(this), function(t, r) {
            if (t === e) return {
                key: r
            }
        }, !0);
        return t && t.key
    }
});
var ly = Wu.Map,
    dy = Wu.set;
Zt({
    target: "Map",
    proto: !0,
    real: !0,
    forced: !0
}, {
    mapKeys: function(e) {
        var t = $v(this),
            r = rn(e, arguments.length > 1 ? arguments[1] : void 0),
            n = new ly;
        return eh(t, function(e, o) {
            dy(n, r(e, o, t), e)
        }), n
    }
});
var hy = Wu.Map,
    py = Wu.set;
Zt({
    target: "Map",
    proto: !0,
    real: !0,
    forced: !0
}, {
    mapValues: function(e) {
        var t = $v(this),
            r = rn(e, arguments.length > 1 ? arguments[1] : void 0),
            n = new hy;
        return eh(t, function(e, o) {
            py(n, o, r(e, o, t))
        }), n
    }
});
var vy = Wu.set;
Zt({
    target: "Map",
    proto: !0,
    real: !0,
    arity: 1,
    forced: !0
}, {
    merge: function(e) {
        for (var t = $v(this), r = arguments.length, n = 0; n < r;) oa(arguments[n++], function(e, r) {
            vy(t, e, r)
        }, {
            AS_ENTRIES: !0
        });
        return t
    }
});
var yy = function(e, t, r) {
    return function() {
        for (var n = new e, o = arguments.length, i = 0; i < o; i++) {
            var a = arguments[i];
            r ? t(n, ne(a)[0], a[1]) : t(n, a)
        }
        return n
    }
};
Zt({
    target: "Map",
    stat: !0,
    forced: !0
}, { of: yy(Wu.Map, Wu.set, !0)
});
var gy = TypeError;
Zt({
    target: "Map",
    proto: !0,
    real: !0,
    forced: !0
}, {
    reduce: function(e) {
        var t = $v(this),
            r = arguments.length < 2,
            n = r ? void 0 : arguments[1];
        if (he(e), eh(t, function(o, i) {
                r ? (r = !1, n = o) : n = e(n, o, i, t)
            }), r) throw new gy("Reduce of empty map with no initial value");
        return n
    }
}), Zt({
    target: "Map",
    proto: !0,
    real: !0,
    forced: !0
}, {
    some: function(e) {
        var t = $v(this),
            r = rn(e, arguments.length > 1 ? arguments[1] : void 0);
        return !0 === eh(t, function(e, n) {
            if (r(e, n, t)) return !0
        }, !0)
    }
});
var by = TypeError,
    my = Wu.get,
    wy = Wu.has,
    Ey = Wu.set;
Zt({
    target: "Map",
    proto: !0,
    real: !0,
    forced: !0
}, {
    update: function(e, t) {
        var r = $v(this),
            n = arguments.length;
        he(t);
        var o = wy(r, e);
        if (!o && n < 3) throw new by("Updating absent value");
        var i = o ? my(r, e) : he(n > 2 ? arguments[2] : void 0)(e, r);
        return Ey(r, e, t(i, e, r)), r
    }
});
var _y = TypeError,
    Ty = function(e, t) {
        var r, n = ne(this),
            o = he(n.get),
            i = he(n.has),
            a = he(n.set),
            u = arguments.length > 2 ? arguments[2] : void 0;
        if (!K(t) && !K(u)) throw new _y("At least one callback required");
        return ie(i, n, e) ? (r = ie(o, n, e), K(t) && (r = t(r), ie(a, n, e, r))) : K(u) && (r = u(), ie(a, n, e, r)), r
    };
Zt({
    target: "Map",
    proto: !0,
    real: !0,
    name: "upsert",
    forced: !0
}, {
    updateOrInsert: Ty
}), Zt({
    target: "Map",
    proto: !0,
    real: !0,
    forced: !0
}, {
    upsert: Ty
});
var Sy = TypeError,
    Ay = function(e) {
        if ("number" == typeof e) return e;
        throw new Sy("Argument is not a number")
    },
    Iy = Math.min,
    Oy = Math.max,
    Ry = function(e, t, r) {
        return Iy(Oy(Ay(e), Ay(t)), Ay(r))
    };
Zt({
    target: "Math",
    stat: !0,
    forced: !0
}, {
    clamp: Ry
}), Zt({
    target: "Math",
    stat: !0,
    nonConfigurable: !0,
    nonWritable: !0
}, {
    DEG_PER_RAD: Math.PI / 180
});
var Ny = 180 / Math.PI;
Zt({
    target: "Math",
    stat: !0,
    forced: !0
}, {
    degrees: function(e) {
        return e * Ny
    }
});
var Py = function(e, t, r, n, o) {
        var i = +e,
            a = +t,
            u = +r,
            s = +n,
            c = +o;
        return i != i || a != a || u != u || s != s || c != c ? NaN : i === 1 / 0 || i === -1 / 0 ? i : (i - a) * (c - s) / (u - a) + s
    },
    My = Math.fround || function(e) {
        return es(e, 1.1920928955078125e-7, 34028234663852886e22, 11754943508222875e-54)
    };
Zt({
    target: "Math",
    stat: !0,
    forced: !0
}, {
    fscale: function(e, t, r, n, o) {
        return My(Py(e, t, r, n, o))
    }
}), Zt({
    target: "Math",
    stat: !0,
    forced: !0
}, {
    iaddh: function(e, t, r, n) {
        var o = e >>> 0,
            i = r >>> 0;
        return (t >>> 0) + (n >>> 0) + ((o & i | (o | i) & ~(o + i >>> 0)) >>> 31) | 0
    }
}), Zt({
    target: "Math",
    stat: !0,
    forced: !0
}, {
    imulh: function(e, t) {
        var r = 65535,
            n = +e,
            o = +t,
            i = n & r,
            a = o & r,
            u = n >> 16,
            s = o >> 16,
            c = (u * a >>> 0) + (i * a >>> 16);
        return u * s + (c >> 16) + ((i * s >>> 0) + (c & r) >> 16)
    }
}), Zt({
    target: "Math",
    stat: !0,
    forced: !0
}, {
    isubh: function(e, t, r, n) {
        var o = e >>> 0,
            i = r >>> 0;
        return (t >>> 0) - (n >>> 0) - ((~o & i | (o ^ ~i) & o - i >>> 0) >>> 31) | 0
    }
}), Zt({
    target: "Math",
    stat: !0,
    nonConfigurable: !0,
    nonWritable: !0
}, {
    RAD_PER_DEG: 180 / Math.PI
});
var Dy = Math.PI / 180;
Zt({
    target: "Math",
    stat: !0,
    forced: !0
}, {
    radians: function(e) {
        return e * Dy
    }
}), Zt({
    target: "Math",
    stat: !0,
    forced: !0
}, {
    scale: Py
});
var xy = a.isFinite,
    Cy = Number.isFinite || function(e) {
        return "number" == typeof e && xy(e)
    },
    ky = "Seeded Random",
    Ly = ky + " Generator",
    jy = mt.set,
    Xy = mt.getterFor(Ly),
    Uy = TypeError,
    By = Fh(function(e) {
        jy(this, {
            type: Ly,
            seed: e % 2147483647
        })
    }, ky, function() {
        var e = Xy(this),
            t = e.seed = (1103515245 * e.seed + 12345) % 2147483647;
        return _i((1073741823 & t) / 1073741823, !1)
    });
Zt({
    target: "Math",
    stat: !0,
    forced: !0
}, {
    seededPRNG: function(e) {
        var t = ne(e).seed;
        if (!Cy(t)) throw new Uy('Math.seededPRNG() argument should have a "seed" field with a finite value.');
        return new By(t)
    }
}), Zt({
    target: "Math",
    stat: !0,
    forced: !0
}, {
    signbit: function(e) {
        var t = +e;
        return t == t && 0 === t ? 1 / t == -1 / 0 : t < 0
    }
}), Zt({
    target: "Math",
    stat: !0,
    forced: !0
}, {
    umulh: function(e, t) {
        var r = 65535,
            n = +e,
            o = +t,
            i = n & r,
            a = o & r,
            u = n >>> 16,
            s = o >>> 16,
            c = (u * a >>> 0) + (i * a >>> 16);
        return u * s + (c >>> 16) + ((i * s >>> 0) + (c & r) >>> 16)
    }
});
var Fy = h(1.1.valueOf);
Zt({
    target: "Number",
    proto: !0,
    forced: !0
}, {
    clamp: function(e, t) {
        return Ry(Fy(this), e, t)
    }
});
var Vy = "Invalid number representation",
    zy = RangeError,
    Hy = SyntaxError,
    Wy = TypeError,
    Yy = parseInt,
    Gy = Math.pow,
    Ky = /^[\d.a-z]+$/,
    qy = h("".charAt),
    $y = h(Ky.exec),
    Qy = h(1.1.toString),
    Jy = h("".slice),
    Zy = h("".split);
Zt({
    target: "Number",
    stat: !0,
    forced: !0
}, {
    fromString: function(e, t) {
        var r = 1;
        if ("string" != typeof e) throw new Wy(Vy);
        if (!e.length) throw new Hy(Vy);
        if ("-" === qy(e, 0) && (r = -1, !(e = Jy(e, 1)).length)) throw new Hy(Vy);
        var n = void 0 === t ? 10 : At(t);
        if (n < 2 || n > 36) throw new zy("Invalid radix");
        if (!$y(Ky, e)) throw new Hy(Vy);
        var o = Zy(e, "."),
            i = Yy(o[0], n);
        if (o.length > 1 && (i += Yy(o[1], n) / Gy(n, o[1].length)), 10 === n && Qy(i, n) !== e) throw new Hy(Vy);
        return r * i
    }
}), Zt({
    target: "Number",
    stat: !0,
    forced: !0
}, {
    range: function(e, t, r) {
        return new $h(e, t, r, "number", 0, 1)
    }
});
var eg = "Object Iterator",
    tg = mt.set,
    rg = mt.getterFor(eg),
    ng = Fh(function(e, t) {
        var r = b(e);
        tg(this, {
            type: eg,
            mode: t,
            object: r,
            keys: Tr(r),
            index: 0
        })
    }, "Object", function() {
        for (var e = rg(this), t = e.keys;;) {
            if (null === t || e.index >= t.length) return e.object = e.keys = null, _i(void 0, !0);
            var r = t[e.index++],
                n = e.object;
            if (w(n, r)) {
                switch (e.mode) {
                    case "keys":
                        return _i(r, !1);
                    case "values":
                        return _i(n[r], !1)
                }
                return _i([r, n[r]], !1)
            }
        }
    });
Zt({
    target: "Object",
    stat: !0,
    forced: !0
}, {
    iterateEntries: function(e) {
        return new ng(e, "entries")
    }
}), Zt({
    target: "Object",
    stat: !0,
    forced: !0
}, {
    iterateKeys: function(e) {
        return new ng(e, "keys")
    }
}), Zt({
    target: "Object",
    stat: !0,
    forced: !0
}, {
    iterateValues: function(e) {
        return new ng(e, "values")
    }
});
var og = H("observable"),
    ig = "Observable",
    ag = "Subscription",
    ug = "SubscriptionObserver",
    sg = mt.getterFor,
    cg = mt.set,
    fg = sg(ig),
    lg = sg(ag),
    dg = sg(ug),
    hg = function(e) {
        this.observer = ne(e), this.cleanup = null, this.subscriptionObserver = null
    };
hg.prototype = {
    type: ag,
    clean: function() {
        var e = this.cleanup;
        if (e) {
            this.cleanup = null;
            try {
                e()
            } catch (e) {}
        }
    },
    close: function() {
        if (!Y) {
            var e = this.facade,
                t = this.subscriptionObserver;
            e.closed = !0, t && (t.closed = !0)
        }
        this.observer = null
    },
    isClosed: function() {
        return null === this.observer
    }
};
var pg = function(e, t) {
    var r, n = cg(this, new hg(e));
    Y || (this.closed = !1);
    try {
        (r = pe(e, "start")) && ie(r, e, this)
    } catch (e) {}
    if (!n.isClosed()) {
        var o = n.subscriptionObserver = new vg(n);
        try {
            var i = t(o),
                a = i;
            p(i) || (n.cleanup = K(i.unsubscribe) ? function() {
                a.unsubscribe()
            } : he(i))
        } catch (e) {
            return void o.error(e)
        }
        n.isClosed() && n.clean()
    }
};
pg.prototype = Xo({}, {
    unsubscribe: function() {
        var e = lg(this);
        e.isClosed() || (e.close(), e.clean())
    }
}), Y && Zn(pg.prototype, "closed", {
    configurable: !0,
    get: function() {
        return lg(this).isClosed()
    }
});
var vg = function(e) {
    cg(this, {
        type: ug,
        subscriptionState: e
    }), Y || (this.closed = !1)
};
vg.prototype = Xo({}, {
    next: function(e) {
        var t = dg(this).subscriptionState;
        if (!t.isClosed()) {
            var r = t.observer;
            try {
                var n = pe(r, "next");
                n && ie(n, r, e)
            } catch (e) {}
        }
    },
    error: function(e) {
        var t = dg(this).subscriptionState;
        if (!t.isClosed()) {
            var r = t.observer;
            t.close();
            try {
                var n = pe(r, "error");
                n && ie(n, r, e)
            } catch (e) {}
            t.clean()
        }
    },
    complete: function() {
        var e = dg(this).subscriptionState;
        if (!e.isClosed()) {
            var t = e.observer;
            e.close();
            try {
                var r = pe(t, "complete");
                r && ie(r, t)
            } catch (e) {}
            e.clean()
        }
    }
}), Y && Zn(vg.prototype, "closed", {
    configurable: !0,
    get: function() {
        return dg(this).subscriptionState.isClosed()
    }
});
var yg = function(e) {
        jo(this, gg), cg(this, {
            type: ig,
            subscriber: he(e)
        })
    },
    gg = yg.prototype;
Xo(gg, {
    subscribe: function(e) {
        var t = arguments.length;
        return new pg(K(e) ? {
            next: e,
            error: t > 1 ? arguments[1] : void 0,
            complete: t > 2 ? arguments[2] : void 0
        } : q(e) ? e : {}, fg(this).subscriber)
    }
}), Et(gg, og, function() {
    return this
}), Zt({
    global: !0,
    constructor: !0,
    forced: !0
}, {
    Observable: yg
}), wp(ig);
var bg = H("observable");
Zt({
    target: "Observable",
    stat: !0,
    forced: !0
}, {
    from: function(e) {
        var t = js(this) ? this : ae("Observable"),
            r = pe(ne(e), bg);
        if (r) {
            var n = ne(ie(r, e));
            return n.constructor === t ? n : new t(function(e) {
                return n.subscribe(e)
            })
        }
        var o = ea(e);
        return new t(function(e) {
            oa(o, function(t, r) {
                if (e.next(t), e.closed) return r()
            }, {
                IS_ITERATOR: !0,
                INTERRUPTED: !0
            }), e.complete()
        })
    }
});
var mg = ae("Array");
Zt({
    target: "Observable",
    stat: !0,
    forced: !0
}, { of: function() {
        for (var e = js(this) ? this : ae("Observable"), t = arguments.length, r = mg(t), n = 0; n < t;) r[n] = arguments[n++];
        return new e(function(e) {
            for (var n = 0; n < t; n++)
                if (e.next(r[n]), e.closed) return;
            e.complete()
        })
    }
});
var wg = ae("Map"),
    Eg = ae("WeakMap"),
    _g = h([].push),
    Tg = A("metadata"),
    Sg = Tg.store || (Tg.store = new Eg),
    Ag = function(e, t, r) {
        var n = Sg.get(e);
        if (!n) {
            if (!r) return;
            Sg.set(e, n = new wg)
        }
        var o = n.get(t);
        if (!o) {
            if (!r) return;
            n.set(t, o = new wg)
        }
        return o
    },
    Ig = {
        store: Sg,
        getMap: Ag,
        has: function(e, t, r) {
            var n = Ag(t, r, !1);
            return void 0 !== n && n.has(e)
        },
        get: function(e, t, r) {
            var n = Ag(t, r, !1);
            return void 0 === n ? void 0 : n.get(e)
        },
        set: function(e, t, r, n) {
            Ag(r, n, !0).set(e, t)
        },
        keys: function(e, t) {
            var r = Ag(e, t, !1),
                n = [];
            return r && r.forEach(function(e, t) {
                _g(n, t)
            }), n
        },
        toKey: function(e) {
            return void 0 === e || "symbol" == typeof e ? e : String(e)
        }
    },
    Og = Ig.toKey,
    Rg = Ig.set;
Zt({
    target: "Reflect",
    stat: !0
}, {
    defineMetadata: function(e, t, r) {
        var n = arguments.length < 4 ? void 0 : Og(arguments[3]);
        Rg(e, t, ne(r), n)
    }
});
var Ng = Ig.toKey,
    Pg = Ig.getMap,
    Mg = Ig.store;
Zt({
    target: "Reflect",
    stat: !0
}, {
    deleteMetadata: function(e, t) {
        var r = arguments.length < 3 ? void 0 : Ng(arguments[2]),
            n = Pg(ne(t), r, !1);
        if (void 0 === n || !n.delete(e)) return !1;
        if (n.size) return !0;
        var o = Mg.get(t);
        return o.delete(r), !!o.size || Mg.delete(t)
    }
});
var Dg = Ig.has,
    xg = Ig.get,
    Cg = Ig.toKey,
    kg = function(e, t, r) {
        if (Dg(e, t, r)) return xg(e, t, r);
        var n = br(t);
        return null !== n ? kg(e, n, r) : void 0
    };
Zt({
    target: "Reflect",
    stat: !0
}, {
    getMetadata: function(e, t) {
        var r = arguments.length < 3 ? void 0 : Cg(arguments[2]);
        return kg(e, ne(t), r)
    }
});
var Lg = h(ih),
    jg = h([].concat),
    Xg = Ig.keys,
    Ug = Ig.toKey,
    Bg = function(e, t) {
        var r = Xg(e, t),
            n = br(e);
        if (null === n) return r;
        var o = Bg(n, t);
        return o.length ? r.length ? Lg(jg(r, o)) : o : r
    };
Zt({
    target: "Reflect",
    stat: !0
}, {
    getMetadataKeys: function(e) {
        var t = arguments.length < 2 ? void 0 : Ug(arguments[1]);
        return Bg(ne(e), t)
    }
});
var Fg = Ig.get,
    Vg = Ig.toKey;
Zt({
    target: "Reflect",
    stat: !0
}, {
    getOwnMetadata: function(e, t) {
        var r = arguments.length < 3 ? void 0 : Vg(arguments[2]);
        return Fg(e, ne(t), r)
    }
});
var zg = Ig.keys,
    Hg = Ig.toKey;
Zt({
    target: "Reflect",
    stat: !0
}, {
    getOwnMetadataKeys: function(e) {
        var t = arguments.length < 2 ? void 0 : Hg(arguments[1]);
        return zg(ne(e), t)
    }
});
var Wg = Ig.has,
    Yg = Ig.toKey,
    Gg = function(e, t, r) {
        if (Wg(e, t, r)) return !0;
        var n = br(t);
        return null !== n && Gg(e, n, r)
    };
Zt({
    target: "Reflect",
    stat: !0
}, {
    hasMetadata: function(e, t) {
        var r = arguments.length < 3 ? void 0 : Yg(arguments[2]);
        return Gg(e, ne(t), r)
    }
});
var Kg = Ig.has,
    qg = Ig.toKey;
Zt({
    target: "Reflect",
    stat: !0
}, {
    hasOwnMetadata: function(e, t) {
        var r = arguments.length < 3 ? void 0 : qg(arguments[2]);
        return Kg(e, ne(t), r)
    }
});
var $g = Ig.toKey,
    Qg = Ig.set;
Zt({
    target: "Reflect",
    stat: !0
}, {
    metadata: function(e, t) {
        return function(r, n) {
            Qg(e, t, ne(r), $g(n))
        }
    }
});
var Jg = Qc.add;
Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: !0
}, {
    addAll: function() {
        for (var e = Zc(this), t = 0, r = arguments.length; t < r; t++) Jg(e, arguments[t]);
        return e
    }
});
var Zg = Qc.remove;
Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: !0
}, {
    deleteAll: function() {
        for (var e, t = Zc(this), r = !0, n = 0, o = arguments.length; n < o; n++) e = Zg(t, arguments[n]), r = r && e;
        return !!r
    }
});
var eb = H("iterator"),
    tb = Object,
    rb = ae("Set"),
    nb = function(e) {
        return function(e) {
            return q(e) && "number" == typeof e.size && K(e.has) && K(e.keys)
        }(e) ? e : function(e) {
            if (p(e)) return !1;
            var t = tb(e);
            return void 0 !== t[eb] || "@@iterator" in t || w(mi, ir(t))
        }(e) ? new rb(e) : e
    };
Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: !0
}, {
    difference: function(e) {
        return ie(wf, this, nb(e))
    }
}), Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: !0
}, {
    every: function(e) {
        var t = Zc(this),
            r = rn(e, arguments.length > 1 ? arguments[1] : void 0);
        return !1 !== uf(t, function(e) {
            if (!r(e, e, t)) return !1
        }, !0)
    }
});
var ob = Qc.Set,
    ib = Qc.add;
Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: !0
}, {
    filter: function(e) {
        var t = Zc(this),
            r = rn(e, arguments.length > 1 ? arguments[1] : void 0),
            n = new ob;
        return uf(t, function(e) {
            r(e, e, t) && ib(n, e)
        }), n
    }
}), Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: !0
}, {
    find: function(e) {
        var t = Zc(this),
            r = rn(e, arguments.length > 1 ? arguments[1] : void 0),
            n = uf(t, function(e) {
                if (r(e, e, t)) return {
                    value: e
                }
            }, !0);
        return n && n.value
    }
}), Zt({
    target: "Set",
    stat: !0,
    forced: !0
}, {
    from: ny(Qc.Set, Qc.add, !1)
}), Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: !0
}, {
    intersection: function(e) {
        return ie(Nf, this, nb(e))
    }
}), Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: !0
}, {
    isDisjointFrom: function(e) {
        return ie(Df, this, nb(e))
    }
}), Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: !0
}, {
    isSubsetOf: function(e) {
        return ie(Cf, this, nb(e))
    }
}), Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: !0
}, {
    isSupersetOf: function(e) {
        return ie(jf, this, nb(e))
    }
});
var ab = h([].join),
    ub = h([].push);
Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: !0
}, {
    join: function(e) {
        var t = Zc(this),
            r = void 0 === e ? "," : Hr(e),
            n = [];
        return uf(t, function(e) {
            ub(n, e)
        }), ab(n, r)
    }
});
var sb = Qc.Set,
    cb = Qc.add;
Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: !0
}, {
    map: function(e) {
        var t = Zc(this),
            r = rn(e, arguments.length > 1 ? arguments[1] : void 0),
            n = new sb;
        return uf(t, function(e) {
            cb(n, r(e, e, t))
        }), n
    }
}), Zt({
    target: "Set",
    stat: !0,
    forced: !0
}, { of: yy(Qc.Set, Qc.add, !1)
});
var fb = TypeError;
Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: !0
}, {
    reduce: function(e) {
        var t = Zc(this),
            r = arguments.length < 2,
            n = r ? void 0 : arguments[1];
        if (he(e), uf(t, function(o) {
                r ? (r = !1, n = o) : n = e(n, o, o, t)
            }), r) throw new fb("Reduce of empty set with no initial value");
        return n
    }
}), Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: !0
}, {
    some: function(e) {
        var t = Zc(this),
            r = rn(e, arguments.length > 1 ? arguments[1] : void 0);
        return !0 === uf(t, function(e) {
            if (r(e, e, t)) return !0
        }, !0)
    }
}), Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: !0
}, {
    symmetricDifference: function(e) {
        return ie(Vf, this, nb(e))
    }
}), Zt({
    target: "Set",
    proto: !0,
    real: !0,
    forced: !0
}, {
    union: function(e) {
        return ie(Yf, this, nb(e))
    }
});
var lb = h("".charAt),
    db = h("".charCodeAt),
    hb = h("".slice),
    pb = function(e) {
        return function(t, r) {
            var n, o, i = Hr(y(t)),
                a = At(r),
                u = i.length;
            return a < 0 || a >= u ? e ? "" : void 0 : (n = db(i, a)) < 55296 || n > 56319 || a + 1 === u || (o = db(i, a + 1)) < 56320 || o > 57343 ? e ? lb(i, a) : n : e ? hb(i, a, a + 2) : o - 56320 + (n - 55296 << 10) + 65536
        }
    },
    vb = {
        codeAt: pb(!1),
        charAt: pb(!0)
    },
    yb = vb.charAt;
Zt({
    target: "String",
    proto: !0,
    forced: !0
}, {
    at: function(e) {
        var t = Hr(y(this)),
            r = t.length,
            n = At(e),
            o = n >= 0 ? n : r + n;
        return o < 0 || o >= r ? void 0 : yb(t, o)
    }
});
var gb = TypeError,
    bb = h([].push),
    mb = h([].join),
    wb = function(e) {
        var t = Fe(e),
            r = Mt(t);
        if (!r) return "";
        for (var n = arguments.length, o = [], i = 0;;) {
            var a = t[i++];
            if (void 0 === a) throw new gb("Incorrect template");
            if (bb(o, Hr(a)), i === r) return mb(o, "");
            i < n && bb(o, Hr(arguments[i]))
        }
    };
Zt({
    target: "String",
    stat: !0,
    forced: !0
}, {
    cooked: wb
});
var Eb = vb.codeAt,
    _b = vb.charAt,
    Tb = "String Iterator",
    Sb = mt.set,
    Ab = mt.getterFor(Tb),
    Ib = Fh(function(e) {
        Sb(this, {
            type: Tb,
            string: e,
            index: 0
        })
    }, "String", function() {
        var e, t = Ab(this),
            r = t.string,
            n = t.index;
        return n >= r.length ? _i(void 0, !0) : (e = _b(r, n), t.index += e.length, _i({
            codePoint: Eb(e, 0),
            position: n
        }, !1))
    });
Zt({
    target: "String",
    proto: !0,
    forced: !0
}, {
    codePoints: function() {
        return new Ib(Hr(y(this)))
    }
});
var Ob = WeakMap.prototype,
    Rb = {
        WeakMap: WeakMap,
        set: h(Ob.set),
        get: h(Ob.get),
        has: h(Ob.has),
        remove: h(Ob.delete)
    },
    Nb = String.fromCharCode,
    Pb = ae("String", "fromCodePoint"),
    Mb = h("".charAt),
    Db = h("".charCodeAt),
    xb = h("".indexOf),
    Cb = h("".slice),
    kb = function(e, t) {
        var r = Db(e, t);
        return r >= 48 && r <= 57
    },
    Lb = function(e, t, r) {
        if (r >= e.length) return -1;
        for (var n = 0; t < r; t++) {
            var o = jb(Db(e, t));
            if (-1 === o) return -1;
            n = 16 * n + o
        }
        return n
    },
    jb = function(e) {
        return e >= 48 && e <= 57 ? e - 48 : e >= 97 && e <= 102 ? e - 97 + 10 : e >= 65 && e <= 70 ? e - 65 + 10 : -1
    },
    Xb = function(e) {
        for (var t, r = "", n = 0, o = 0;
            (o = xb(e, "\\", o)) > -1;) {
            if (r += Cb(e, n, o), ++o === e.length) return;
            var i = Mb(e, o++);
            switch (i) {
                case "b":
                    r += "\b";
                    break;
                case "t":
                    r += "\t";
                    break;
                case "n":
                    r += "\n";
                    break;
                case "v":
                    r += "\v";
                    break;
                case "f":
                    r += "\f";
                    break;
                case "r":
                    r += "\r";
                    break;
                case "\r":
                    o < e.length && "\n" === Mb(e, o) && ++o;
                case "\n":
                case "\u2028":
                case "\u2029":
                    break;
                case "0":
                    if (kb(e, o)) return;
                    r += "\0";
                    break;
                case "x":
                    if (-1 === (t = Lb(e, o, o + 2))) return;
                    o += 2, r += Nb(t);
                    break;
                case "u":
                    if (o < e.length && "{" === Mb(e, o)) {
                        var a = xb(e, "}", ++o);
                        if (-1 === a) return;
                        t = Lb(e, o, a), o = a + 1
                    } else t = Lb(e, o, o + 4), o += 4;
                    if (-1 === t || t > 1114111) return;
                    r += Pb(t);
                    break;
                default:
                    if (kb(i, 0)) return;
                    r += i
            }
            n = o
        }
        return r + Cb(e, n)
    },
    Ub = Oe.f,
    Bb = new Rb.WeakMap,
    Fb = Rb.get,
    Vb = Rb.has,
    zb = Rb.set,
    Hb = Array,
    Wb = TypeError,
    Yb = Object.freeze || Object,
    Gb = Object.isFrozen,
    Kb = Math.min,
    qb = h("".charAt),
    $b = h("".slice),
    Qb = h("".split),
    Jb = h(/./.exec),
    Zb = /([\n\u2028\u2029]|\r\n?)/g,
    em = RegExp("^[" + Mc + "]*"),
    tm = RegExp("[^" + Mc + "]"),
    rm = "Invalid tag",
    nm = function(e, t) {
        if (void 0 === t || e === t) return e;
        for (var r = 0, n = Kb(e.length, t.length); r < n && qb(e, r) === qb(t, r); r++);
        return $b(e, 0, r)
    },
    om = function(e) {
        return wt(function(t) {
            var r = Su(arguments);
            return r[0] = function(e) {
                var t = e.raw;
                if (vu && !Gb(t)) throw new Wb("Raw template should be frozen");
                if (Vb(Bb, t)) return Fb(Bb, t);
                var r = function(e) {
                        var t, r, n, o, i = b(e),
                            a = Mt(i),
                            u = Hb(a),
                            s = Hb(a),
                            c = 0;
                        if (!a) throw new Wb(rm);
                        for (; c < a; c++) {
                            var f = i[c];
                            if ("string" != typeof f) throw new Wb(rm);
                            u[c] = Qb(f, Zb)
                        }
                        for (c = 0; c < a; c++) {
                            var l = c + 1 === a;
                            if (t = u[c], 0 === c) {
                                if (1 === t.length || t[0].length > 0) throw new Wb("Invalid opening line");
                                t[1] = ""
                            }
                            if (l) {
                                if (1 === t.length || Jb(tm, t[t.length - 1])) throw new Wb("Invalid closing line");
                                t[t.length - 2] = "", t[t.length - 1] = ""
                            }
                            for (var d = 2; d < t.length; d += 2) {
                                var h = t[d],
                                    p = d + 1 === t.length && !l,
                                    v = Jb(em, h)[0];
                                p || v.length !== h.length ? r = nm(v, r) : t[d] = ""
                            }
                        }
                        var y = r ? r.length : 0;
                        for (c = 0; c < a; c++) {
                            for (n = (t = u[c])[0], o = 1; o < t.length; o += 2) n += t[o] + $b(t[o + 1], y);
                            s[c] = n
                        }
                        return s
                    }(t),
                    n = function(e) {
                        for (var t = 0, r = e.length, n = Hb(r); t < r; t++) n[t] = Xb(e[t]);
                        return n
                    }(r);
                return Ub(n, "raw", {
                    value: Yb(r)
                }), Yb(n), zb(Bb, t, n), n
            }(ne(t)), Ra(e, this, r)
        }, "")
    },
    im = om(wb);
Zt({
    target: "String",
    stat: !0,
    forced: !0
}, {
    dedent: function(e) {
        return ne(e), K(e) ? om(e) : Ra(im, this, arguments)
    }
}), Ne("customMatcher");
var am = ae("Symbol"),
    um = am.keyFor,
    sm = h(am.prototype.valueOf),
    cm = am.isRegisteredSymbol || function(e) {
        try {
            return void 0 !== um(sm(e))
        } catch (e) {
            return !1
        }
    };
Zt({
    target: "Symbol",
    stat: !0
}, {
    isRegisteredSymbol: cm
}), Zt({
    target: "Symbol",
    stat: !0,
    name: "isRegisteredSymbol"
}, {
    isRegistered: cm
});
for (var fm = ae("Symbol"), lm = fm.isWellKnownSymbol, dm = ae("Object", "getOwnPropertyNames"), hm = h(fm.prototype.valueOf), pm = A("wks"), vm = 0, ym = dm(fm), gm = ym.length; vm < gm; vm++) try {
    var bm = ym[vm];
    ce(fm[bm]) && H(bm)
} catch (e) {}
var mm = function(e) {
    if (lm && lm(e)) return !0;
    try {
        for (var t = hm(e), r = 0, n = dm(pm), o = n.length; r < o; r++)
            if (pm[n[r]] == t) return !0
    } catch (e) {}
    return !1
};
Zt({
    target: "Symbol",
    stat: !0,
    forced: !0
}, {
    isWellKnownSymbol: mm
}), Zt({
    target: "Symbol",
    stat: !0,
    name: "isWellKnownSymbol",
    forced: !0
}, {
    isWellKnown: mm
}), Ne("matcher"), Ne("metadata"), Ne("metadataKey"), Ne("observable"), Ne("patternMatch"), Ne("replaceAll");
var wm = TypeError,
    Em = Tl.aTypedArrayConstructor;
(0, Tl.exportTypedArrayStaticMethod)("fromAsync", function(e) {
    var t = this,
        r = arguments.length,
        n = r > 1 ? arguments[1] : void 0,
        o = r > 2 ? arguments[2] : void 0;
    return new(ae("Promise"))(function(r) {
        ! function(e) {
            if (js(e)) return e;
            throw new wm(le(e) + " is not a constructor")
        }(t), r(ac(e, n, o))
    }).then(function(e) {
        return Tn(Em(t), e)
    })
}, !0);
var _m = Tl.getTypedArrayConstructor,
    Tm = function(e, t) {
        return Tn(_m(e), t)
    },
    Sm = Cd.filterReject,
    Am = Tl.aTypedArray;
(0, Tl.exportTypedArrayMethod)("filterOut", function(e) {
    var t = Sm(Am(this), e, arguments.length > 1 ? arguments[1] : void 0);
    return Tm(this, t)
}, !0);
var Im = Cd.filterReject,
    Om = Tl.aTypedArray;
(0, Tl.exportTypedArrayMethod)("filterReject", function(e) {
    var t = Im(Om(this), e, arguments.length > 1 ? arguments[1] : void 0);
    return Tm(this, t)
}, !0);
var Rm = Tl.aTypedArray,
    Nm = Tl.getTypedArrayConstructor;
(0, Tl.exportTypedArrayMethod)("groupBy", function(e) {
    var t = arguments.length > 1 ? arguments[1] : void 0;
    return Ud(Rm(this), e, t, Nm)
}, !0);
var Pm = Tl.aTypedArray,
    Mm = Tl.getTypedArrayConstructor,
    Dm = Tl.exportTypedArrayMethod,
    xm = Math.max,
    Cm = Math.min;
Dm("toSpliced", function(e, t) {
    var r, n, o, i, a, u, s, c = Pm(this),
        f = Mm(c),
        l = Mt(c),
        d = Rt(e, l),
        h = arguments.length,
        p = 0;
    if (0 === h) r = n = 0;
    else if (1 === h) r = 0, n = l - d;
    else if (n = Cm(xm(At(t), 0), l - d), r = h - 2) {
        i = new f(r), o = Cl(i);
        for (var v = 2; v < h; v++) a = arguments[v], i[v - 2] = o ? Ll(a) : +a
    }
    for (s = new f(u = l + r - n); p < d; p++) s[p] = c[p];
    for (; p < d + r; p++) s[p] = i[p - d];
    for (; p < u; p++) s[p] = c[p + n - r];
    return s
}, !0);
var km = Tl.aTypedArray,
    Lm = Tl.getTypedArrayConstructor,
    jm = Tl.exportTypedArrayMethod,
    Xm = h(ih);
jm("uniqueBy", function(e) {
    return km(this), Tn(Lm(this), Xm(this, e))
}, !0);
var Um = Rb.has,
    Bm = function(e) {
        return Um(e), e
    },
    Fm = Rb.remove;
Zt({
    target: "WeakMap",
    proto: !0,
    real: !0,
    forced: !0
}, {
    deleteAll: function() {
        for (var e, t = Bm(this), r = !0, n = 0, o = arguments.length; n < o; n++) e = Fm(t, arguments[n]), r = r && e;
        return !!r
    }
}), Zt({
    target: "WeakMap",
    stat: !0,
    forced: !0
}, {
    from: ny(Rb.WeakMap, Rb.set, !0)
}), Zt({
    target: "WeakMap",
    stat: !0,
    forced: !0
}, { of: yy(Rb.WeakMap, Rb.set, !0)
});
var Vm = Rb.get,
    zm = Rb.has,
    Hm = Rb.set;
Zt({
    target: "WeakMap",
    proto: !0,
    real: !0,
    forced: !0
}, {
    emplace: function(e, t) {
        var r, n, o = Bm(this);
        return zm(o, e) ? (r = Vm(o, e), "update" in t && (r = t.update(r, e, o), Hm(o, e, r)), r) : (n = t.insert(e, o), Hm(o, e, n), n)
    }
});
var Wm = Rb.get,
    Ym = Rb.has,
    Gm = Rb.set;
Zt({
    target: "WeakMap",
    proto: !0,
    real: !0,
    forced: E
}, {
    getOrInsert: function(e, t) {
        return Ym(Bm(this), e) ? Wm(this, e) : (Gm(this, e, t), t)
    }
});
var Km = new Rb.WeakMap,
    qm = Rb.set,
    $m = Rb.remove,
    Qm = Rb.get,
    Jm = Rb.has,
    Zm = Rb.set,
    ew = ! function() {
        try {
            WeakMap.prototype.getOrInsertComputed && (new WeakMap).getOrInsertComputed(1, function() {
                throw 1
            })
        } catch (e) {
            return e instanceof TypeError
        }
    }();
Zt({
    target: "WeakMap",
    proto: !0,
    real: !0,
    forced: ew
}, {
    getOrInsertComputed: function(e, t) {
        if (Bm(this), function(e) {
                qm(Km, e, 1), $m(Km, e)
            }(e), he(t), Jm(this, e)) return Qm(this, e);
        var r = t(e);
        return Zm(this, e, r), r
    }
}), Zt({
    target: "WeakMap",
    proto: !0,
    real: !0,
    forced: !0
}, {
    upsert: Ty
});
var tw = WeakSet.prototype,
    rw = {
        WeakSet: WeakSet,
        add: h(tw.add),
        has: h(tw.has),
        remove: h(tw.delete)
    },
    nw = rw.has,
    ow = function(e) {
        return nw(e), e
    },
    iw = rw.add;
Zt({
    target: "WeakSet",
    proto: !0,
    real: !0,
    forced: !0
}, {
    addAll: function() {
        for (var e = ow(this), t = 0, r = arguments.length; t < r; t++) iw(e, arguments[t]);
        return e
    }
});
var aw = rw.remove;
Zt({
    target: "WeakSet",
    proto: !0,
    real: !0,
    forced: !0
}, {
    deleteAll: function() {
        for (var e, t = ow(this), r = !0, n = 0, o = arguments.length; n < o; n++) e = aw(t, arguments[n]), r = r && e;
        return !!r
    }
}), Zt({
    target: "WeakSet",
    stat: !0,
    forced: !0
}, {
    from: ny(rw.WeakSet, rw.add, !1)
}), Zt({
    target: "WeakSet",
    stat: !0,
    forced: !0
}, { of: yy(rw.WeakSet, rw.add, !1)
});
var uw = {
        IndexSizeError: {
            s: "INDEX_SIZE_ERR",
            c: 1,
            m: 1
        },
        DOMStringSizeError: {
            s: "DOMSTRING_SIZE_ERR",
            c: 2,
            m: 0
        },
        HierarchyRequestError: {
            s: "HIERARCHY_REQUEST_ERR",
            c: 3,
            m: 1
        },
        WrongDocumentError: {
            s: "WRONG_DOCUMENT_ERR",
            c: 4,
            m: 1
        },
        InvalidCharacterError: {
            s: "INVALID_CHARACTER_ERR",
            c: 5,
            m: 1
        },
        NoDataAllowedError: {
            s: "NO_DATA_ALLOWED_ERR",
            c: 6,
            m: 0
        },
        NoModificationAllowedError: {
            s: "NO_MODIFICATION_ALLOWED_ERR",
            c: 7,
            m: 1
        },
        NotFoundError: {
            s: "NOT_FOUND_ERR",
            c: 8,
            m: 1
        },
        NotSupportedError: {
            s: "NOT_SUPPORTED_ERR",
            c: 9,
            m: 1
        },
        InUseAttributeError: {
            s: "INUSE_ATTRIBUTE_ERR",
            c: 10,
            m: 1
        },
        InvalidStateError: {
            s: "INVALID_STATE_ERR",
            c: 11,
            m: 1
        },
        SyntaxError: {
            s: "SYNTAX_ERR",
            c: 12,
            m: 1
        },
        InvalidModificationError: {
            s: "INVALID_MODIFICATION_ERR",
            c: 13,
            m: 1
        },
        NamespaceError: {
            s: "NAMESPACE_ERR",
            c: 14,
            m: 1
        },
        InvalidAccessError: {
            s: "INVALID_ACCESS_ERR",
            c: 15,
            m: 1
        },
        ValidationError: {
            s: "VALIDATION_ERR",
            c: 16,
            m: 0
        },
        TypeMismatchError: {
            s: "TYPE_MISMATCH_ERR",
            c: 17,
            m: 1
        },
        SecurityError: {
            s: "SECURITY_ERR",
            c: 18,
            m: 1
        },
        NetworkError: {
            s: "NETWORK_ERR",
            c: 19,
            m: 1
        },
        AbortError: {
            s: "ABORT_ERR",
            c: 20,
            m: 1
        },
        URLMismatchError: {
            s: "URL_MISMATCH_ERR",
            c: 21,
            m: 1
        },
        QuotaExceededError: {
            s: "QUOTA_EXCEEDED_ERR",
            c: 22,
            m: 1
        },
        TimeoutError: {
            s: "TIMEOUT_ERR",
            c: 23,
            m: 1
        },
        InvalidNodeTypeError: {
            s: "INVALID_NODE_TYPE_ERR",
            c: 24,
            m: 1
        },
        DataCloneError: {
            s: "DATA_CLONE_ERR",
            c: 25,
            m: 1
        }
    },
    sw = Oe.f,
    cw = "DOMException",
    fw = ae("Error"),
    lw = ae(cw),
    dw = function() {
        jo(this, hw);
        var e = arguments.length,
            t = Wr(e < 1 ? void 0 : arguments[0]),
            r = Wr(e < 2 ? void 0 : arguments[1], "Error"),
            n = new lw(t, r),
            o = new fw(t);
        return o.name = cw, sw(n, "stack", Ce(1, Br(o.stack, 1))), sp(n, this, dw), n
    },
    hw = dw.prototype = lw.prototype,
    pw = "stack" in new fw(cw),
    vw = "stack" in new lw(1, 2),
    yw = lw && Y && Object.getOwnPropertyDescriptor(a, cw),
    gw = !(!yw || yw.writable && yw.configurable),
    bw = pw && !gw && !vw;
Zt({
    global: !0,
    constructor: !0,
    forced: bw
}, {
    DOMException: bw ? dw : lw
});
var mw = ae(cw),
    ww = mw.prototype;
if (ww.constructor !== mw)
    for (var Ew in sw(ww, "constructor", Ce(1, mw)), uw)
        if (w(uw, Ew)) {
            var _w = uw[Ew],
                Tw = _w.s;
            w(mw, Tw) || sw(mw, Tw, Ce(6, _w.c))
        }
var Sw, Aw, Iw, Ow, Rw = TypeError,
    Nw = function(e, t) {
        if (e < t) throw new Rw("Not enough arguments");
        return e
    },
    Pw = /(?:ipad|iphone|ipod).*applewebkit/i.test(D),
    Mw = a.setImmediate,
    Dw = a.clearImmediate,
    xw = a.process,
    Cw = a.Dispatch,
    kw = a.Function,
    Lw = a.MessageChannel,
    jw = a.String,
    Xw = 0,
    Uw = {},
    Bw = "onreadystatechange";
s(function() {
    Sw = a.location
});
var Fw = function(e) {
        if (w(Uw, e)) {
            var t = Uw[e];
            delete Uw[e], t()
        }
    },
    Vw = function(e) {
        return function() {
            Fw(e)
        }
    },
    zw = function(e) {
        Fw(e.data)
    },
    Hw = function(e) {
        a.postMessage(jw(e), Sw.protocol + "//" + Sw.host)
    };
Mw && Dw || (Mw = function(e) {
    Nw(arguments.length, 1);
    var t = K(e) ? e : kw(e),
        r = Su(arguments, 1);
    return Uw[++Xw] = function() {
        Ra(t, void 0, r)
    }, Aw(Xw), Xw
}, Dw = function(e) {
    delete Uw[e]
}, yo ? Aw = function(e) {
    xw.nextTick(Vw(e))
} : Cw && Cw.now ? Aw = function(e) {
    Cw.now(Vw(e))
} : Lw && !Pw ? (Ow = (Iw = new Lw).port2, Iw.port1.onmessage = zw, Aw = rn(Ow.postMessage, Ow)) : a.addEventListener && K(a.postMessage) && !a.importScripts && Sw && "file:" !== Sw.protocol && !s(Hw) ? (Aw = Hw, a.addEventListener("message", zw, !1)) : Aw = Bw in J("script") ? function(e) {
    Ir.appendChild(J("script"))[Bw] = function() {
        Ir.removeChild(this), Fw(e)
    }
} : function(e) {
    setTimeout(Vw(e), 0)
});
var Ww = {
        set: Mw,
        clear: Dw
    },
    Yw = Ww.clear;
Zt({
    global: !0,
    bind: !0,
    enumerable: !0,
    forced: a.clearImmediate !== Yw
}, {
    clearImmediate: Yw
});
var Gw = a.Function,
    Kw = /MSIE .\./.test(D) || "BUN" === vo && function() {
        var e = a.Bun.version.split(".");
        return e.length < 3 || "0" === e[0] && (e[1] < 3 || "3" === e[1] && "0" === e[2])
    }(),
    qw = Ww.set,
    $w = a.setImmediate ? function(e) {
        return Kw ? function(t, r) {
            var n = Nw(arguments.length, 1) > 1,
                o = K(t) ? t : Gw(t),
                i = n ? Su(arguments, 1) : [],
                a = n ? function() {
                    Ra(o, this, i)
                } : o;
            return e(a)
        } : e
    }(qw) : qw;
Zt({
    global: !0,
    bind: !0,
    enumerable: !0,
    forced: a.setImmediate !== $w
}, {
    setImmediate: $w
});
var Qw = RegExp.prototype,
    Jw = Kc.correct ? function(e) {
        return e.flags
    } : function(e) {
        return Kc.correct || !ue(Qw, e) || w(e, "flags") ? e.flags : ie(qc, e)
    },
    Zw = a.Object,
    eE = a.Array,
    tE = a.Date,
    rE = a.Error,
    nE = a.TypeError,
    oE = a.PerformanceMark,
    iE = ae("DOMException"),
    aE = Wu.Map,
    uE = Wu.has,
    sE = Wu.get,
    cE = Wu.set,
    fE = Qc.Set,
    lE = Qc.add,
    dE = Qc.has,
    hE = ae("Object", "keys"),
    pE = h([].push),
    vE = h((!0).valueOf),
    yE = h(1.1.valueOf),
    gE = h("".valueOf),
    bE = h(tE.prototype.getTime),
    mE = N("structuredClone"),
    wE = "DataCloneError",
    EE = "Transferring",
    _E = function(e) {
        return !s(function() {
            var t = new a.Set([7]),
                r = e(t),
                n = e(Zw(7));
            return r === t || !r.has(7) || !q(n) || 7 !== +n
        }) && e
    },
    TE = function(e, t) {
        return !s(function() {
            var r = new t,
                n = e({
                    a: r,
                    b: r
                });
            return !(n && n.a === n.b && n.a instanceof t && n.a.stack === r.stack)
        })
    },
    SE = a.structuredClone,
    AE = !TE(SE, rE) || !TE(SE, iE) || ! function(e) {
        return !s(function() {
            var t = e(new a.AggregateError([1], mE, {
                cause: 3
            }));
            return "AggregateError" !== t.name || 1 !== t.errors[0] || t.message !== mE || 3 !== t.cause
        })
    }(SE),
    IE = !SE && _E(function(e) {
        return new oE(mE, {
            detail: e
        }).detail
    }),
    OE = _E(SE) || IE,
    RE = function(e) {
        throw new iE("Uncloneable type: " + e, wE)
    },
    NE = function(e, t) {
        throw new iE((t || "Cloning") + " of " + e + " cannot be properly polyfilled in this engine", wE)
    },
    PE = function(e, t) {
        return OE || NE(t), OE(e)
    },
    ME = function(e, t, r) {
        if (uE(t, e)) return sE(t, e);
        var n, o, i, u, s, c;
        if ("SharedArrayBuffer" === (r || ir(e))) n = OE ? OE(e) : e;
        else {
            var f = a.DataView;
            f || K(e.slice) || NE("ArrayBuffer");
            try {
                if (K(e.slice) && !e.resizable) n = e.slice(0);
                else {
                    o = e.byteLength, i = "maxByteLength" in e ? {
                        maxByteLength: e.maxByteLength
                    } : void 0, n = new ArrayBuffer(o, i), u = new f(e), s = new f(n);
                    for (c = 0; c < o; c++) s.setUint8(c, u.getUint8(c))
                }
            } catch (e) {
                throw new iE("ArrayBuffer is detached", wE)
            }
        }
        return cE(t, e, n), n
    },
    DE = function(e, t) {
        if (ce(e) && RE("Symbol"), !q(e)) return e;
        if (t) {
            if (uE(t, e)) return sE(t, e)
        } else t = new aE;
        var r, n, o, i, u, s, c, f, l = ir(e);
        switch (l) {
            case "Array":
                o = eE(Mt(e));
                break;
            case "Object":
                o = {};
                break;
            case "Map":
                o = new aE;
                break;
            case "Set":
                o = new fE;
                break;
            case "RegExp":
                o = new RegExp(e.source, Jw(e));
                break;
            case "Error":
                switch (n = e.name) {
                    case "AggregateError":
                        o = new(ae(n))([]);
                        break;
                    case "EvalError":
                    case "RangeError":
                    case "ReferenceError":
                    case "SuppressedError":
                    case "SyntaxError":
                    case "TypeError":
                    case "URIError":
                        o = new(ae(n));
                        break;
                    case "CompileError":
                    case "LinkError":
                    case "RuntimeError":
                        o = new(ae("WebAssembly", n));
                        break;
                    default:
                        o = new rE
                }
                break;
            case "DOMException":
                o = new iE(e.message, e.name);
                break;
            case "ArrayBuffer":
            case "SharedArrayBuffer":
                o = ME(e, t, l);
                break;
            case "DataView":
            case "Int8Array":
            case "Uint8Array":
            case "Uint8ClampedArray":
            case "Int16Array":
            case "Uint16Array":
            case "Int32Array":
            case "Uint32Array":
            case "Float16Array":
            case "Float32Array":
            case "Float64Array":
            case "BigInt64Array":
            case "BigUint64Array":
                s = "DataView" === l ? e.byteLength : e.length, o = function(e, t, r, n, o) {
                    var i = a[t];
                    return q(i) || NE(t), new i(ME(e.buffer, o), r, n)
                }(e, l, e.byteOffset, s, t);
                break;
            case "DOMQuad":
                try {
                    o = new DOMQuad(DE(e.p1, t), DE(e.p2, t), DE(e.p3, t), DE(e.p4, t))
                } catch (t) {
                    o = PE(e, l)
                }
                break;
            case "File":
                if (OE) try {
                    o = OE(e), ir(o) !== l && (o = void 0)
                } catch (e) {}
                if (!o) try {
                    o = new File([e], e.name, e)
                } catch (e) {}
                o || NE(l);
                break;
            case "FileList":
                if (i = function() {
                        var e;
                        try {
                            e = new a.DataTransfer
                        } catch (t) {
                            try {
                                e = new a.ClipboardEvent("").clipboardData
                            } catch (e) {}
                        }
                        return e && e.items && e.files ? e : null
                    }()) {
                    for (u = 0, s = Mt(e); u < s; u++) i.items.add(DE(e[u], t));
                    o = i.files
                } else o = PE(e, l);
                break;
            case "ImageData":
                try {
                    o = new ImageData(DE(e.data, t), e.width, e.height, {
                        colorSpace: e.colorSpace
                    })
                } catch (t) {
                    o = PE(e, l)
                }
                break;
            default:
                if (OE) o = OE(e);
                else switch (l) {
                    case "BigInt":
                        o = Zw(e.valueOf());
                        break;
                    case "Boolean":
                        o = Zw(vE(e));
                        break;
                    case "Number":
                        o = Zw(yE(e));
                        break;
                    case "String":
                        o = Zw(gE(e));
                        break;
                    case "Date":
                        o = new tE(bE(e));
                        break;
                    case "Blob":
                        try {
                            o = e.slice(0, e.size, e.type)
                        } catch (e) {
                            NE(l)
                        }
                        break;
                    case "DOMPoint":
                    case "DOMPointReadOnly":
                        r = a[l];
                        try {
                            o = r.fromPoint ? r.fromPoint(e) : new r(e.x, e.y, e.z, e.w)
                        } catch (e) {
                            NE(l)
                        }
                        break;
                    case "DOMRect":
                    case "DOMRectReadOnly":
                        r = a[l];
                        try {
                            o = r.fromRect ? r.fromRect(e) : new r(e.x, e.y, e.width, e.height)
                        } catch (e) {
                            NE(l)
                        }
                        break;
                    case "DOMMatrix":
                    case "DOMMatrixReadOnly":
                        r = a[l];
                        try {
                            o = r.fromMatrix ? r.fromMatrix(e) : new r(e)
                        } catch (e) {
                            NE(l)
                        }
                        break;
                    case "AudioData":
                    case "VideoFrame":
                        K(e.clone) || NE(l);
                        try {
                            o = e.clone()
                        } catch (e) {
                            RE(l)
                        }
                        break;
                    case "CropTarget":
                    case "CryptoKey":
                    case "FileSystemDirectoryHandle":
                    case "FileSystemFileHandle":
                    case "FileSystemHandle":
                    case "GPUCompilationInfo":
                    case "GPUCompilationMessage":
                    case "ImageBitmap":
                    case "RTCCertificate":
                    case "WebAssembly.Module":
                        NE(l);
                    default:
                        RE(l)
                }
        }
        switch (cE(t, e, o), l) {
            case "Array":
            case "Object":
                for (c = hE(e), u = 0, s = Mt(c); u < s; u++) f = c[u], ii(o, f, DE(e[f], t));
                break;
            case "Map":
                e.forEach(function(e, r) {
                    cE(o, DE(r, t), DE(e, t))
                });
                break;
            case "Set":
                e.forEach(function(e) {
                    lE(o, DE(e, t))
                });
                break;
            case "Error":
                Ze(o, "message", DE(e.message, t)), w(e, "cause") && Ze(o, "cause", DE(e.cause, t)), "AggregateError" === n ? o.errors = DE(e.errors, t) : "SuppressedError" === n && (o.error = DE(e.error, t), o.suppressed = DE(e.suppressed, t));
            case "DOMException":
                Fr && Ze(o, "stack", DE(e.stack, t))
        }
        return o
    };
Zt({
    global: !0,
    enumerable: !0,
    sham: !bo,
    forced: AE
}, {
    structuredClone: function(e) {
        var t, r, n = Nw(arguments.length, 1) > 1 && !p(arguments[1]) ? ne(arguments[1]) : void 0,
            o = n ? n.transfer : void 0;
        void 0 !== o && (r = function(e, t) {
            if (!q(e)) throw new nE("Transfer option cannot be converted to a sequence");
            var r = [];
            oa(e, function(e) {
                pE(r, ne(e))
            });
            for (var n, o, i, u, s, c = 0, f = Mt(r), l = new fE; c < f;) {
                if (n = r[c++], "ArrayBuffer" === (o = ir(n)) ? dE(l, n) : uE(t, n)) throw new iE("Duplicate transferable", wE);
                if ("ArrayBuffer" !== o) {
                    if (bo) u = SE(n, {
                        transfer: [n]
                    });
                    else switch (o) {
                        case "ImageBitmap":
                            i = a.OffscreenCanvas, js(i) || NE(o, EE);
                            try {
                                (s = new i(n.width, n.height)).getContext("bitmaprenderer").transferFromImageBitmap(n), u = s.transferToImageBitmap()
                            } catch (e) {}
                            break;
                        case "AudioData":
                        case "VideoFrame":
                            K(n.clone) && K(n.close) || NE(o, EE);
                            try {
                                u = n.clone(), n.close()
                            } catch (e) {}
                            break;
                        case "MediaSourceHandle":
                        case "MessagePort":
                        case "MIDIAccess":
                        case "OffscreenCanvas":
                        case "ReadableStream":
                        case "RTCDataChannel":
                        case "TransformStream":
                        case "WebTransportReceiveStream":
                        case "WebTransportSendStream":
                        case "WritableStream":
                            NE(o, EE)
                    }
                    if (void 0 === u) throw new iE("This object cannot be transferred: " + o, wE);
                    cE(t, n, u)
                } else lE(l, n)
            }
            return l
        }(o, t = new aE));
        var i = DE(e, t);
        return r && function(e) {
            uf(e, function(e) {
                bo ? OE(e, {
                    transfer: [e]
                }) : K(e.transfer) ? e.transfer() : To ? To(e) : NE("ArrayBuffer", EE)
            })
        }(r), i
    }
});
var xE = H("iterator"),
    CE = !s(function() {
        var e = new URL("b?a=1&b=2&c=3", "https://a"),
            t = e.searchParams,
            r = new URLSearchParams("a=1&a=2&b=3"),
            n = "";
        return e.pathname = "c%20d", t.forEach(function(e, r) {
            t.delete("b"), n += r + e
        }), r.delete("a", 2), r.delete("b", void 0), !t.size && !Y || !t.sort || "https://a/c%20d?a=1&c=3" !== e.href || "3" !== t.get("c") || "a=1" !== String(new URLSearchParams("?a=1")) || !t[xE] || "a" !== new URL("https://a@b").username || "b" !== new URLSearchParams(new URLSearchParams("a=b")).get("a") || "xn--e1aybc" !== new URL("https://тест").host || "#%D0%B1" !== new URL("https://a#б").hash || "a1c3" !== n || "x" !== new URL("https://x", void 0).host
    }),
    kE = ae("URL"),
    LE = CE && s(function() {
        kE.canParse()
    }),
    jE = s(function() {
        return 1 !== kE.canParse.length
    });
Zt({
    target: "URL",
    stat: !0,
    forced: !LE || jE
}, {
    canParse: function(e) {
        var t = Nw(arguments.length, 1),
            r = Hr(e),
            n = t < 2 || void 0 === arguments[1] ? void 0 : Hr(arguments[1]);
        try {
            return !!new kE(r, n)
        } catch (e) {
            return !1
        }
    }
});
var XE = ae("URL");
Zt({
    target: "URL",
    stat: !0,
    forced: !CE
}, {
    parse: function(e) {
        var t = Nw(arguments.length, 1),
            r = Hr(e),
            n = t < 2 || void 0 === arguments[1] ? void 0 : Hr(arguments[1]);
        try {
            return new XE(r, n)
        } catch (e) {
            return null
        }
    }
});
var UE = URLSearchParams,
    BE = UE.prototype,
    FE = h(BE.append),
    VE = h(BE.delete),
    zE = h(BE.forEach),
    HE = h([].push),
    WE = new UE("a=1&a=2&b=3");
WE.delete("a", 1), WE.delete("b", void 0), WE + "" != "a=2" && Et(BE, "delete", function(e) {
    var t = arguments.length,
        r = t < 2 ? void 0 : arguments[1];
    if (t && void 0 === r) return VE(this, e);
    var n = [];
    zE(this, function(e, t) {
        HE(n, {
            key: t,
            value: e
        })
    }), Nw(t, 1);
    for (var o, i = Hr(e), a = Hr(r), u = 0, s = 0, c = !1, f = n.length; u < f;) o = n[u++], c || o.key === i ? (c = !0, VE(this, o.key)) : s++;
    for (; s < f;)(o = n[s++]).key === i && o.value === a || FE(this, o.key, o.value)
}, {
    enumerable: !0,
    unsafe: !0
});
var YE = URLSearchParams,
    GE = YE.prototype,
    KE = h(GE.getAll),
    qE = h(GE.has),
    $E = new YE("a=1");
!$E.has("a", 2) && $E.has("a", void 0) || Et(GE, "has", function(e) {
    var t = arguments.length,
        r = t < 2 ? void 0 : arguments[1];
    if (t && void 0 === r) return qE(this, e);
    var n = KE(this, e);
    Nw(t, 1);
    for (var o = Hr(r), i = 0; i < n.length;)
        if (n[i++] === o) return !0;
    return !1
}, {
    enumerable: !0,
    unsafe: !0
});
var QE = URLSearchParams.prototype,
    JE = h(QE.forEach);
Y && !("size" in QE) && Zn(QE, "size", {
    get: function() {
        var e = 0;
        return JE(this, function() {
            e++
        }), e
    },
    configurable: !0,
    enumerable: !0
});
const ZE = {
        MANIFEST: "manifest",
        SEGMENT: "segment"
    },
    e_ = {
        method: "GET",
        async: !0,
        retry: 0,
        throwHttpErrors: !0,
        headers: {},
        hooks: {
            beforeRequest: [],
            beforeRetry: [],
            afterResponse: []
        },
        validateStatus: function(e) {
            return e >= 200 && e < 300
        },
        retryStatus: function(e) {
            return [408, 413, 429].includes(e) || e >= 500 && e < 600
        }
    };

function t_(e) {
    return e.filter((e, t, r) => r.indexOf(e) === t)
}

function r_(e, t) {
    return e.reduce((e, r, n, o) => e.concat(t(r, n, o)), [])
}

function n_(e) {
    return (t, ...r) => (r.forEach(r => {
        for (const n in r) {
            const o = Object.getOwnPropertyDescriptor(r, n);
            Object.defineProperty(t, n, Object.assign(o, e))
        }
    }), t)
}
const o_ = n_({
        enumerable: !1,
        configurable: !0,
        writeable: !1
    }),
    i_ = n_({
        enumerable: !1,
        configurable: !1,
        writeable: !1
    }),
    a_ = n_({
        enumerable: !0,
        configurable: !0,
        writeable: !1
    }),
    u_ = {
        h264: "video/mp4",
        hls: "application/vnd.apple.mpegurl",
        hlsLive: "application/x-mpegURL",
        dash: "application/vnd.vimeo.dash+json",
        dashMpd: "video/vnd.mpeg.dash.mpd",
        vp6: "video/x-flv",
        vp8: "video/webm",
        webm: "video/webm",
        hds: "application/f4m"
    },
    s_ = e => new Promise(t => setTimeout(t, e));

function c_(e) {
    return "webkitDisplayingFullscreen" in e && e.webkitDisplayingFullscreen
}

function f_(e) {
    if (e && c_(e)) return !0;
    const t = [document.fullscreenElement, document.webkitFullscreenElement, document.webkitCurrentFullScreenElement, document.mozFullScreenElement, document.msFullscreenElement].find(e => void 0 !== e);
    return Boolean(t)
}
const l_ = () => {
    const e = window.navigator ? .connection ? .downlink;
    return void 0 === e ? null : 1e3 * e * 1e3
};

function d_(e) {
    try {
        const t = new URLSearchParams;
        return Object.entries(e).forEach(([e, r]) => {
            void 0 !== r && t.append(e, String(r))
        }), t.toString()
    } catch (e) {
        return ""
    }
}

function h_(e) {
    if ("string" != typeof e) return {};
    try {
        const t = new URLSearchParams(e),
            r = {};
        return t.forEach((e, t) => {
            r[t] = e
        }), r
    } catch (e) {
        return {}
    }
}

function p_(e) {
    try {
        return new URL(e)
    } catch (e) {
        return {}
    }
}
const v_ = (e, t, r = !1) => {
        try {
            const n = new URL(e);
            return Object.entries(t).forEach(([e, t]) => {
                r && void 0 === t || n.searchParams.set(e, t ? .toString() ? ? "")
            }), n.toString()
        } catch (t) {
            return e
        }
    },
    y_ = e => {
        try {
            const {
                username: t,
                password: r,
                host: n
            } = new URL(e);
            return n ? t || r ? `${t}:${r}@${n}` : n : null
        } catch (e) {
            return null
        }
    };

function g_(e) {
    const t = p_(e),
        r = t && t.pathname.match(/^\/(exp=)?(\d{10,})/);
    if (r && r[2]) return 1e3 * Number(r[2])
}
async function b_(e) {
    return /json=1/.test(e) ? (await _T(e).json()).url : e
}

function m_(e) {
    e.substring(0, e.lastIndexOf("/") + 1)
}
const w_ = (e, t = !1) => new Promise((r, n) => {
        if (t) {
            const t = document.querySelector(`script[src="${e}"]`);
            if (t && !t.dataset.error) return void setTimeout(r, 0)
        }
        const o = document.createElement("script");
        o.src = e, o.addEventListener("load", r), o.addEventListener("error", e => {
            o.dataset.error = "true", n(e.error)
        }), document.head.appendChild(o)
    }),
    E_ = e => Math.pow(e, 2),
    __ = e => Math.sqrt(e),
    T_ = (e, t) => {
        const r = (...e) => {},
            n = (...e) => {};
        return Object.assign(n, {
            log: r,
            warn: (...e) => {},
            error: (...e) => {}
        }), n
    };

function S_(e, ...t) {
    return t.reduce((e, t) => (Object.keys(t || {}).forEach(r => {
        const n = e[r],
            o = t[r];
        n && void 0 === o || (Array.isArray(o) ? e[r] = (n || []).concat(o) : (e => e && "object" == typeof e)(o) ? e[r] = S_({}, n, o) : e[r] = o)
    }), e), e)
}
const A_ = void 0 !== window.ManagedMediaSource ? window.ManagedMediaSource : window.MediaSource,
    I_ = (e = !1) => e ? window.MediaSource : A_,
    O_ = navigator.userAgent.toLowerCase(),
    R_ = ["googlebot", "google-inspectiontool"],
    N_ = ["bingbot", "bingpreview", "yandex", "slurp", "facebookexternalhit", "msnbot", "feedly", "parse.ly"],
    P_ = ["gptbot", "claude-web", "claudebot", "perplexitybot", "perplexity-user"];

function M_(e) {
    e = e.toLowerCase();
    const t = new RegExp(e).test(O_);
    return "safari" === e ? t && new RegExp("version").test(O_) : t
}

function D_(e) {
    const t = document.createElement("div"),
        r = e.charAt(0).toUpperCase() + e.slice(1),
        n = (e + " " + ["Webkit", "Moz", "O", "ms"].join(r + " ") + r).split(" ");
    for (let e in n) {
        const r = n[e];
        if (void 0 !== t.style[r]) return r
    }
    return e
}
const x_ = !!M_("android") && (parseFloat(O_.replace(/^.* android (\d+)\.(\d+).*$/, "$1.$2")) || !0),
    C_ = window.devicePixelRatio || 1,
    k_ = !(!M_("windows phone") && !M_("iemobile")) && (parseFloat(O_.replace(/^.* windows phone (os )?(\d+)\.(\d+).*$/, "$2.$3")) || !0),
    L_ = !!M_("msie") && parseFloat(O_.replace(/^.*msie (\d+).*$/, "$1")),
    j_ = !!M_("trident") && parseFloat(O_.replace(/^.*trident\/(\d+)\.(\d+).*$/, "$1.$2")) + 4,
    X_ = M_("ipad;") || M_("iphone;") || M_("ipod touch;") ? parseFloat(O_.replace(/^.* os (\d+)_(\d+).*$/, "$1.$2")) : navigator.userAgent.includes("Mac") && "ontouchend" in document,
    U_ = /(iPhone|iPod|iPad).*AppleWebKit(?!.*Version)/i.test(navigator.userAgent),
    B_ = "MacIntel" === navigator.platform && navigator.maxTouchPoints > 1,
    F_ = M_("opera") || M_("opr"),
    V_ = /^Mozilla\/5\.0 \(.* Mac OS X.*\(KHTML, like Gecko\)(?: Mobile\/[\S]*|)$/i.test(O_),
    z_ = (M_("safari") || U_) && M_("apple") && !M_("chrome") && !M_("android");

function H_() {
    if (!M_("chrome")) return [];
    const e = O_.split(" ").find(function(e) {
        return X_ ? /CriOS\//.test(e) : /chrome\//.test(e)
    });
    return e ? e.replace("chrome/", "").split(".").map(function(e) {
        return parseInt(e, 10)
    }) : []
}

function W_(e) {
    if (!z_) return !1;
    const t = e.split("."),
        r = function() {
            if (!M_("safari")) return [];
            const e = O_.split(" ").find(function(e) {
                return /version\//.test(e)
            });
            return e ? e.replace("version/", "").split(".").map(function(e) {
                return parseInt(e, 10)
            }) : []
        }();
    for (let e = 0; e < 3; e++) {
        const n = parseInt(t[e], 10) || 0,
            o = r[e] || 0;
        if (n < o) return !0;
        if (n > o) return !1
    }
    return !0
}
const Y_ = {
        autoplayPolicy: W_("11"),
        hevc: W_("11"),
        dolbyVision: W_("14.1"),
        spatial: W_("11.0.2"),
        fullscreenRequiresDataLoaded: W_("17.2")
    },
    G_ = {
        airPlay: "WebKitPlaybackTargetAvailabilityEvent" in window,
        android: x_,
        appleMail: V_,
        hasAutoplayPolicy: x_ || X_ || Y_.autoplayPolicy || H_()[0] >= 66,
        iOS: X_,
        iPadOS: B_,
        mobileAndroid: x_ && M_("mobile"),
        browser: {
            bb10: M_("bb10"),
            chrome: M_("chrome"),
            firefox: M_("firefox"),
            ie: L_ || j_,
            edge: M_("edge"),
            opera: F_,
            safari: z_,
            chromium: "chrome" in window && !M_("crios"),
            webKit: z_ || M_("crios")
        },
        mse: A_,
        devicePixelRatio: C_,
        iPhone: M_("iphone;") || M_("ipod touch;") || M_("ipod;"),
        iPad: M_("ipad;"),
        iPadNonRetina: M_("ipad;") && C_ < 2,
        mac: M_("mac os"),
        navigatorConnectionDownlink: !!window.navigator.connection ? .downlink,
        pictureInPictureSupportType: function() {
            if ("pictureInPictureEnabled" in document) return "pip-api";
            const e = document.createElement("video");
            return !("function" != typeof e.webkitSetPresentationMode || !e.webkitSupportsPresentationMode("picture-in-picture")) && "webkit-presentation-mode"
        }(),
        pointerEvents: window.navigator.pointerEnabled || window.navigator.msPointerEnabled || !1,
        passiveEvents: function() {
            let e = !1;
            try {
                const t = Object.defineProperty({}, "passive", {
                    get: function() {
                        e = !0
                    }
                });
                window.addEventListener("testPassive", null, t), window.removeEventListener("testPassive", null, t)
            } catch (e) {}
            return e
        }(),
        svg: !!document.createElementNS && !!document.createElementNS("http://www.w3.org/2000/svg", "svg").createSVGRect,
        touch: "ontouchstart" in window || window.DocumentTouch && document instanceof DocumentTouch || M_("windows phone") || window.navigator.maxTouchPoints > 1 || window.navigator.msMaxTouchPoints || !1,
        transformProperty: D_("transform"),
        transitionProperty: D_("transition"),
        webp: function() {
            const e = document.createElement("canvas");
            return !(!e.getContext || !e.getContext("2d")) && 0 === e.toDataURL("image/webp").indexOf("data:image/webp")
        }(),
        windowsPhone: k_,
        mediaCapabilities: "mediaCapabilities" in navigator,
        webShare: "canShare" in navigator && "share" in navigator,
        isGoogleBot: (() => {
            const e = O_.toLowerCase();
            return R_.some(t => e.includes(t))
        })(),
        isCrawler: (() => {
            const e = O_.toLowerCase();
            return N_.some(t => e.includes(t))
        })(),
        isLLMBot: (() => {
            const e = O_.toLowerCase();
            return P_.some(t => e.includes(t))
        })(),
        storageAccessAPI: "requestStorageAccess" in document && "hasStorageAccess" in document,
        clipboardAPI: "clipboard" in navigator && "write" in navigator.clipboard,
        videoContentPreload: !M_("iphone"),
        intersectionObserver: "IntersectionObserver" in window
    },
    K_ = e => {
        G_.mse = e
    },
    q_ = /mac os x 10_13/.test(O_),
    $_ = G_.iOS && G_.iOS >= 11,
    Q_ = "undefined" != typeof matchMedia && (matchMedia("(color-gamut: p3)").matches && screen.pixelDepth > 24 || matchMedia("(dynamic-range: high), (video-dynamic-range: high)").matches);

function J_(e, t) {
    let r = !0,
        n = !0;

    function o() {
        return n = r && "visible" === document.visibilityState, n
    }
    if (!G_.intersectionObserver) return t ? .(!0), {
        cleanup: () => {},
        isInView: !0
    };
    const i = new IntersectionObserver(e => {
        const [i] = e;
        r = !!i ? .isIntersecting, o(), t ? .(n)
    }, {
        threshold: .5
    });
    i.observe(e);
    const a = () => {
        o(), t ? .(n)
    };
    return document.addEventListener("visibilitychange", a), {
        cleanup: () => {
            i.disconnect(), document.removeEventListener("visibilitychange", a)
        },
        get isInView() {
            return n
        }
    }
}
async function Z_(e) {
    return new Promise(t => {
        const {
            cleanup: r
        } = J_(e, e => {
            e && (t(), r())
        })
    })
}

function eT() {
    let e, t, r = new Promise((r, n) => {
        e = r, t = n
    });
    return Object.assign(r, {
        resolve: e,
        reject: t
    }), r
}

function tT(e, t) {
    const r = [e, t].filter(e => "number" == typeof e);
    return `${r.length?Math.min(...r):t}p`
}

function rT(e, t) {
    if (!t || !t.length) return 0;
    if (1 === t.length && t.end(0) - t.start(0) < 1e-6) return 0;
    let r = 0;
    for (let n = t.length - 1; n >= 0 && t.end(n) > e; --n) r += t.end(n) - Math.max(t.start(n), e);
    return r
}

function nT(e, t) {
    let r = e;
    for (let n = 0; n < t.length; n++)
        if (t.start(n) <= e && t.end(n) >= e) {
            r = t.end(n);
            break
        }
    return r - e
}
G_.hevc = function(e = "hvc1") {
    return void 0 !== A_ ? A_.isTypeSupported(`video/mp4; codecs="${e}"`) : Y_.hevc && (q_ || $_)
}("hvc1.2.4.H150.90"), G_.hdr = Q_, G_.dolbyVision = function() {
    const e = 'video/mp4; codecs="dvh1"';
    let t = void 0 !== A_ && A_.isTypeSupported(e);
    if (!t) {
        const r = document.createElement("video");
        "canPlayType" in r && (t = "probably" === r.canPlayType(e))
    }
    return !((B_ || G_.iOS) && !Y_.dolbyVision) && t
}(), G_.vp9hdr = (window.matchMedia("(color-gamut: p3)").matches || window.matchMedia("(color-gamut: rec2020)").matches) && screen.colorDepth >= 48 && (A_.isTypeSupported('video/webm; codecs="vp09.02.10.10.01.09.16.09.00"') || A_.isTypeSupported('video/webm; codecs="vp09.02.10.10.01.09.16.09.01"') || A_.isTypeSupported('video/webm; codecs="vp09.02.10.10.01.09.18.09.00"') || A_.isTypeSupported('video/webm; codecs="vp09.02.10.10.01.09.18.09.01"')), G_.av1 = void 0 !== A_ && A_.isTypeSupported('video/mp4; codecs="av01.0.31M.08.0.110.01.01.01.0"'), G_.webvr = !(!window.navigator || !("getVRDisplays" in window.navigator)), G_.webxr = !!(window.navigator && "xr" in window.navigator && "supportsSession" in window.navigator.xr), G_.spatialPlayback = !!G_.mse, G_.stereoscopic = G_.spatialPlayback && G_.mobileAndroid, G_.chromeHls = function() {
    const e = document.createElement("video"),
        t = M_("chrome") && H_()[0] >= 142;
    return !("function" != typeof e.canPlayType || !t || !e.canPlayType(u_.hls))
}(), G_.fullscreenRequiresDataLoaded = G_.iOS >= 17 || G_.iPadOS && Y_.fullscreenRequiresDataLoaded;
const oT = e => {
    const t = [];
    for (let r = 0; r < e.length; r++) t.push(`${e.start(r)}-${e.end(r)}`);
    return t.join(", ")
};

function iT() {
    return void 0 !== window.performance && "function" == typeof window.performance.now ? window.performance.now() : Date.now()
}

function aT() {
    return Math.trunc(iT() / 1e3)
}

function uT(e) {
    return aT() - e
}

function sT(e) {
    return iT() - e
}
const cT = e => Math.trunc(Date.now() / 1e3) - e;

function fT() {
    return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, e => (e ^ 16 * Math.random() >> e / 4).toString(16))
}

function lT(e, t) {
    this.headers = {}, this.perfTimings = {}, S_(this, t), this.ok = 2 == (this.status / 100 | 0), this.body = e, this.text = () => Promise.resolve(e), this.json = () => Promise.resolve(JSON.parse(e)), this.blob = () => Promise.resolve(new Blob([e])), this.arrayBuffer = () => Promise.resolve(e), this.clone = () => new lT(e, this), this.isVimeoResponse = !0
}
class dT extends Error {
    constructor() {
        super("The operation was aborted."), this.name = "AbortError"
    }
}
class hT extends Error {
    constructor(e) {
        super(e.statusText), this.name = "HTTPError", this.response = e
    }
}
class pT extends Error {
    constructor() {
        super("A network error occurred."), this.name = "NetworkError"
    }
}
class vT extends Error {
    constructor(e) {
        super("Request timed out."), this.name = "TimeoutError", this.timeoutMs = e
    }
}

function yT(e, t) {
    let {
        url: r,
        method: n,
        body: o,
        onDownloadProgress: i
    } = e, a = 100;
    return new Promise(function(u, s) {
        const c = t ? new t : new XMLHttpRequest,
            f = window.performance;
        c.open(n.toUpperCase(), r, e.async), e.timeout && (c.timeout = e.timeout), c.onload = function() {
            if (0 === c.status && (!c.responseURL || 0 !== c.responseURL.indexOf("file:"))) return;
            const e = {};
            c.getAllResponseHeaders().replace(/^(.*?):[^\S\n]*([\s\S]*?)$/gm, (t, r, n) => {
                e[r] = e[r] ? `${e[r]},${n}` : n
            });
            let t = {};
            if (window.performance && void 0 !== window.performance.getEntriesByType) {
                const e = window.performance.getEntriesByType("resource");
                if (e.length && e.length >= a && ("function" == typeof f.clearResourceTimings && f.clearResourceTimings(), "function" == typeof f.setResourceTimingBufferSize && (f.setResourceTimingBufferSize(500), a = 500)), e.length) {
                    const r = e.filter(e => e.name === c.responseURL).sort((e, t) => e.connectStart - t.connectStart);
                    r.length && (t = r[r.length - 1].toJSON())
                }
            }
            u(new lT(c.response, {
                headers: e,
                statusText: c.statusText,
                status: c.status,
                url: c.responseURL,
                perfTimings: t
            }))
        }, c.onabort = function() {
            s(new dT)
        }, c.onerror = function() {
            s(new pT)
        }, c.ontimeout = function() {
            s(new vT(e.timeout))
        }, "function" == typeof i && c.addEventListener("progress", i);
        for (let t in e.headers) c.setRequestHeader(t, e.headers[t]);
        e.withCredentials && (c.withCredentials = !0), e.responseType && (c.responseType = e.responseType), e.abort = c.abort.bind(c), c.send(o || null)
    })
}
const gT = .3;

function bT(e, t) {
    const r = e.then.bind(e);
    return Object.assign(e, {
        abort: t,
        then: (...e) => bT(r(...e), t)
    })
}
const mT = ["get", "post", "put", "patch", "head", "delete"],
    wT = {
        json: "application/json",
        text: "text/plain",
        arrayBuffer: "*/*",
        blob: "*/*"
    },
    ET = ["get"];

function _T(e, t) {
    t = new TT(e, t);
    const {
        method: r,
        json: n,
        jwt: o,
        searchParams: i
    } = t;
    async function a() {
        const e = t.hooks.beforeRequest || [];
        for (let r = 0; r < e.length; r++) {
            const n = e[r],
                o = await n(t);
            if (o instanceof TT) {
                t = o;
                break
            }
            if (o ? .isVimeoResponse) return Promise.resolve(o).then(ST(t))
        }
        return yT(t).then(ST(t))
    }
    n && (t.headers["Content-Type"] = wT.json, t.body = JSON.stringify(n)), o && (t.headers.Authorization = `jwt ${o}`), i && (t.url = v_(t.url, i));
    const u = -1 !== ET.indexOf(r.toLowerCase()) ? function(e) {
        let t = 0;
        return async function r(n) {
            try {
                return await n()
            } catch (o) {
                const i = function(r) {
                    if (!e.retryAbortErrors && r instanceof dT) return 0;
                    if (r instanceof vT) return 0;
                    if (t >= e.retry) return 0;
                    if (r instanceof hT) {
                        if (!e.retryStatus(r.response.status)) return 0;
                        const t = function(e) {
                            const t = "retry-after".toLowerCase();
                            for (const r in e)
                                if (r.toLowerCase() === t) return e[r];
                            return null
                        }(r.response.headers);
                        if (t && e.retryStatus(r.response.status)) {
                            let e = Number(t);
                            return isNaN(e) ? e = Date.parse(t) - Date.now() : e *= 1e3, e
                        }
                        if (413 === r.response.status) return 0
                    }
                    return gT * 2 ** (t - 1) * 1e3
                }(o);
                if (t++, 0 !== i && t > 0) {
                    await s_(i);
                    const a = e ? .hooks ? .beforeRetry || [];
                    for (let r = 0; r < a.length; r++) {
                        const n = a[r];
                        await n(e, o, t)
                    }
                    return r(n)
                }
                if (e.throwHttpErrors) throw o
            }
        }
    }(t)(a) : a();
    for (const e in wT) u[e] = async () => (t.headers["Content-Type"] = wT[e], (await u).clone()[e]());
    return bT(u, () => t.abort())
}

function TT(e, t) {
    S_(this, e_, e = "string" == typeof e ? {
        url: e
    } : e, t)
}

function ST(e) {
    const {
        validateStatus: t,
        throwHttpErrors: r,
        hooks: n
    } = e;
    return async o => {
        const i = n.afterResponse || [];
        for (let t = 0; t < i.length; t++) {
            const r = i[t],
                n = await r(e, o.clone());
            n instanceof lT && (o = n)
        }
        if (!t || t(o.status)) return o;
        if (r) throw new hT(o);
        return o
    }
}
mT.forEach(function(e) {
    return _T[e] = (t, r) => _T(t, {
        method: e,
        ...r
    }), _T[e]
});
const {
    get: AT,
    post: IT,
    put: OT,
    patch: RT,
    head: NT
} = _T, PT = {
    ARRAY_BUFFER: "arraybuffer"
};
var MT = Object.freeze({
        __proto__: null,
        ContentTypes: ZE,
        defaults: e_,
        requestMethods: mT,
        responseTypes: wT,
        retryMethods: ET,
        request: _T,
        Request: TT,
        get: AT,
        post: IT,
        put: OT,
        patch: RT,
        head: NT,
        Response: lT,
        ResponseTypes: PT,
        AbortError: dT,
        HTTPError: hT,
        NetworkError: pT,
        TimeoutError: vT,
        xhr: yT
    }),
    DT = Array.isArray,
    xT = "object" == typeof global && global && global.Object === Object && global,
    CT = "object" == typeof self && self && self.Object === Object && self,
    kT = xT || CT || Function("return this")(),
    LT = kT.Symbol,
    jT = Object.prototype,
    XT = jT.hasOwnProperty,
    UT = jT.toString,
    BT = LT ? LT.toStringTag : void 0,
    FT = Object.prototype.toString,
    VT = LT ? LT.toStringTag : void 0;

function zT(e) {
    return null == e ? void 0 === e ? "[object Undefined]" : "[object Null]" : VT && VT in Object(e) ? function(e) {
        var t = XT.call(e, BT),
            r = e[BT];
        try {
            e[BT] = void 0;
            var n = !0
        } catch (e) {}
        var o = UT.call(e);
        return n && (t ? e[BT] = r : delete e[BT]), o
    }(e) : function(e) {
        return FT.call(e)
    }(e)
}

function HT(e) {
    return null != e && "object" == typeof e
}

function WT(e) {
    return "symbol" == typeof e || HT(e) && "[object Symbol]" == zT(e)
}
var YT = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
    GT = /^\w*$/;

function KT(e) {
    var t = typeof e;
    return null != e && ("object" == t || "function" == t)
}

function qT(e) {
    if (!KT(e)) return !1;
    var t = zT(e);
    return "[object Function]" == t || "[object GeneratorFunction]" == t || "[object AsyncFunction]" == t || "[object Proxy]" == t
}
var $T = kT["__core-js_shared__"],
    QT = function() {
        var e = /[^.]+$/.exec($T && $T.keys && $T.keys.IE_PROTO || "");
        return e ? "Symbol(src)_1." + e : ""
    }(),
    JT = Function.prototype.toString;

function ZT(e) {
    if (null != e) {
        try {
            return JT.call(e)
        } catch (e) {}
        try {
            return e + ""
        } catch (e) {}
    }
    return ""
}
var eS = /^\[object .+?Constructor\]$/,
    tS = Function.prototype,
    rS = Object.prototype,
    nS = tS.toString,
    oS = rS.hasOwnProperty,
    iS = RegExp("^" + nS.call(oS).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");

function aS(e, t) {
    var r = function(e, t) {
        return null == e ? void 0 : e[t]
    }(e, t);
    return function(e) {
        return !(!KT(e) || function(e) {
            return !!QT && QT in e
        }(e)) && (qT(e) ? iS : eS).test(ZT(e))
    }(r) ? r : void 0
}
var uS = aS(Object, "create"),
    sS = Object.prototype.hasOwnProperty,
    cS = Object.prototype.hasOwnProperty;

function fS(e) {
    var t = -1,
        r = null == e ? 0 : e.length;
    for (this.clear(); ++t < r;) {
        var n = e[t];
        this.set(n[0], n[1])
    }
}

function lS(e, t) {
    return e === t || e != e && t != t
}

function dS(e, t) {
    for (var r = e.length; r--;)
        if (lS(e[r][0], t)) return r;
    return -1
}
fS.prototype.clear = function() {
    this.__data__ = uS ? uS(null) : {}, this.size = 0
}, fS.prototype.delete = function(e) {
    var t = this.has(e) && delete this.__data__[e];
    return this.size -= t ? 1 : 0, t
}, fS.prototype.get = function(e) {
    var t = this.__data__;
    if (uS) {
        var r = t[e];
        return "__lodash_hash_undefined__" === r ? void 0 : r
    }
    return sS.call(t, e) ? t[e] : void 0
}, fS.prototype.has = function(e) {
    var t = this.__data__;
    return uS ? void 0 !== t[e] : cS.call(t, e)
}, fS.prototype.set = function(e, t) {
    var r = this.__data__;
    return this.size += this.has(e) ? 0 : 1, r[e] = uS && void 0 === t ? "__lodash_hash_undefined__" : t, this
};
var hS = Array.prototype.splice;

function pS(e) {
    var t = -1,
        r = null == e ? 0 : e.length;
    for (this.clear(); ++t < r;) {
        var n = e[t];
        this.set(n[0], n[1])
    }
}
pS.prototype.clear = function() {
    this.__data__ = [], this.size = 0
}, pS.prototype.delete = function(e) {
    var t = this.__data__,
        r = dS(t, e);
    return !(r < 0 || (r == t.length - 1 ? t.pop() : hS.call(t, r, 1), --this.size, 0))
}, pS.prototype.get = function(e) {
    var t = this.__data__,
        r = dS(t, e);
    return r < 0 ? void 0 : t[r][1]
}, pS.prototype.has = function(e) {
    return dS(this.__data__, e) > -1
}, pS.prototype.set = function(e, t) {
    var r = this.__data__,
        n = dS(r, e);
    return n < 0 ? (++this.size, r.push([e, t])) : r[n][1] = t, this
};
var vS = aS(kT, "Map");

function yS(e, t) {
    var r = e.__data__;
    return function(e) {
        var t = typeof e;
        return "string" == t || "number" == t || "symbol" == t || "boolean" == t ? "__proto__" !== e : null === e
    }(t) ? r["string" == typeof t ? "string" : "hash"] : r.map
}

function gS(e) {
    var t = -1,
        r = null == e ? 0 : e.length;
    for (this.clear(); ++t < r;) {
        var n = e[t];
        this.set(n[0], n[1])
    }
}

function bS(e, t) {
    if ("function" != typeof e || null != t && "function" != typeof t) throw new TypeError("Expected a function");
    var r = function() {
        var n = arguments,
            o = t ? t.apply(this, n) : n[0],
            i = r.cache;
        if (i.has(o)) return i.get(o);
        var a = e.apply(this, n);
        return r.cache = i.set(o, a) || i, a
    };
    return r.cache = new(bS.Cache || gS), r
}
gS.prototype.clear = function() {
    this.size = 0, this.__data__ = {
        hash: new fS,
        map: new(vS || pS),
        string: new fS
    }
}, gS.prototype.delete = function(e) {
    var t = yS(this, e).delete(e);
    return this.size -= t ? 1 : 0, t
}, gS.prototype.get = function(e) {
    return yS(this, e).get(e)
}, gS.prototype.has = function(e) {
    return yS(this, e).has(e)
}, gS.prototype.set = function(e, t) {
    var r = yS(this, e),
        n = r.size;
    return r.set(e, t), this.size += r.size == n ? 0 : 1, this
}, bS.Cache = gS;
var mS = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,
    wS = /\\(\\)?/g,
    ES = function() {
        var e = bS(function(e) {
                var t = [];
                return 46 === e.charCodeAt(0) && t.push(""), e.replace(mS, function(e, r, n, o) {
                    t.push(n ? o.replace(wS, "$1") : r || e)
                }), t
            }, function(e) {
                return 500 === t.size && t.clear(), e
            }),
            t = e.cache;
        return e
    }(),
    _S = LT ? LT.prototype : void 0,
    TS = _S ? _S.toString : void 0;

function SS(e) {
    if ("string" == typeof e) return e;
    if (DT(e)) return function(e, t) {
        for (var r = -1, n = null == e ? 0 : e.length, o = Array(n); ++r < n;) o[r] = t(e[r], r, e);
        return o
    }(e, SS) + "";
    if (WT(e)) return TS ? TS.call(e) : "";
    var t = e + "";
    return "0" == t && 1 / e == -1 / 0 ? "-0" : t
}

function AS(e) {
    return null == e ? "" : SS(e)
}

function IS(e, t) {
    return DT(e) ? e : function(e, t) {
        if (DT(e)) return !1;
        var r = typeof e;
        return !("number" != r && "symbol" != r && "boolean" != r && null != e && !WT(e)) || GT.test(e) || !YT.test(e) || null != t && e in Object(t)
    }(e, t) ? [e] : ES(AS(e))
}

function OS(e) {
    if ("string" == typeof e || WT(e)) return e;
    var t = e + "";
    return "0" == t && 1 / e == -1 / 0 ? "-0" : t
}

function RS(e, t) {
    for (var r = 0, n = (t = IS(t, e)).length; null != e && r < n;) e = e[OS(t[r++])];
    return r && r == n ? e : void 0
}

function NS(e, t, r) {
    var n = null == e ? void 0 : RS(e, t);
    return void 0 === n ? r : n
}
var PS = "object" == typeof global && global && global.Object === Object && global,
    MS = "object" == typeof self && self && self.Object === Object && self,
    DS = (PS || MS || Function("return this")()).Symbol,
    xS = Object.prototype,
    CS = xS.hasOwnProperty,
    kS = xS.toString,
    LS = DS ? DS.toStringTag : void 0,
    jS = Object.prototype.toString,
    XS = DS ? DS.toStringTag : void 0;
var US = function(e, t) {
        return function(r) {
            return e(t(r))
        }
    }(Object.getPrototypeOf, Object),
    BS = Function.prototype,
    FS = Object.prototype,
    VS = BS.toString,
    zS = FS.hasOwnProperty,
    HS = VS.call(Object),
    WS = function() {
        var e, t = ("undefined" != typeof self ? self : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof module ? module : Function("return this")()).Symbol;
        return "function" == typeof t ? t.observable ? e = t.observable : (e = t("observable"), t.observable = e) : e = "@@observable", e
    }(),
    YS = "@@redux/INIT";

function GS(e, t, r) {
    var n;
    if ("function" == typeof t && void 0 === r && (r = t, t = void 0), void 0 !== r) {
        if ("function" != typeof r) throw new Error("Expected the enhancer to be a function.");
        return r(GS)(e, t)
    }
    if ("function" != typeof e) throw new Error("Expected the reducer to be a function.");
    var o = e,
        i = t,
        a = [],
        u = a,
        s = !1;

    function c() {
        u === a && (u = a.slice())
    }

    function f() {
        return i
    }

    function l(e) {
        if ("function" != typeof e) throw new Error("Expected listener to be a function.");
        var t = !0;
        return c(), u.push(e),
            function() {
                if (t) {
                    t = !1, c();
                    var r = u.indexOf(e);
                    u.splice(r, 1)
                }
            }
    }

    function d(e) {
        if (! function(e) {
                if (! function(e) {
                        return null != e && "object" == typeof e
                    }(e) || "[object Object]" != function(e) {
                        return null == e ? void 0 === e ? "[object Undefined]" : "[object Null]" : XS && XS in Object(e) ? function(e) {
                            var t = CS.call(e, LS),
                                r = e[LS];
                            try {
                                e[LS] = void 0;
                                var n = !0
                            } catch (e) {}
                            var o = kS.call(e);
                            return n && (t ? e[LS] = r : delete e[LS]), o
                        }(e) : function(e) {
                            return jS.call(e)
                        }(e)
                    }(e)) return !1;
                var t = US(e);
                if (null === t) return !0;
                var r = zS.call(t, "constructor") && t.constructor;
                return "function" == typeof r && r instanceof r && VS.call(r) == HS
            }(e)) throw new Error("Actions must be plain objects. Use custom middleware for async actions.");
        if (void 0 === e.type) throw new Error('Actions may not have an undefined "type" property. Have you misspelled a constant?');
        if (s) throw new Error("Reducers may not dispatch actions.");
        try {
            s = !0, i = o(i, e)
        } finally {
            s = !1
        }
        for (var t = a = u, r = 0; r < t.length; r++)(0, t[r])();
        return e
    }
    return d({
        type: YS
    }), (n = {
        dispatch: d,
        subscribe: l,
        getState: f,
        replaceReducer: function(e) {
            if ("function" != typeof e) throw new Error("Expected the nextReducer to be a function.");
            o = e, d({
                type: YS
            })
        }
    })[WS] = function() {
        var e, t = l;
        return (e = {
            subscribe: function(e) {
                if ("object" != typeof e) throw new TypeError("Expected the observer to be an object.");

                function r() {
                    e.next && e.next(f())
                }
                return r(), {
                    unsubscribe: t(r)
                }
            }
        })[WS] = function() {
            return this
        }, e
    }, n
}

function KS() {
    for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
    return 0 === t.length ? function(e) {
        return e
    } : 1 === t.length ? t[0] : t.reduce(function(e, t) {
        return function() {
            return e(t.apply(void 0, arguments))
        }
    })
}
var qS = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var r = arguments[t];
        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
    }
    return e
};

function $S() {
    for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
    return function(e) {
        return function(r, n, o) {
            var i, a = e(r, n, o),
                u = a.dispatch,
                s = {
                    getState: a.getState,
                    dispatch: function(e) {
                        return u(e)
                    }
                };
            return i = t.map(function(e) {
                return e(s)
            }), u = KS.apply(void 0, i)(a.dispatch), qS({}, a, {
                dispatch: u
            })
        }
    }
}

function QS(e) {
    var t = this.__data__ = new pS(e);
    this.size = t.size
}
QS.prototype.clear = function() {
    this.__data__ = new pS, this.size = 0
}, QS.prototype.delete = function(e) {
    var t = this.__data__,
        r = t.delete(e);
    return this.size = t.size, r
}, QS.prototype.get = function(e) {
    return this.__data__.get(e)
}, QS.prototype.has = function(e) {
    return this.__data__.has(e)
}, QS.prototype.set = function(e, t) {
    var r = this.__data__;
    if (r instanceof pS) {
        var n = r.__data__;
        if (!vS || n.length < 199) return n.push([e, t]), this.size = ++r.size, this;
        r = this.__data__ = new gS(n)
    }
    return r.set(e, t), this.size = r.size, this
};
var JS = function() {
    try {
        var e = aS(Object, "defineProperty");
        return e({}, "", {}), e
    } catch (e) {}
}();

function ZS(e, t, r) {
    "__proto__" == t && JS ? JS(e, t, {
        configurable: !0,
        enumerable: !0,
        value: r,
        writable: !0
    }) : e[t] = r
}
var eA = Object.prototype.hasOwnProperty;

function tA(e, t, r) {
    var n = e[t];
    eA.call(e, t) && lS(n, r) && (void 0 !== r || t in e) || ZS(e, t, r)
}

function rA(e, t, r, n) {
    var o = !r;
    r || (r = {});
    for (var i = -1, a = t.length; ++i < a;) {
        var u = t[i],
            s = n ? n(r[u], e[u], u, r, e) : void 0;
        void 0 === s && (s = e[u]), o ? ZS(r, u, s) : tA(r, u, s)
    }
    return r
}

function nA(e) {
    return HT(e) && "[object Arguments]" == zT(e)
}
var oA = Object.prototype,
    iA = oA.hasOwnProperty,
    aA = oA.propertyIsEnumerable,
    uA = nA(function() {
        return arguments
    }()) ? nA : function(e) {
        return HT(e) && iA.call(e, "callee") && !aA.call(e, "callee")
    },
    sA = "object" == typeof exports && exports && !exports.nodeType && exports,
    cA = sA && "object" == typeof module && module && !module.nodeType && module,
    fA = cA && cA.exports === sA ? kT.Buffer : void 0,
    lA = (fA ? fA.isBuffer : void 0) || function() {
        return !1
    },
    dA = /^(?:0|[1-9]\d*)$/;

function hA(e, t) {
    var r = typeof e;
    return !!(t = null == t ? 9007199254740991 : t) && ("number" == r || "symbol" != r && dA.test(e)) && e > -1 && e % 1 == 0 && e < t
}

function pA(e) {
    return "number" == typeof e && e > -1 && e % 1 == 0 && e <= 9007199254740991
}
var vA = {};

function yA(e) {
    return function(t) {
        return e(t)
    }
}
vA["[object Float32Array]"] = vA["[object Float64Array]"] = vA["[object Int8Array]"] = vA["[object Int16Array]"] = vA["[object Int32Array]"] = vA["[object Uint8Array]"] = vA["[object Uint8ClampedArray]"] = vA["[object Uint16Array]"] = vA["[object Uint32Array]"] = !0, vA["[object Arguments]"] = vA["[object Array]"] = vA["[object ArrayBuffer]"] = vA["[object Boolean]"] = vA["[object DataView]"] = vA["[object Date]"] = vA["[object Error]"] = vA["[object Function]"] = vA["[object Map]"] = vA["[object Number]"] = vA["[object Object]"] = vA["[object RegExp]"] = vA["[object Set]"] = vA["[object String]"] = vA["[object WeakMap]"] = !1;
var gA = "object" == typeof exports && exports && !exports.nodeType && exports,
    bA = gA && "object" == typeof module && module && !module.nodeType && module,
    mA = bA && bA.exports === gA && xT.process,
    wA = function() {
        try {
            return bA && bA.require && bA.require("util").types || mA && mA.binding && mA.binding("util")
        } catch (e) {}
    }(),
    EA = wA && wA.isTypedArray,
    _A = EA ? yA(EA) : function(e) {
        return HT(e) && pA(e.length) && !!vA[zT(e)]
    },
    TA = Object.prototype.hasOwnProperty;

function SA(e, t) {
    var r = DT(e),
        n = !r && uA(e),
        o = !r && !n && lA(e),
        i = !r && !n && !o && _A(e),
        a = r || n || o || i,
        u = a ? function(e, t) {
            for (var r = -1, n = Array(e); ++r < e;) n[r] = t(r);
            return n
        }(e.length, String) : [],
        s = u.length;
    for (var c in e) !t && !TA.call(e, c) || a && ("length" == c || o && ("offset" == c || "parent" == c) || i && ("buffer" == c || "byteLength" == c || "byteOffset" == c) || hA(c, s)) || u.push(c);
    return u
}
var AA = Object.prototype;

function IA(e) {
    var t = e && e.constructor;
    return e === ("function" == typeof t && t.prototype || AA)
}

function OA(e, t) {
    return function(r) {
        return e(t(r))
    }
}
var RA = OA(Object.keys, Object),
    NA = Object.prototype.hasOwnProperty;

function PA(e) {
    if (!IA(e)) return RA(e);
    var t = [];
    for (var r in Object(e)) NA.call(e, r) && "constructor" != r && t.push(r);
    return t
}

function MA(e) {
    return null != e && pA(e.length) && !qT(e)
}

function DA(e) {
    return MA(e) ? SA(e) : PA(e)
}
var xA = Object.prototype.hasOwnProperty;

function CA(e) {
    return MA(e) ? SA(e, !0) : function(e) {
        if (!KT(e)) return function(e) {
            var t = [];
            if (null != e)
                for (var r in Object(e)) t.push(r);
            return t
        }(e);
        var t = IA(e),
            r = [];
        for (var n in e)("constructor" != n || !t && xA.call(e, n)) && r.push(n);
        return r
    }(e)
}
var kA = "object" == typeof exports && exports && !exports.nodeType && exports,
    LA = kA && "object" == typeof module && module && !module.nodeType && module,
    jA = LA && LA.exports === kA ? kT.Buffer : void 0,
    XA = jA ? jA.allocUnsafe : void 0;

function UA(e, t) {
    if (t) return e.slice();
    var r = e.length,
        n = XA ? XA(r) : new e.constructor(r);
    return e.copy(n), n
}

function BA(e, t) {
    var r = -1,
        n = e.length;
    for (t || (t = Array(n)); ++r < n;) t[r] = e[r];
    return t
}

function FA() {
    return []
}
var VA = Object.prototype.propertyIsEnumerable,
    zA = Object.getOwnPropertySymbols,
    HA = zA ? function(e) {
        return null == e ? [] : (e = Object(e), function(e, t) {
            for (var r = -1, n = null == e ? 0 : e.length, o = 0, i = []; ++r < n;) {
                var a = e[r];
                t(a) && (i[o++] = a)
            }
            return i
        }(zA(e), function(t) {
            return VA.call(e, t)
        }))
    } : FA;

function WA(e, t) {
    for (var r = -1, n = t.length, o = e.length; ++r < n;) e[o + r] = t[r];
    return e
}
var YA = OA(Object.getPrototypeOf, Object),
    GA = Object.getOwnPropertySymbols ? function(e) {
        for (var t = []; e;) WA(t, HA(e)), e = YA(e);
        return t
    } : FA;

function KA(e, t, r) {
    var n = t(e);
    return DT(e) ? n : WA(n, r(e))
}

function qA(e) {
    return KA(e, DA, HA)
}

function $A(e) {
    return KA(e, CA, GA)
}
var QA = aS(kT, "DataView"),
    JA = aS(kT, "Promise"),
    ZA = aS(kT, "Set"),
    eI = aS(kT, "WeakMap"),
    tI = "[object Map]",
    rI = "[object Promise]",
    nI = "[object Set]",
    oI = "[object WeakMap]",
    iI = "[object DataView]",
    aI = ZT(QA),
    uI = ZT(vS),
    sI = ZT(JA),
    cI = ZT(ZA),
    fI = ZT(eI),
    lI = zT;
(QA && lI(new QA(new ArrayBuffer(1))) != iI || vS && lI(new vS) != tI || JA && lI(JA.resolve()) != rI || ZA && lI(new ZA) != nI || eI && lI(new eI) != oI) && (lI = function(e) {
    var t = zT(e),
        r = "[object Object]" == t ? e.constructor : void 0,
        n = r ? ZT(r) : "";
    if (n) switch (n) {
        case aI:
            return iI;
        case uI:
            return tI;
        case sI:
            return rI;
        case cI:
            return nI;
        case fI:
            return oI
    }
    return t
});
var dI = lI,
    hI = Object.prototype.hasOwnProperty,
    pI = kT.Uint8Array;

function vI(e) {
    var t = new e.constructor(e.byteLength);
    return new pI(t).set(new pI(e)), t
}
var yI = /\w*$/,
    gI = LT ? LT.prototype : void 0,
    bI = gI ? gI.valueOf : void 0;

function mI(e, t) {
    var r = t ? vI(e.buffer) : e.buffer;
    return new e.constructor(r, e.byteOffset, e.length)
}
var wI = Object.create,
    EI = function() {
        function e() {}
        return function(t) {
            if (!KT(t)) return {};
            if (wI) return wI(t);
            e.prototype = t;
            var r = new e;
            return e.prototype = void 0, r
        }
    }();

function _I(e) {
    return "function" != typeof e.constructor || IA(e) ? {} : EI(YA(e))
}
var TI = wA && wA.isMap,
    SI = TI ? yA(TI) : function(e) {
        return HT(e) && "[object Map]" == dI(e)
    },
    AI = wA && wA.isSet,
    II = AI ? yA(AI) : function(e) {
        return HT(e) && "[object Set]" == dI(e)
    },
    OI = "[object Arguments]",
    RI = "[object Function]",
    NI = "[object Object]",
    PI = {};

function MI(e, t, r, n, o, i) {
    var a, u = 1 & t,
        s = 2 & t,
        c = 4 & t;
    if (r && (a = o ? r(e, n, o, i) : r(e)), void 0 !== a) return a;
    if (!KT(e)) return e;
    var f = DT(e);
    if (f) {
        if (a = function(e) {
                var t = e.length,
                    r = new e.constructor(t);
                return t && "string" == typeof e[0] && hI.call(e, "index") && (r.index = e.index, r.input = e.input), r
            }(e), !u) return BA(e, a)
    } else {
        var l = dI(e),
            d = l == RI || "[object GeneratorFunction]" == l;
        if (lA(e)) return UA(e, u);
        if (l == NI || l == OI || d && !o) {
            if (a = s || d ? {} : _I(e), !u) return s ? function(e, t) {
                return rA(e, GA(e), t)
            }(e, function(e, t) {
                return e && rA(t, CA(t), e)
            }(a, e)) : function(e, t) {
                return rA(e, HA(e), t)
            }(e, function(e, t) {
                return e && rA(t, DA(t), e)
            }(a, e))
        } else {
            if (!PI[l]) return o ? e : {};
            a = function(e, t, r) {
                var n = e.constructor;
                switch (t) {
                    case "[object ArrayBuffer]":
                        return vI(e);
                    case "[object Boolean]":
                    case "[object Date]":
                        return new n(+e);
                    case "[object DataView]":
                        return function(e, t) {
                            var r = t ? vI(e.buffer) : e.buffer;
                            return new e.constructor(r, e.byteOffset, e.byteLength)
                        }(e, r);
                    case "[object Float32Array]":
                    case "[object Float64Array]":
                    case "[object Int8Array]":
                    case "[object Int16Array]":
                    case "[object Int32Array]":
                    case "[object Uint8Array]":
                    case "[object Uint8ClampedArray]":
                    case "[object Uint16Array]":
                    case "[object Uint32Array]":
                        return mI(e, r);
                    case "[object Map]":
                    case "[object Set]":
                        return new n;
                    case "[object Number]":
                    case "[object String]":
                        return new n(e);
                    case "[object RegExp]":
                        return function(e) {
                            var t = new e.constructor(e.source, yI.exec(e));
                            return t.lastIndex = e.lastIndex, t
                        }(e);
                    case "[object Symbol]":
                        return function(e) {
                            return bI ? Object(bI.call(e)) : {}
                        }(e)
                }
            }(e, l, u)
        }
    }
    i || (i = new QS);
    var h = i.get(e);
    if (h) return h;
    i.set(e, a), II(e) ? e.forEach(function(n) {
        a.add(MI(n, t, r, n, e, i))
    }) : SI(e) && e.forEach(function(n, o) {
        a.set(o, MI(n, t, r, o, e, i))
    });
    var p = f ? void 0 : (c ? s ? $A : qA : s ? CA : DA)(e);
    return function(e, t) {
        for (var r = -1, n = null == e ? 0 : e.length; ++r < n && !1 !== t(e[r], r););
    }(p || e, function(n, o) {
        p && (n = e[o = n]), tA(a, o, MI(n, t, r, o, e, i))
    }), a
}

function DI(e) {
    return MI(e, 5)
}

function xI(e, t, r) {
    switch (r.length) {
        case 0:
            return e.call(t);
        case 1:
            return e.call(t, r[0]);
        case 2:
            return e.call(t, r[0], r[1]);
        case 3:
            return e.call(t, r[0], r[1], r[2])
    }
    return e.apply(t, r)
}

function CI(e) {
    return e
}
PI[OI] = PI["[object Array]"] = PI["[object ArrayBuffer]"] = PI["[object DataView]"] = PI["[object Boolean]"] = PI["[object Date]"] = PI["[object Float32Array]"] = PI["[object Float64Array]"] = PI["[object Int8Array]"] = PI["[object Int16Array]"] = PI["[object Int32Array]"] = PI["[object Map]"] = PI["[object Number]"] = PI[NI] = PI["[object RegExp]"] = PI["[object Set]"] = PI["[object String]"] = PI["[object Symbol]"] = PI["[object Uint8Array]"] = PI["[object Uint8ClampedArray]"] = PI["[object Uint16Array]"] = PI["[object Uint32Array]"] = !0, PI["[object Error]"] = PI[RI] = PI["[object WeakMap]"] = !1;
var kI = Math.max;

function LI(e, t, r) {
    return t = kI(void 0 === t ? e.length - 1 : t, 0),
        function() {
            for (var n = arguments, o = -1, i = kI(n.length - t, 0), a = Array(i); ++o < i;) a[o] = n[t + o];
            o = -1;
            for (var u = Array(t + 1); ++o < t;) u[o] = n[o];
            return u[t] = r(a), xI(e, this, u)
        }
}

function jI(e) {
    return function() {
        return e
    }
}
var XI = JS ? function(e, t) {
        return JS(e, "toString", {
            configurable: !0,
            enumerable: !1,
            value: jI(t),
            writable: !0
        })
    } : CI,
    UI = Date.now,
    BI = function(e) {
        var t = 0,
            r = 0;
        return function() {
            var n = UI(),
                o = 16 - (n - r);
            if (r = n, o > 0) {
                if (++t >= 800) return arguments[0]
            } else t = 0;
            return e.apply(void 0, arguments)
        }
    }(XI);

function FI(e, t) {
    return BI(LI(e, t, CI), e + "")
}

function VI(e, t, r) {
    (void 0 !== r && !lS(e[t], r) || void 0 === r && !(t in e)) && ZS(e, t, r)
}
var zI = function(e, t, r) {
        for (var n = -1, o = Object(e), i = r(e), a = i.length; a--;) {
            var u = i[++n];
            if (!1 === t(o[u], u, o)) break
        }
        return e
    },
    HI = Function.prototype,
    WI = Object.prototype,
    YI = HI.toString,
    GI = WI.hasOwnProperty,
    KI = YI.call(Object);

function qI(e) {
    if (!HT(e) || "[object Object]" != zT(e)) return !1;
    var t = YA(e);
    if (null === t) return !0;
    var r = GI.call(t, "constructor") && t.constructor;
    return "function" == typeof r && r instanceof r && YI.call(r) == KI
}

function $I(e, t) {
    if (("constructor" !== t || "function" != typeof e[t]) && "__proto__" != t) return e[t]
}

function QI(e, t, r, n, o) {
    e !== t && zI(t, function(i, a) {
        if (o || (o = new QS), KT(i)) ! function(e, t, r, n, o, i, a) {
            var u = $I(e, r),
                s = $I(t, r),
                c = a.get(s);
            if (c) VI(e, r, c);
            else {
                var f = i ? i(u, s, r + "", e, t, a) : void 0,
                    l = void 0 === f;
                if (l) {
                    var d = DT(s),
                        h = !d && lA(s),
                        p = !d && !h && _A(s);
                    f = s, d || h || p ? DT(u) ? f = u : function(e) {
                        return HT(e) && MA(e)
                    }(u) ? f = BA(u) : h ? (l = !1, f = UA(s, !0)) : p ? (l = !1, f = mI(s, !0)) : f = [] : qI(s) || uA(s) ? (f = u, uA(u) ? f = function(e) {
                        return rA(e, CA(e))
                    }(u) : KT(u) && !qT(u) || (f = _I(s))) : l = !1
                }
                l && (a.set(s, f), o(f, s, n, i, a), a.delete(s)), VI(e, r, f)
            }
        }(e, t, a, r, QI, n, o);
        else {
            var u = n ? n($I(e, a), i, a + "", e, t, o) : void 0;
            void 0 === u && (u = i), VI(e, a, u)
        }
    }, CA)
}

function JI(e, t, r, n, o, i) {
    return KT(e) && KT(t) && (i.set(t, e), QI(e, t, void 0, JI, i), i.delete(t)), e
}

function ZI(e) {
    return FI(function(t, r) {
        var n = -1,
            o = r.length,
            i = o > 1 ? r[o - 1] : void 0,
            a = o > 2 ? r[2] : void 0;
        for (i = e.length > 3 && "function" == typeof i ? (o--, i) : void 0, a && function(e, t, r) {
                if (!KT(r)) return !1;
                var n = typeof t;
                return !!("number" == n ? MA(r) && hA(t, r.length) : "string" == n && t in r) && lS(r[t], e)
            }(r[0], r[1], a) && (i = o < 3 ? void 0 : i, o = 1), t = Object(t); ++n < o;) {
            var u = r[n];
            u && e(t, u, n, i)
        }
        return t
    })
}
var eO = ZI(function(e, t, r, n) {
        QI(e, t, r, n)
    }),
    tO = FI(function(e) {
        return e.push(void 0, JI), xI(eO, void 0, e)
    }),
    rO = /\s/,
    nO = /^\s+/;
var oO = /^[-+]0x[0-9a-f]+$/i,
    iO = /^0b[01]+$/i,
    aO = /^0o[0-7]+$/i,
    uO = parseInt;

function sO(e) {
    if ("number" == typeof e) return e;
    if (WT(e)) return NaN;
    if (KT(e)) {
        var t = "function" == typeof e.valueOf ? e.valueOf() : e;
        e = KT(t) ? t + "" : t
    }
    if ("string" != typeof e) return 0 === e ? e : +e;
    e = function(e) {
        return e ? e.slice(0, function(e) {
            for (var t = e.length; t-- && rO.test(e.charAt(t)););
            return t
        }(e) + 1).replace(nO, "") : e
    }(e);
    var r = iO.test(e);
    return r || aO.test(e) ? uO(e.slice(2), r ? 2 : 8) : oO.test(e) ? NaN : +e
}
var cO = 1 / 0;
var fO = kT.isFinite,
    lO = Math.min,
    dO = function() {
        var e = Math.round;
        return function(t, r) {
            if (t = sO(t), (r = null == r ? 0 : lO(function(e) {
                    var t = function(e) {
                            return e ? (e = sO(e)) === cO || e === -1 / 0 ? 17976931348623157e292 * (e < 0 ? -1 : 1) : e == e ? e : 0 : 0 === e ? e : 0
                        }(e),
                        r = t % 1;
                    return t == t ? r ? t - r : t : 0
                }(r), 292)) && fO(t)) {
                var n = (AS(t) + "e").split("e");
                return +((n = (AS(e(n[0] + "e" + (+n[1] + r))) + "e").split("e"))[0] + "e" + (+n[1] - r))
            }
            return e(t)
        }
    }(),
    hO = Object.prototype.hasOwnProperty;

function pO(e) {
    if (null == e) return !0;
    if (MA(e) && (DT(e) || "string" == typeof e || "function" == typeof e.splice || lA(e) || _A(e) || uA(e))) return !e.length;
    var t = dI(e);
    if ("[object Map]" == t || "[object Set]" == t) return !e.size;
    if (IA(e)) return !PA(e).length;
    for (var r in e)
        if (hO.call(e, r)) return !1;
    return !0
}

function vO(e, t, r) {
    return void 0 === r && (r = t, t = void 0), void 0 !== r && (r = (r = sO(r)) == r ? r : 0), void 0 !== t && (t = (t = sO(t)) == t ? t : 0),
        function(e, t, r) {
            return e == e && (void 0 !== r && (e = e <= r ? e : r), void 0 !== t && (e = e >= t ? e : t)), e
        }(sO(e), t, r)
}
var yO = ZI(function(e, t, r) {
    QI(e, t, r)
});

function gO(e) {
    return "string" == typeof e || !DT(e) && HT(e) && "[object String]" == zT(e)
}

function bO(e) {
    return Math.round(parseInt(e, 16) / 255 * 100) / 100
}

function mO(...e) {
    if (1 === e.length && e[0] instanceof mO) {
        var t = e[0];
        return this.red = t.red, this.green = t.green, this.blue = t.blue, this.alpha = t.alpha, this.hue = t.hue, this.saturation = t.saturation, this.lightness = t.lightness, this
    }
    if (1 === e.length) {
        if ("string" == typeof e[0] && e[0].indexOf("rgb") >= 0) return this.rgba = function(e) {
            var t = /rgba?\((\d{1,3}),\s*(\d{1,3}),\s*(\d{1,3})(,\s*([\d.]+))?\)/.exec(e);
            if (!t) throw new Error("Invalid rgb value");
            return {
                red: parseInt(t[1], 10),
                green: parseInt(t[2], 10),
                blue: parseInt(t[3], 10),
                alpha: parseFloat(t[5]) || 1
            }
        }(e[0]), this;
        if (! function(e) {
                return "string" == typeof(e = e.replace("#", "")) && [3, 4, 6, 8].includes(e.length) && !isNaN(parseInt(e, 16))
            }(`${e[0]}`)) throw new Error("Invalid hex value");
        const {
            hex: t,
            alpha: r
        } = function(e) {
            let t = 1;
            return 4 === (e = e.replace("#", "")).length && (t = bO(e.slice(3) + e.slice(3)), e = e.slice(0, 3)), 8 === e.length && (t = bO(e.slice(6, 8)), e = e.slice(0, 6)), {
                hex: e,
                alpha: t
            }
        }(`${e[0]}`);
        return this.hex = t, this.alpha = r, this
    }
    if (3 === e.length || 4 === e.length) {
        for (var r = 0; r < 3; r++)
            if (isNaN(parseInt(e[r], 10)) || parseInt(e[r], 10) < 0 || parseInt(e[r], 10) > 255) throw new Error("Invalid rgb value");
        if (e[3] && parseFloat(e[3]) < 0 || parseFloat(e[3]) > 1) throw new Error("Invalid alpha value");
        return this.rgba = {
            red: e[0],
            green: e[1],
            blue: e[2],
            alpha: parseFloat(e[3]) || 1
        }, this
    }
    throw new Error("Invalid color")
}
mO.prototype = {
    get complement() {
        var e = this.clone();
        return e.rgb = {
            red: 255 - this.red,
            green: 255 - this.green,
            blue: 255 - this.blue
        }, e
    },
    get hex() {
        return mO.rgbToHex(this.red, this.green, this.blue)
    },
    get hexWithAlpha() {
        const e = ("0" + Math.round(255 * this.alpha).toString(16)).slice(-2);
        return mO.rgbToHex(this.red, this.green, this.blue) + e
    },
    set hex(e) {
        return this.rgba = mO.hexToRgb(e), this
    },
    get hsl() {
        return "hsl(" + this.hue + "," + this.saturation + "%," + Math.round(this.lightness) + "%)"
    },
    set hsl(e) {
        this.hue = e.hue, this.saturation = e.saturation, this.lightness = e.lightness;
        var t = mO.hslToRgb(e.hue, e.saturation, e.lightness);
        return this.red = t.red, this.green = t.green, this.blue = t.blue, this.alpha = t.alpha, this
    },
    get luminance() {
        function e(e) {
            return e <= .03928 ? e / 12.92 : Math.pow((e + .055) / 1.055, 2.4)
        }
        return .2126 * e(this.red / 255) + .7152 * e(this.green / 255) + .0722 * e(this.blue / 255)
    },
    get rgb() {
        return "rgb(" + this.red + "," + this.green + "," + this.blue + ")"
    },
    set rgb(e) {
        return this.rgba = e, this
    },
    get rgba() {
        return "rgba(" + this.red + "," + this.green + "," + this.blue + "," + this.alpha + ")"
    },
    set rgba(e) {
        this.red = e.red, this.green = e.green, this.blue = e.blue, this.alpha = e.alpha || 1;
        var t = mO.rgbToHsl(e.red, e.green, e.blue);
        return this.hue = t.hue, this.saturation = t.saturation, this.lightness = t.lightness, this
    },
    get yiq() {
        return (299 * this.red + 587 * this.green + 114 * this.blue) / 1e3
    },
    clone: function() {
        return new mO(this)
    },
    lighten: function(e, t, r) {
        if (this.hsl = {
                hue: this.hue,
                saturation: this.saturation,
                lightness: this.lightness + e
            }, t && r)
            for (var n = r.contrast(this).ratio; n < t && (this.lighten(5), n = r.contrast(this).ratio, !(this.lightness >= 100)););
        return this
    },
    darken: function(e, t, r) {
        if (this.hsl = {
                hue: this.hue,
                saturation: this.saturation,
                lightness: this.lightness - e
            }, t && r)
            for (var n = r.contrast(this).ratio; n < t && (this.darken(5), n = r.contrast(this).ratio, !(this.lightness <= 0)););
        return this
    },
    overlayOn: function(e) {
        if (this.alpha >= 1) return this;
        var t = this.clone();
        return t.rgba = {
            red: t.red * this.alpha + e.red * e.alpha * (1 - this.alpha),
            green: t.green * this.alpha + e.green * e.alpha * (1 - this.alpha),
            blue: t.blue * this.alpha + e.blue * e.alpha * (1 - this.alpha),
            alpha: t.alpha + e.alpha * (1 - this.alpha)
        }, t
    },
    contrast: function(e) {
        var t = this.alpha;
        if (t >= 1) {
            e.alpha < 1 && (e = e.overlayOn(this));
            var r = this.luminance + .05,
                n = e.luminance + .05,
                o = r / n;
            return n > r && (o = 1 / o), {
                ratio: o = Math.round(10 * o) / 10,
                error: 0,
                min: o,
                max: o
            }
        }
        var i = this.overlayOn(mO.white).contrast(e).ratio,
            a = this.overlayOn(mO.black).contrast(e).ratio,
            u = Math.max(i, a),
            s = {
                red: Math.min(Math.max(0, (e.red - this.red * t) / (1 - t)), 255),
                green: Math.min(Math.max(0, (e.green - this.green * t) / (1 - t)), 255),
                blue: Math.min(Math.max(0, (e.blue - this.blue * t) / (1 - t)), 255)
            },
            c = this.clone();
        c.rgb = s;
        var f = this.overlayOn(c).contrast(e).ratio;
        return {
            ratio: Math.round((f + u) / 2 * 10) / 10,
            error: Math.round((u - f) / 2 * 10) / 10,
            min: f,
            max: u,
            closest: c,
            farthest: a === u ? mO.white : mO.black
        }
    },
    wcagAACompliant: function(e) {
        return this.contrast(e).ratio >= 4.5
    },
    wcagAAACompliant: function(e) {
        return this.contrast(e).ratio >= 7
    },
    yiqContrastColor: function() {
        return this.yiq >= 120 ? new mO(0, 0, 0) : new mO(255, 255, 255)
    }
}, mO.hexToRgb = function(e) {
    var t;
    return 3 === (e = String(e)).length || 4 === e.length ? (t = /^#?([A-Fa-f0-9])([A-Fa-f0-9])([A-Fa-f0-9])$/i.exec(e)) && (t[1] += t[1], t[2] += t[2], t[3] += t[3]) : t = /^#?([A-Fa-f0-9]{2})([A-Fa-f0-9]{2})([A-Fa-f0-9]{2})$/i.exec(e), t ? {
        red: parseInt(t[1], 16),
        green: parseInt(t[2], 16),
        blue: parseInt(t[3], 16),
        alpha: 1
    } : null
}, mO.rgbToHex = function(e, t, r) {
    return "#" + ((1 << 24) + (Math.round(e) << 16) + (Math.round(t) << 8) + Math.round(r)).toString(16).slice(1)
}, mO.rgbToHsl = function(e, t, r) {
    e /= 255, t /= 255, r /= 255;
    var n, o = Math.max(e, t, r),
        i = Math.min(e, t, r),
        a = (o + i) / 2,
        u = a;
    if (o === i) return {
        hue: 0,
        saturation: 0,
        lightness: 100 * u
    };
    var s = o - i;
    return n = u > .5 ? s / (2 - o - i) : s / (o + i), o === e ? a = (t - r) / s + (t < r ? 6 : 0) : o === t ? a = (r - e) / s + 2 : o === r && (a = (e - t) / s + 4), a /= 6, {
        hue: Math.round(360 * a),
        saturation: Math.round(100 * n),
        lightness: Math.round(100 * u)
    }
}, mO.hslToRgb = function(e, t, r) {
    function n(e, t, r) {
        return r < 0 && (r += 1), r > 1 && (r -= 1), 6 * r < 1 ? e + 6 * (t - e) * r : 2 * r < 1 ? t : 3 * r < 2 ? e + 6 * (2 / 3 - r) * (t - e) : e
    }
    if (e /= 360, r /= 100, 0 == (t /= 100)) return {
        red: Math.floor(255 * r),
        green: Math.floor(255 * r),
        blue: Math.floor(255 * r)
    };
    var o = r < .5 ? r * (1 + t) : r + t - t * r,
        i = 2 * r - o;
    return {
        red: Math.floor(255 * n(i, o, e + 1 / 3)),
        green: Math.floor(255 * n(i, o, e)),
        blue: Math.floor(255 * n(i, o, e - 1 / 3))
    }
}, mO.hslToHex = function(e, t, r) {
    var n = mO.hslToRgb(e, t, r);
    return mO.rgbToHex(n.red, n.green, n.blue)
}, mO.white = new mO("fff"), mO.black = new mO("000");
var wO = function() {
        return kT.Date.now()
    },
    EO = Math.max,
    _O = Math.min;

function TO(e, t, r) {
    var n, o, i, a, u, s, c = 0,
        f = !1,
        l = !1,
        d = !0;
    if ("function" != typeof e) throw new TypeError("Expected a function");

    function h(t) {
        var r = n,
            i = o;
        return n = o = void 0, c = t, a = e.apply(i, r)
    }

    function p(e) {
        var r = e - s;
        return void 0 === s || r >= t || r < 0 || l && e - c >= i
    }

    function v() {
        var e = wO();
        if (p(e)) return y(e);
        u = setTimeout(v, function(e) {
            var r = t - (e - s);
            return l ? _O(r, i - (e - c)) : r
        }(e))
    }

    function y(e) {
        return u = void 0, d && n ? h(e) : (n = o = void 0, a)
    }

    function g() {
        var e = wO(),
            r = p(e);
        if (n = arguments, o = this, s = e, r) {
            if (void 0 === u) return function(e) {
                return c = e, u = setTimeout(v, t), f ? h(e) : a
            }(s);
            if (l) return clearTimeout(u), u = setTimeout(v, t), h(s)
        }
        return void 0 === u && (u = setTimeout(v, t)), a
    }
    return t = sO(t) || 0, KT(r) && (f = !!r.leading, i = (l = "maxWait" in r) ? EO(sO(r.maxWait) || 0, t) : i, d = "trailing" in r ? !!r.trailing : d), g.cancel = function() {
        void 0 !== u && clearTimeout(u), c = 0, n = s = o = u = void 0
    }, g.flush = function() {
        return void 0 === u ? a : y(wO())
    }, g
}

function SO(e, t, r) {
    var n = !0,
        o = !0;
    if ("function" != typeof e) throw new TypeError("Expected a function");
    return KT(r) && (n = "leading" in r ? !!r.leading : n, o = "trailing" in r ? !!r.trailing : o), TO(e, t, {
        leading: n,
        maxWait: t,
        trailing: o
    })
}
const AO = [];
for (let e = 0; e < 256; ++e) AO.push((e + 256).toString(16).slice(1));
let IO;
const OO = new Uint8Array(16);
var RO = {
    randomUUID: "undefined" != typeof crypto && crypto.randomUUID && crypto.randomUUID.bind(crypto)
};

function NO(e, t, r) {
    if (RO.randomUUID && !t && !e) return RO.randomUUID();
    const n = (e = e || {}).random ? ? e.rng ? .() ? ? function() {
        if (!IO) {
            if ("undefined" == typeof crypto || !crypto.getRandomValues) throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
            IO = crypto.getRandomValues.bind(crypto)
        }
        return IO(OO)
    }();
    if (n.length < 16) throw new Error("Random bytes length must be >= 16");
    if (n[6] = 15 & n[6] | 64, n[8] = 63 & n[8] | 128, t) {
        if ((r = r || 0) < 0 || r + 16 > t.length) throw new RangeError(`UUID byte range ${r}:${r+15} is out of buffer bounds`);
        for (let e = 0; e < 16; ++e) t[r + e] = n[e];
        return t
    }
    return function(e, t = 0) {
        return (AO[e[t + 0]] + AO[e[t + 1]] + AO[e[t + 2]] + AO[e[t + 3]] + "-" + AO[e[t + 4]] + AO[e[t + 5]] + "-" + AO[e[t + 6]] + AO[e[t + 7]] + "-" + AO[e[t + 8]] + AO[e[t + 9]] + "-" + AO[e[t + 10]] + AO[e[t + 11]] + AO[e[t + 12]] + AO[e[t + 13]] + AO[e[t + 14]] + AO[e[t + 15]]).toLowerCase()
    }(n)
}
var PO = t(function(t, r) {
        ! function(e, n) {
            var o = "function",
                i = "undefined",
                a = "object",
                u = "string",
                s = "major",
                c = "model",
                f = "name",
                l = "type",
                d = "vendor",
                h = "version",
                p = "architecture",
                v = "console",
                y = "mobile",
                g = "tablet",
                b = "smarttv",
                m = "wearable",
                w = "embedded",
                E = "Amazon",
                _ = "Apple",
                T = "ASUS",
                S = "BlackBerry",
                A = "Browser",
                I = "Chrome",
                O = "Firefox",
                R = "Google",
                N = "Honor",
                P = "Huawei",
                M = "LG",
                D = "Microsoft",
                x = "Motorola",
                C = "Nvidia",
                k = "OnePlus",
                L = "Opera",
                j = "OPPO",
                X = "Samsung",
                U = "Sharp",
                B = "Sony",
                F = "Xiaomi",
                V = "Zebra",
                z = "Facebook",
                H = "Chromium OS",
                W = "Mac OS",
                Y = " Browser",
                G = function(e) {
                    for (var t = {}, r = 0; r < e.length; r++) t[e[r].toUpperCase()] = e[r];
                    return t
                },
                K = function(e, t) {
                    return typeof e === u && -1 !== q(t).indexOf(q(e))
                },
                q = function(e) {
                    return e.toLowerCase()
                },
                $ = function(e, t) {
                    if (typeof e === u) return e = e.replace(/^\s\s*/, ""), typeof t === i ? e : e.substring(0, 500)
                },
                Q = function(e, t) {
                    for (var r, i, u, s, c, f, l = 0; l < t.length && !c;) {
                        var d = t[l],
                            h = t[l + 1];
                        for (r = i = 0; r < d.length && !c && d[r];)
                            if (c = d[r++].exec(e))
                                for (u = 0; u < h.length; u++) f = c[++i], typeof(s = h[u]) === a && s.length > 0 ? 2 === s.length ? typeof s[1] == o ? this[s[0]] = s[1].call(this, f) : this[s[0]] = s[1] : 3 === s.length ? typeof s[1] !== o || s[1].exec && s[1].test ? this[s[0]] = f ? f.replace(s[1], s[2]) : n : this[s[0]] = f ? s[1].call(this, f, s[2]) : n : 4 === s.length && (this[s[0]] = f ? s[3].call(this, f.replace(s[1], s[2])) : n) : this[s] = f || n;
                        l += 2
                    }
                },
                J = function(e, t) {
                    for (var r in t)
                        if (typeof t[r] === a && t[r].length > 0) {
                            for (var o = 0; o < t[r].length; o++)
                                if (K(t[r][o], e)) return "?" === r ? n : r
                        } else if (K(t[r], e)) return "?" === r ? n : r;
                    return t.hasOwnProperty("*") ? t["*"] : e
                },
                Z = {
                    ME: "4.90",
                    "NT 3.11": "NT3.51",
                    "NT 4.0": "NT4.0",
                    2e3: "NT 5.0",
                    XP: ["NT 5.1", "NT 5.2"],
                    Vista: "NT 6.0",
                    7: "NT 6.1",
                    8: "NT 6.2",
                    8.1: "NT 6.3",
                    10: ["NT 6.4", "NT 10.0"],
                    RT: "ARM"
                },
                ee = {
                    browser: [
                        [/\b(?:crmo|crios)\/([\w\.]+)/i],
                        [h, [f, "Chrome"]],
                        [/edg(?:e|ios|a)?\/([\w\.]+)/i],
                        [h, [f, "Edge"]],
                        [/(opera mini)\/([-\w\.]+)/i, /(opera [mobiletab]{3,6})\b.+version\/([-\w\.]+)/i, /(opera)(?:.+version\/|[\/ ]+)([\w\.]+)/i],
                        [f, h],
                        [/opios[\/ ]+([\w\.]+)/i],
                        [h, [f, L + " Mini"]],
                        [/\bop(?:rg)?x\/([\w\.]+)/i],
                        [h, [f, L + " GX"]],
                        [/\bopr\/([\w\.]+)/i],
                        [h, [f, L]],
                        [/\bb[ai]*d(?:uhd|[ub]*[aekoprswx]{5,6})[\/ ]?([\w\.]+)/i],
                        [h, [f, "Baidu"]],
                        [/\b(?:mxbrowser|mxios|myie2)\/?([-\w\.]*)\b/i],
                        [h, [f, "Maxthon"]],
                        [/(kindle)\/([\w\.]+)/i, /(lunascape|maxthon|netfront|jasmine|blazer|sleipnir)[\/ ]?([\w\.]*)/i, /(avant|iemobile|slim(?:browser|boat|jet))[\/ ]?([\d\.]*)/i, /(?:ms|\()(ie) ([\w\.]+)/i, /(flock|rockmelt|midori|epiphany|silk|skyfire|ovibrowser|bolt|iron|vivaldi|iridium|phantomjs|bowser|qupzilla|falkon|rekonq|puffin|brave|whale(?!.+naver)|qqbrowserlite|duckduckgo|klar|helio|(?=comodo_)?dragon)\/([-\w\.]+)/i, /(heytap|ovi|115)browser\/([\d\.]+)/i, /(weibo)__([\d\.]+)/i],
                        [f, h],
                        [/quark(?:pc)?\/([-\w\.]+)/i],
                        [h, [f, "Quark"]],
                        [/\bddg\/([\w\.]+)/i],
                        [h, [f, "DuckDuckGo"]],
                        [/(?:\buc? ?browser|(?:juc.+)ucweb)[\/ ]?([\w\.]+)/i],
                        [h, [f, "UC" + A]],
                        [/microm.+\bqbcore\/([\w\.]+)/i, /\bqbcore\/([\w\.]+).+microm/i, /micromessenger\/([\w\.]+)/i],
                        [h, [f, "WeChat"]],
                        [/konqueror\/([\w\.]+)/i],
                        [h, [f, "Konqueror"]],
                        [/trident.+rv[: ]([\w\.]{1,9})\b.+like gecko/i],
                        [h, [f, "IE"]],
                        [/ya(?:search)?browser\/([\w\.]+)/i],
                        [h, [f, "Yandex"]],
                        [/slbrowser\/([\w\.]+)/i],
                        [h, [f, "Smart Lenovo " + A]],
                        [/(avast|avg)\/([\w\.]+)/i],
                        [
                            [f, /(.+)/, "$1 Secure " + A], h
                        ],
                        [/\bfocus\/([\w\.]+)/i],
                        [h, [f, O + " Focus"]],
                        [/\bopt\/([\w\.]+)/i],
                        [h, [f, L + " Touch"]],
                        [/coc_coc\w+\/([\w\.]+)/i],
                        [h, [f, "Coc Coc"]],
                        [/dolfin\/([\w\.]+)/i],
                        [h, [f, "Dolphin"]],
                        [/coast\/([\w\.]+)/i],
                        [h, [f, L + " Coast"]],
                        [/miuibrowser\/([\w\.]+)/i],
                        [h, [f, "MIUI" + Y]],
                        [/fxios\/([\w\.-]+)/i],
                        [h, [f, O]],
                        [/\bqihoobrowser\/?([\w\.]*)/i],
                        [h, [f, "360"]],
                        [/\b(qq)\/([\w\.]+)/i],
                        [
                            [f, /(.+)/, "$1Browser"], h
                        ],
                        [/(oculus|sailfish|huawei|vivo|pico)browser\/([\w\.]+)/i],
                        [
                            [f, /(.+)/, "$1" + Y], h
                        ],
                        [/samsungbrowser\/([\w\.]+)/i],
                        [h, [f, X + " Internet"]],
                        [/metasr[\/ ]?([\d\.]+)/i],
                        [h, [f, "Sogou Explorer"]],
                        [/(sogou)mo\w+\/([\d\.]+)/i],
                        [
                            [f, "Sogou Mobile"], h
                        ],
                        [/(electron)\/([\w\.]+) safari/i, /(tesla)(?: qtcarbrowser|\/(20\d\d\.[-\w\.]+))/i, /m?(qqbrowser|2345(?=browser|chrome|explorer))\w*[\/ ]?v?([\w\.]+)/i],
                        [f, h],
                        [/(lbbrowser|rekonq)/i, /\[(linkedin)app\]/i],
                        [f],
                        [/ome\/([\w\.]+) \w* ?(iron) saf/i, /ome\/([\w\.]+).+qihu (360)[es]e/i],
                        [h, f],
                        [/((?:fban\/fbios|fb_iab\/fb4a)(?!.+fbav)|;fbav\/([\w\.]+);)/i],
                        [
                            [f, z], h
                        ],
                        [/(Klarna)\/([\w\.]+)/i, /(kakao(?:talk|story))[\/ ]([\w\.]+)/i, /(naver)\(.*?(\d+\.[\w\.]+).*\)/i, /(daum)apps[\/ ]([\w\.]+)/i, /safari (line)\/([\w\.]+)/i, /\b(line)\/([\w\.]+)\/iab/i, /(alipay)client\/([\w\.]+)/i, /(twitter)(?:and| f.+e\/([\w\.]+))/i, /(chromium|instagram|snapchat)[\/ ]([-\w\.]+)/i],
                        [f, h],
                        [/\bgsa\/([\w\.]+) .*safari\//i],
                        [h, [f, "GSA"]],
                        [/musical_ly(?:.+app_?version\/|_)([\w\.]+)/i],
                        [h, [f, "TikTok"]],
                        [/headlesschrome(?:\/([\w\.]+)| )/i],
                        [h, [f, I + " Headless"]],
                        [/ wv\).+(chrome)\/([\w\.]+)/i],
                        [
                            [f, I + " WebView"], h
                        ],
                        [/droid.+ version\/([\w\.]+)\b.+(?:mobile safari|safari)/i],
                        [h, [f, "Android " + A]],
                        [/(chrome|omniweb|arora|[tizenoka]{5} ?browser)\/v?([\w\.]+)/i],
                        [f, h],
                        [/version\/([\w\.\,]+) .*mobile\/\w+ (safari)/i],
                        [h, [f, "Mobile Safari"]],
                        [/version\/([\w(\.|\,)]+) .*(mobile ?safari|safari)/i],
                        [h, f],
                        [/webkit.+?(mobile ?safari|safari)(\/[\w\.]+)/i],
                        [f, [h, J, {
                            "1.0": "/8",
                            1.2: "/1",
                            1.3: "/3",
                            "2.0": "/412",
                            "2.0.2": "/416",
                            "2.0.3": "/417",
                            "2.0.4": "/419",
                            "?": "/"
                        }]],
                        [/(webkit|khtml)\/([\w\.]+)/i],
                        [f, h],
                        [/(navigator|netscape\d?)\/([-\w\.]+)/i],
                        [
                            [f, "Netscape"], h
                        ],
                        [/(wolvic|librewolf)\/([\w\.]+)/i],
                        [f, h],
                        [/mobile vr; rv:([\w\.]+)\).+firefox/i],
                        [h, [f, O + " Reality"]],
                        [/ekiohf.+(flow)\/([\w\.]+)/i, /(swiftfox)/i, /(icedragon|iceweasel|camino|chimera|fennec|maemo browser|minimo|conkeror)[\/ ]?([\w\.\+]+)/i, /(seamonkey|k-meleon|icecat|iceape|firebird|phoenix|palemoon|basilisk|waterfox)\/([-\w\.]+)$/i, /(firefox)\/([\w\.]+)/i, /(mozilla)\/([\w\.]+) .+rv\:.+gecko\/\d+/i, /(amaya|dillo|doris|icab|ladybird|lynx|mosaic|netsurf|obigo|polaris|w3m|(?:go|ice|up)[\. ]?browser)[-\/ ]?v?([\w\.]+)/i, /\b(links) \(([\w\.]+)/i],
                        [f, [h, /_/g, "."]],
                        [/(cobalt)\/([\w\.]+)/i],
                        [f, [h, /master.|lts./, ""]]
                    ],
                    cpu: [
                        [/\b((amd|x|x86[-_]?|wow|win)64)\b/i],
                        [
                            [p, "amd64"]
                        ],
                        [/(ia32(?=;))/i, /\b((i[346]|x)86)(pc)?\b/i],
                        [
                            [p, "ia32"]
                        ],
                        [/\b(aarch64|arm(v?[89]e?l?|_?64))\b/i],
                        [
                            [p, "arm64"]
                        ],
                        [/\b(arm(v[67])?ht?n?[fl]p?)\b/i],
                        [
                            [p, "armhf"]
                        ],
                        [/( (ce|mobile); ppc;|\/[\w\.]+arm\b)/i],
                        [
                            [p, "arm"]
                        ],
                        [/((ppc|powerpc)(64)?)( mac|;|\))/i],
                        [
                            [p, /ower/, "", q]
                        ],
                        [/ sun4\w[;\)]/i],
                        [
                            [p, "sparc"]
                        ],
                        [/\b(avr32|ia64(?=;)|68k(?=\))|\barm(?=v([1-7]|[5-7]1)l?|;|eabi)|(irix|mips|sparc)(64)?\b|pa-risc)/i],
                        [
                            [p, q]
                        ]
                    ],
                    device: [
                        [/\b(sch-i[89]0\d|shw-m380s|sm-[ptx]\w{2,4}|gt-[pn]\d{2,4}|sgh-t8[56]9|nexus 10)/i],
                        [c, [d, X],
                            [l, g]
                        ],
                        [/\b((?:s[cgp]h|gt|sm)-(?![lr])\w+|sc[g-]?[\d]+a?|galaxy nexus)/i, /samsung[- ]((?!sm-[lr])[-\w]+)/i, /sec-(sgh\w+)/i],
                        [c, [d, X],
                            [l, y]
                        ],
                        [/(?:\/|\()(ip(?:hone|od)[\w, ]*)(?:\/|;)/i],
                        [c, [d, _],
                            [l, y]
                        ],
                        [/\((ipad);[-\w\),; ]+apple/i, /applecoremedia\/[\w\.]+ \((ipad)/i, /\b(ipad)\d\d?,\d\d?[;\]].+ios/i],
                        [c, [d, _],
                            [l, g]
                        ],
                        [/(macintosh);/i],
                        [c, [d, _]],
                        [/\b(sh-?[altvz]?\d\d[a-ekm]?)/i],
                        [c, [d, U],
                            [l, y]
                        ],
                        [/\b((?:brt|eln|hey2?|gdi|jdn)-a?[lnw]09|(?:ag[rm]3?|jdn2|kob2)-a?[lw]0[09]hn)(?: bui|\)|;)/i],
                        [c, [d, N],
                            [l, g]
                        ],
                        [/honor([-\w ]+)[;\)]/i],
                        [c, [d, N],
                            [l, y]
                        ],
                        [/\b((?:ag[rs][2356]?k?|bah[234]?|bg[2o]|bt[kv]|cmr|cpn|db[ry]2?|jdn2|got|kob2?k?|mon|pce|scm|sht?|[tw]gr|vrd)-[ad]?[lw][0125][09]b?|605hw|bg2-u03|(?:gem|fdr|m2|ple|t1)-[7a]0[1-4][lu]|t1-a2[13][lw]|mediapad[\w\. ]*(?= bui|\)))\b(?!.+d\/s)/i],
                        [c, [d, P],
                            [l, g]
                        ],
                        [/(?:huawei)([-\w ]+)[;\)]/i, /\b(nexus 6p|\w{2,4}e?-[atu]?[ln][\dx][012359c][adn]?)\b(?!.+d\/s)/i],
                        [c, [d, P],
                            [l, y]
                        ],
                        [/oid[^\)]+; (2[\dbc]{4}(182|283|rp\w{2})[cgl]|m2105k81a?c)(?: bui|\))/i, /\b((?:red)?mi[-_ ]?pad[\w- ]*)(?: bui|\))/i],
                        [
                            [c, /_/g, " "],
                            [d, F],
                            [l, g]
                        ],
                        [/\b(poco[\w ]+|m2\d{3}j\d\d[a-z]{2})(?: bui|\))/i, /\b; (\w+) build\/hm\1/i, /\b(hm[-_ ]?note?[_ ]?(?:\d\w)?) bui/i, /\b(redmi[\-_ ]?(?:note|k)?[\w_ ]+)(?: bui|\))/i, /oid[^\)]+; (m?[12][0-389][01]\w{3,6}[c-y])( bui|; wv|\))/i, /\b(mi[-_ ]?(?:a\d|one|one[_ ]plus|note lte|max|cc)?[_ ]?(?:\d?\w?)[_ ]?(?:plus|se|lite|pro)?)(?: bui|\))/i, / ([\w ]+) miui\/v?\d/i],
                        [
                            [c, /_/g, " "],
                            [d, F],
                            [l, y]
                        ],
                        [/; (\w+) bui.+ oppo/i, /\b(cph[12]\d{3}|p(?:af|c[al]|d\w|e[ar])[mt]\d0|x9007|a101op)\b/i],
                        [c, [d, j],
                            [l, y]
                        ],
                        [/\b(opd2(\d{3}a?))(?: bui|\))/i],
                        [c, [d, J, {
                                OnePlus: ["304", "403", "203"],
                                "*": j
                            }],
                            [l, g]
                        ],
                        [/vivo (\w+)(?: bui|\))/i, /\b(v[12]\d{3}\w?[at])(?: bui|;)/i],
                        [c, [d, "Vivo"],
                            [l, y]
                        ],
                        [/\b(rmx[1-3]\d{3})(?: bui|;|\))/i],
                        [c, [d, "Realme"],
                            [l, y]
                        ],
                        [/\b(milestone|droid(?:[2-4x]| (?:bionic|x2|pro|razr))?:?( 4g)?)\b[\w ]+build\//i, /\bmot(?:orola)?[- ](\w*)/i, /((?:moto(?! 360)[\w\(\) ]+|xt\d{3,4}|nexus 6)(?= bui|\)))/i],
                        [c, [d, x],
                            [l, y]
                        ],
                        [/\b(mz60\d|xoom[2 ]{0,2}) build\//i],
                        [c, [d, x],
                            [l, g]
                        ],
                        [/((?=lg)?[vl]k\-?\d{3}) bui| 3\.[-\w; ]{10}lg?-([06cv9]{3,4})/i],
                        [c, [d, M],
                            [l, g]
                        ],
                        [/(lm(?:-?f100[nv]?|-[\w\.]+)(?= bui|\))|nexus [45])/i, /\blg[-e;\/ ]+((?!browser|netcast|android tv|watch)\w+)/i, /\blg-?([\d\w]+) bui/i],
                        [c, [d, M],
                            [l, y]
                        ],
                        [/(ideatab[-\w ]+|602lv|d-42a|a101lv|a2109a|a3500-hv|s[56]000|pb-6505[my]|tb-?x?\d{3,4}(?:f[cu]|xu|[av])|yt\d?-[jx]?\d+[lfmx])( bui|;|\)|\/)/i, /lenovo ?(b[68]0[08]0-?[hf]?|tab(?:[\w- ]+?)|tb[\w-]{6,7})( bui|;|\)|\/)/i],
                        [c, [d, "Lenovo"],
                            [l, g]
                        ],
                        [/(nokia) (t[12][01])/i],
                        [d, c, [l, g]],
                        [/(?:maemo|nokia).*(n900|lumia \d+|rm-\d+)/i, /nokia[-_ ]?(([-\w\. ]*))/i],
                        [
                            [c, /_/g, " "],
                            [l, y],
                            [d, "Nokia"]
                        ],
                        [/(pixel (c|tablet))\b/i],
                        [c, [d, R],
                            [l, g]
                        ],
                        [/droid.+; (pixel[\daxl ]{0,6})(?: bui|\))/i],
                        [c, [d, R],
                            [l, y]
                        ],
                        [/droid.+; (a?\d[0-2]{2}so|[c-g]\d{4}|so[-gl]\w+|xq-a\w[4-7][12])(?= bui|\).+chrome\/(?![1-6]{0,1}\d\.))/i],
                        [c, [d, B],
                            [l, y]
                        ],
                        [/sony tablet [ps]/i, /\b(?:sony)?sgp\w+(?: bui|\))/i],
                        [
                            [c, "Xperia Tablet"],
                            [d, B],
                            [l, g]
                        ],
                        [/ (kb2005|in20[12]5|be20[12][59])\b/i, /(?:one)?(?:plus)? (a\d0\d\d)(?: b|\))/i],
                        [c, [d, k],
                            [l, y]
                        ],
                        [/(alexa)webm/i, /(kf[a-z]{2}wi|aeo(?!bc)\w\w)( bui|\))/i, /(kf[a-z]+)( bui|\)).+silk\//i],
                        [c, [d, E],
                            [l, g]
                        ],
                        [/((?:sd|kf)[0349hijorstuw]+)( bui|\)).+silk\//i],
                        [
                            [c, /(.+)/g, "Fire Phone $1"],
                            [d, E],
                            [l, y]
                        ],
                        [/(playbook);[-\w\),; ]+(rim)/i],
                        [c, d, [l, g]],
                        [/\b((?:bb[a-f]|st[hv])100-\d)/i, /\(bb10; (\w+)/i],
                        [c, [d, S],
                            [l, y]
                        ],
                        [/(?:\b|asus_)(transfo[prime ]{4,10} \w+|eeepc|slider \w+|nexus 7|padfone|p00[cj])/i],
                        [c, [d, T],
                            [l, g]
                        ],
                        [/ (z[bes]6[027][012][km][ls]|zenfone \d\w?)\b/i],
                        [c, [d, T],
                            [l, y]
                        ],
                        [/(nexus 9)/i],
                        [c, [d, "HTC"],
                            [l, g]
                        ],
                        [/(htc)[-;_ ]{1,2}([\w ]+(?=\)| bui)|\w+)/i, /(zte)[- ]([\w ]+?)(?: bui|\/|\))/i, /(alcatel|geeksphone|nexian|panasonic(?!(?:;|\.))|sony(?!-bra))[-_ ]?([-\w]*)/i],
                        [d, [c, /_/g, " "],
                            [l, y]
                        ],
                        [/droid [\w\.]+; ((?:8[14]9[16]|9(?:0(?:48|60|8[01])|1(?:3[27]|66)|2(?:6[69]|9[56])|466))[gqswx])\w*(\)| bui)/i],
                        [c, [d, "TCL"],
                            [l, g]
                        ],
                        [/(itel) ((\w+))/i],
                        [
                            [d, q], c, [l, J, {
                                tablet: ["p10001l", "w7001"],
                                "*": "mobile"
                            }]
                        ],
                        [/droid.+; ([ab][1-7]-?[0178a]\d\d?)/i],
                        [c, [d, "Acer"],
                            [l, g]
                        ],
                        [/droid.+; (m[1-5] note) bui/i, /\bmz-([-\w]{2,})/i],
                        [c, [d, "Meizu"],
                            [l, y]
                        ],
                        [/; ((?:power )?armor(?:[\w ]{0,8}))(?: bui|\))/i],
                        [c, [d, "Ulefone"],
                            [l, y]
                        ],
                        [/; (energy ?\w+)(?: bui|\))/i, /; energizer ([\w ]+)(?: bui|\))/i],
                        [c, [d, "Energizer"],
                            [l, y]
                        ],
                        [/; cat (b35);/i, /; (b15q?|s22 flip|s48c|s62 pro)(?: bui|\))/i],
                        [c, [d, "Cat"],
                            [l, y]
                        ],
                        [/((?:new )?andromax[\w- ]+)(?: bui|\))/i],
                        [c, [d, "Smartfren"],
                            [l, y]
                        ],
                        [/droid.+; (a(?:015|06[35]|142p?))/i],
                        [c, [d, "Nothing"],
                            [l, y]
                        ],
                        [/; (x67 5g|tikeasy \w+|ac[1789]\d\w+)( b|\))/i, /archos ?(5|gamepad2?|([\w ]*[t1789]|hello) ?\d+[\w ]*)( b|\))/i],
                        [c, [d, "Archos"],
                            [l, g]
                        ],
                        [/archos ([\w ]+)( b|\))/i, /; (ac[3-6]\d\w{2,8})( b|\))/i],
                        [c, [d, "Archos"],
                            [l, y]
                        ],
                        [/(imo) (tab \w+)/i, /(infinix) (x1101b?)/i],
                        [d, c, [l, g]],
                        [/(blackberry|benq|palm(?=\-)|sonyericsson|acer|asus(?! zenw)|dell|jolla|meizu|motorola|polytron|infinix|tecno|micromax|advan)[-_ ]?([-\w]*)/i, /; (hmd|imo) ([\w ]+?)(?: bui|\))/i, /(hp) ([\w ]+\w)/i, /(microsoft); (lumia[\w ]+)/i, /(lenovo)[-_ ]?([-\w ]+?)(?: bui|\)|\/)/i, /(oppo) ?([\w ]+) bui/i],
                        [d, c, [l, y]],
                        [/(kobo)\s(ereader|touch)/i, /(hp).+(touchpad(?!.+tablet)|tablet)/i, /(kindle)\/([\w\.]+)/i, /(nook)[\w ]+build\/(\w+)/i, /(dell) (strea[kpr\d ]*[\dko])/i, /(le[- ]+pan)[- ]+(\w{1,9}) bui/i, /(trinity)[- ]*(t\d{3}) bui/i, /(gigaset)[- ]+(q\w{1,9}) bui/i, /(vodafone) ([\w ]+)(?:\)| bui)/i],
                        [d, c, [l, g]],
                        [/(surface duo)/i],
                        [c, [d, D],
                            [l, g]
                        ],
                        [/droid [\d\.]+; (fp\du?)(?: b|\))/i],
                        [c, [d, "Fairphone"],
                            [l, y]
                        ],
                        [/(u304aa)/i],
                        [c, [d, "AT&T"],
                            [l, y]
                        ],
                        [/\bsie-(\w*)/i],
                        [c, [d, "Siemens"],
                            [l, y]
                        ],
                        [/\b(rct\w+) b/i],
                        [c, [d, "RCA"],
                            [l, g]
                        ],
                        [/\b(venue[\d ]{2,7}) b/i],
                        [c, [d, "Dell"],
                            [l, g]
                        ],
                        [/\b(q(?:mv|ta)\w+) b/i],
                        [c, [d, "Verizon"],
                            [l, g]
                        ],
                        [/\b(?:barnes[& ]+noble |bn[rt])([\w\+ ]*) b/i],
                        [c, [d, "Barnes & Noble"],
                            [l, g]
                        ],
                        [/\b(tm\d{3}\w+) b/i],
                        [c, [d, "NuVision"],
                            [l, g]
                        ],
                        [/\b(k88) b/i],
                        [c, [d, "ZTE"],
                            [l, g]
                        ],
                        [/\b(nx\d{3}j) b/i],
                        [c, [d, "ZTE"],
                            [l, y]
                        ],
                        [/\b(gen\d{3}) b.+49h/i],
                        [c, [d, "Swiss"],
                            [l, y]
                        ],
                        [/\b(zur\d{3}) b/i],
                        [c, [d, "Swiss"],
                            [l, g]
                        ],
                        [/\b((zeki)?tb.*\b) b/i],
                        [c, [d, "Zeki"],
                            [l, g]
                        ],
                        [/\b([yr]\d{2}) b/i, /\b(dragon[- ]+touch |dt)(\w{5}) b/i],
                        [
                            [d, "Dragon Touch"], c, [l, g]
                        ],
                        [/\b(ns-?\w{0,9}) b/i],
                        [c, [d, "Insignia"],
                            [l, g]
                        ],
                        [/\b((nxa|next)-?\w{0,9}) b/i],
                        [c, [d, "NextBook"],
                            [l, g]
                        ],
                        [/\b(xtreme\_)?(v(1[045]|2[015]|[3469]0|7[05])) b/i],
                        [
                            [d, "Voice"], c, [l, y]
                        ],
                        [/\b(lvtel\-)?(v1[12]) b/i],
                        [
                            [d, "LvTel"], c, [l, y]
                        ],
                        [/\b(ph-1) /i],
                        [c, [d, "Essential"],
                            [l, y]
                        ],
                        [/\b(v(100md|700na|7011|917g).*\b) b/i],
                        [c, [d, "Envizen"],
                            [l, g]
                        ],
                        [/\b(trio[-\w\. ]+) b/i],
                        [c, [d, "MachSpeed"],
                            [l, g]
                        ],
                        [/\btu_(1491) b/i],
                        [c, [d, "Rotor"],
                            [l, g]
                        ],
                        [/((?:tegranote|shield t(?!.+d tv))[\w- ]*?)(?: b|\))/i],
                        [c, [d, C],
                            [l, g]
                        ],
                        [/(sprint) (\w+)/i],
                        [d, c, [l, y]],
                        [/(kin\.[onetw]{3})/i],
                        [
                            [c, /\./g, " "],
                            [d, D],
                            [l, y]
                        ],
                        [/droid.+; (cc6666?|et5[16]|mc[239][23]x?|vc8[03]x?)\)/i],
                        [c, [d, V],
                            [l, g]
                        ],
                        [/droid.+; (ec30|ps20|tc[2-8]\d[kx])\)/i],
                        [c, [d, V],
                            [l, y]
                        ],
                        [/smart-tv.+(samsung)/i],
                        [d, [l, b]],
                        [/hbbtv.+maple;(\d+)/i],
                        [
                            [c, /^/, "SmartTV"],
                            [d, X],
                            [l, b]
                        ],
                        [/(nux; netcast.+smarttv|lg (netcast\.tv-201\d|android tv))/i],
                        [
                            [d, M],
                            [l, b]
                        ],
                        [/(apple) ?tv/i],
                        [d, [c, _ + " TV"],
                            [l, b]
                        ],
                        [/crkey/i],
                        [
                            [c, I + "cast"],
                            [d, R],
                            [l, b]
                        ],
                        [/droid.+aft(\w+)( bui|\))/i],
                        [c, [d, E],
                            [l, b]
                        ],
                        [/(shield \w+ tv)/i],
                        [c, [d, C],
                            [l, b]
                        ],
                        [/\(dtv[\);].+(aquos)/i, /(aquos-tv[\w ]+)\)/i],
                        [c, [d, U],
                            [l, b]
                        ],
                        [/(bravia[\w ]+)( bui|\))/i],
                        [c, [d, B],
                            [l, b]
                        ],
                        [/(mi(tv|box)-?\w+) bui/i],
                        [c, [d, F],
                            [l, b]
                        ],
                        [/Hbbtv.*(technisat) (.*);/i],
                        [d, c, [l, b]],
                        [/\b(roku)[\dx]*[\)\/]((?:dvp-)?[\d\.]*)/i, /hbbtv\/\d+\.\d+\.\d+ +\([\w\+ ]*; *([\w\d][^;]*);([^;]*)/i],
                        [
                            [d, $],
                            [c, $],
                            [l, b]
                        ],
                        [/droid.+; ([\w- ]+) (?:android tv|smart[- ]?tv)/i],
                        [c, [l, b]],
                        [/\b(android tv|smart[- ]?tv|opera tv|tv; rv:)\b/i],
                        [
                            [l, b]
                        ],
                        [/(ouya)/i, /(nintendo) ([wids3utch]+)/i],
                        [d, c, [l, v]],
                        [/droid.+; (shield)( bui|\))/i],
                        [c, [d, C],
                            [l, v]
                        ],
                        [/(playstation \w+)/i],
                        [c, [d, B],
                            [l, v]
                        ],
                        [/\b(xbox(?: one)?(?!; xbox))[\); ]/i],
                        [c, [d, D],
                            [l, v]
                        ],
                        [/\b(sm-[lr]\d\d[0156][fnuw]?s?|gear live)\b/i],
                        [c, [d, X],
                            [l, m]
                        ],
                        [/((pebble))app/i, /(asus|google|lg|oppo) ((pixel |zen)?watch[\w ]*)( bui|\))/i],
                        [d, c, [l, m]],
                        [/(ow(?:19|20)?we?[1-3]{1,3})/i],
                        [c, [d, j],
                            [l, m]
                        ],
                        [/(watch)(?: ?os[,\/]|\d,\d\/)[\d\.]+/i],
                        [c, [d, _],
                            [l, m]
                        ],
                        [/(opwwe\d{3})/i],
                        [c, [d, k],
                            [l, m]
                        ],
                        [/(moto 360)/i],
                        [c, [d, x],
                            [l, m]
                        ],
                        [/(smartwatch 3)/i],
                        [c, [d, B],
                            [l, m]
                        ],
                        [/(g watch r)/i],
                        [c, [d, M],
                            [l, m]
                        ],
                        [/droid.+; (wt63?0{2,3})\)/i],
                        [c, [d, V],
                            [l, m]
                        ],
                        [/droid.+; (glass) \d/i],
                        [c, [d, R],
                            [l, m]
                        ],
                        [/(pico) (4|neo3(?: link|pro)?)/i],
                        [d, c, [l, m]],
                        [/; (quest( \d| pro)?)/i],
                        [c, [d, z],
                            [l, m]
                        ],
                        [/(tesla)(?: qtcarbrowser|\/[-\w\.]+)/i],
                        [d, [l, w]],
                        [/(aeobc)\b/i],
                        [c, [d, E],
                            [l, w]
                        ],
                        [/(homepod).+mac os/i],
                        [c, [d, _],
                            [l, w]
                        ],
                        [/windows iot/i],
                        [
                            [l, w]
                        ],
                        [/droid .+?; ([^;]+?)(?: bui|; wv\)|\) applew).+? mobile safari/i],
                        [c, [l, y]],
                        [/droid .+?; ([^;]+?)(?: bui|\) applew).+?(?! mobile) safari/i],
                        [c, [l, g]],
                        [/\b((tablet|tab)[;\/]|focus\/\d(?!.+mobile))/i],
                        [
                            [l, g]
                        ],
                        [/(phone|mobile(?:[;\/]| [ \w\/\.]*safari)|pda(?=.+windows ce))/i],
                        [
                            [l, y]
                        ],
                        [/droid .+?; ([\w\. -]+)( bui|\))/i],
                        [c, [d, "Generic"]]
                    ],
                    engine: [
                        [/windows.+ edge\/([\w\.]+)/i],
                        [h, [f, "EdgeHTML"]],
                        [/(arkweb)\/([\w\.]+)/i],
                        [f, h],
                        [/webkit\/537\.36.+chrome\/(?!27)([\w\.]+)/i],
                        [h, [f, "Blink"]],
                        [/(presto)\/([\w\.]+)/i, /(webkit|trident|netfront|netsurf|amaya|lynx|w3m|goanna|servo)\/([\w\.]+)/i, /ekioh(flow)\/([\w\.]+)/i, /(khtml|tasman|links)[\/ ]\(?([\w\.]+)/i, /(icab)[\/ ]([23]\.[\d\.]+)/i, /\b(libweb)/i],
                        [f, h],
                        [/ladybird\//i],
                        [
                            [f, "LibWeb"]
                        ],
                        [/rv\:([\w\.]{1,9})\b.+(gecko)/i],
                        [h, f]
                    ],
                    os: [
                        [/microsoft (windows) (vista|xp)/i],
                        [f, h],
                        [/(windows (?:phone(?: os)?|mobile|iot))[\/ ]?([\d\.\w ]*)/i],
                        [f, [h, J, Z]],
                        [/windows nt 6\.2; (arm)/i, /windows[\/ ]([ntce\d\. ]+\w)(?!.+xbox)/i, /(?:win(?=3|9|n)|win 9x )([nt\d\.]+)/i],
                        [
                            [h, J, Z],
                            [f, "Windows"]
                        ],
                        [/[adehimnop]{4,7}\b(?:.*os ([\w]+) like mac|; opera)/i, /(?:ios;fbsv\/|iphone.+ios[\/ ])([\d\.]+)/i, /cfnetwork\/.+darwin/i],
                        [
                            [h, /_/g, "."],
                            [f, "iOS"]
                        ],
                        [/(mac os x) ?([\w\. ]*)/i, /(macintosh|mac_powerpc\b)(?!.+haiku)/i],
                        [
                            [f, W],
                            [h, /_/g, "."]
                        ],
                        [/droid ([\w\.]+)\b.+(android[- ]x86|harmonyos)/i],
                        [h, f],
                        [/(ubuntu) ([\w\.]+) like android/i],
                        [
                            [f, /(.+)/, "$1 Touch"], h
                        ],
                        [/(android|bada|blackberry|kaios|maemo|meego|openharmony|qnx|rim tablet os|sailfish|series40|symbian|tizen|webos)\w*[-\/; ]?([\d\.]*)/i],
                        [f, h],
                        [/\(bb(10);/i],
                        [h, [f, S]],
                        [/(?:symbian ?os|symbos|s60(?=;)|series ?60)[-\/ ]?([\w\.]*)/i],
                        [h, [f, "Symbian"]],
                        [/mozilla\/[\d\.]+ \((?:mobile|tablet|tv|mobile; [\w ]+); rv:.+ gecko\/([\w\.]+)/i],
                        [h, [f, O + " OS"]],
                        [/web0s;.+rt(tv)/i, /\b(?:hp)?wos(?:browser)?\/([\w\.]+)/i],
                        [h, [f, "webOS"]],
                        [/watch(?: ?os[,\/]|\d,\d\/)([\d\.]+)/i],
                        [h, [f, "watchOS"]],
                        [/crkey\/([\d\.]+)/i],
                        [h, [f, I + "cast"]],
                        [/(cros) [\w]+(?:\)| ([\w\.]+)\b)/i],
                        [
                            [f, H], h
                        ],
                        [/panasonic;(viera)/i, /(netrange)mmh/i, /(nettv)\/(\d+\.[\w\.]+)/i, /(nintendo|playstation) ([wids345portablevuch]+)/i, /(xbox); +xbox ([^\);]+)/i, /\b(joli|palm)\b ?(?:os)?\/?([\w\.]*)/i, /(mint)[\/\(\) ]?(\w*)/i, /(mageia|vectorlinux)[; ]/i, /([kxln]?ubuntu|debian|suse|opensuse|gentoo|arch(?= linux)|slackware|fedora|mandriva|centos|pclinuxos|red ?hat|zenwalk|linpus|raspbian|plan 9|minix|risc os|contiki|deepin|manjaro|elementary os|sabayon|linspire)(?: gnu\/linux)?(?: enterprise)?(?:[- ]linux)?(?:-gnu)?[-\/ ]?(?!chrom|package)([-\w\.]*)/i, /(hurd|linux)(?: arm\w*| x86\w*| ?)([\w\.]*)/i, /(gnu) ?([\w\.]*)/i, /\b([-frentopcghs]{0,5}bsd|dragonfly)[\/ ]?(?!amd|[ix346]{1,2}86)([\w\.]*)/i, /(haiku) (\w+)/i],
                        [f, h],
                        [/(sunos) ?([\w\.\d]*)/i],
                        [
                            [f, "Solaris"], h
                        ],
                        [/((?:open)?solaris)[-\/ ]?([\w\.]*)/i, /(aix) ((\d)(?=\.|\)| )[\w\.])*/i, /\b(beos|os\/2|amigaos|morphos|openvms|fuchsia|hp-ux|serenityos)/i, /(unix) ?([\w\.]*)/i],
                        [f, h]
                    ]
                },
                te = function(t, r) {
                    if (typeof t === a && (r = t, t = n), !(this instanceof te)) return new te(t, r).getResult();
                    var v = typeof e !== i && e.navigator ? e.navigator : n,
                        b = t || (v && v.userAgent ? v.userAgent : ""),
                        m = v && v.userAgentData ? v.userAgentData : n,
                        w = r ? function(e, t) {
                            var r = {};
                            for (var n in e) t[n] && t[n].length % 2 == 0 ? r[n] = t[n].concat(e[n]) : r[n] = e[n];
                            return r
                        }(ee, r) : ee,
                        E = v && v.userAgent == b;
                    return this.getBrowser = function() {
                        var e = {};
                        return e[f] = n, e[h] = n, Q.call(e, b, w.browser), e[s] = function(e) {
                            return typeof e === u ? e.replace(/[^\d\.]/g, "").split(".")[0] : n
                        }(e[h]), E && v && v.brave && typeof v.brave.isBrave == o && (e[f] = "Brave"), e
                    }, this.getCPU = function() {
                        var e = {};
                        return e[p] = n, Q.call(e, b, w.cpu), e
                    }, this.getDevice = function() {
                        var e = {};
                        return e[d] = n, e[c] = n, e[l] = n, Q.call(e, b, w.device), E && !e[l] && m && m.mobile && (e[l] = y), E && "Macintosh" == e[c] && v && typeof v.standalone !== i && v.maxTouchPoints && v.maxTouchPoints > 2 && (e[c] = "iPad", e[l] = g), e
                    }, this.getEngine = function() {
                        var e = {};
                        return e[f] = n, e[h] = n, Q.call(e, b, w.engine), e
                    }, this.getOS = function() {
                        var e = {};
                        return e[f] = n, e[h] = n, Q.call(e, b, w.os), E && !e[f] && m && m.platform && "Unknown" != m.platform && (e[f] = m.platform.replace(/chrome os/i, H).replace(/macos/i, W)), e
                    }, this.getResult = function() {
                        return {
                            ua: this.getUA(),
                            browser: this.getBrowser(),
                            engine: this.getEngine(),
                            os: this.getOS(),
                            device: this.getDevice(),
                            cpu: this.getCPU()
                        }
                    }, this.getUA = function() {
                        return b
                    }, this.setUA = function(e) {
                        return b = typeof e === u && e.length > 500 ? $(e, 500) : e, this
                    }, this.setUA(b), this
                };
            te.VERSION = "1.0.41", te.BROWSER = G([f, h, s]), te.CPU = G([p]), te.DEVICE = G([c, d, l, v, y, b, g, m, w]), te.ENGINE = te.OS = G([f, h]), t.exports && (r = t.exports = te), r.UAParser = te;
            var re = typeof e !== i && (e.jQuery || e.Zepto);
            if (re && !re.ua) {
                var ne = new te;
                re.ua = ne.getResult(), re.ua.get = function() {
                    return ne.getUA()
                }, re.ua.set = function(e) {
                    ne.setUA(e);
                    var t = ne.getResult();
                    for (var r in t) re.ua[r] = t[r]
                }
            }
        }("object" == typeof window ? window : e)
    }),
    MO = t(function(e, t) {
        e.exports = function() {
            function e(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = arguments[t];
                    for (var n in r) e[n] = r[n]
                }
                return e
            }
            return function t(r, n) {
                function o(t, o, i) {
                    if ("undefined" != typeof document) {
                        "number" == typeof(i = e({}, n, i)).expires && (i.expires = new Date(Date.now() + 864e5 * i.expires)), i.expires && (i.expires = i.expires.toUTCString()), t = encodeURIComponent(t).replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent).replace(/[()]/g, escape);
                        var a = "";
                        for (var u in i) i[u] && (a += "; " + u, !0 !== i[u] && (a += "=" + i[u].split(";")[0]));
                        return document.cookie = t + "=" + r.write(o, t) + a
                    }
                }
                return Object.create({
                    set: o,
                    get: function(e) {
                        if ("undefined" != typeof document && (!arguments.length || e)) {
                            for (var t = document.cookie ? document.cookie.split("; ") : [], n = {}, o = 0; o < t.length; o++) {
                                var i = t[o].split("="),
                                    a = i.slice(1).join("=");
                                try {
                                    var u = decodeURIComponent(i[0]);
                                    if (n[u] = r.read(a, u), e === u) break
                                } catch (e) {}
                            }
                            return e ? n[e] : n
                        }
                    },
                    remove: function(t, r) {
                        o(t, "", e({}, r, {
                            expires: -1
                        }))
                    },
                    withAttributes: function(r) {
                        return t(this.converter, e({}, this.attributes, r))
                    },
                    withConverter: function(r) {
                        return t(e({}, this.converter, r), this.attributes)
                    }
                }, {
                    attributes: {
                        value: Object.freeze(n)
                    },
                    converter: {
                        value: Object.freeze(r)
                    }
                })
            }({
                read: function(e) {
                    return '"' === e[0] && (e = e.slice(1, -1)), e.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent)
                },
                write: function(e) {
                    return encodeURIComponent(e).replace(/%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g, decodeURIComponent)
                }
            }, {
                path: "/"
            })
        }()
    }),
    DO = t(function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.PROMISE_RESOLVED_VOID = t.PROMISE_RESOLVED_TRUE = t.PROMISE_RESOLVED_FALSE = void 0, t.isPromise = function(e) {
            return e && "function" == typeof e.then
        }, t.microSeconds = function() {
            var e = 1e3 * Date.now();
            return e <= r && (e = r + 1), r = e, e
        }, t.randomInt = function(e, t) {
            return Math.floor(Math.random() * (t - e + 1) + e)
        }, t.randomToken = function() {
            return Math.random().toString(36).substring(2)
        }, t.sleep = function(e, t) {
            return e || (e = 0), new Promise(function(r) {
                return setTimeout(function() {
                    return r(t)
                }, e)
            })
        }, t.supportsWebLockAPI = function() {
            return "undefined" != typeof navigator && void 0 !== navigator.locks && "function" == typeof navigator.locks.request
        }, t.PROMISE_RESOLVED_FALSE = Promise.resolve(!1), t.PROMISE_RESOLVED_TRUE = Promise.resolve(!0), t.PROMISE_RESOLVED_VOID = Promise.resolve();
        var r = 0
    });
t(function(e) {
    function t(r) {
        return e.exports = t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        }, e.exports.__esModule = !0, e.exports.default = e.exports, t(r)
    }
    e.exports = t, e.exports.__esModule = !0, e.exports.default = e.exports
});
var xO = t(function(e, t) {
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.NativeMethod = void 0, t.averageResponseTime = c, t.canBeUsed = s, t.close = i, t.create = o, t.microSeconds = void 0, t.onMessage = u, t.postMessage = a, t.type = void 0;
    var r = t.microSeconds = DO.microSeconds,
        n = t.type = "native";

    function o(e) {
        var t = {
            time: (0, DO.microSeconds)(),
            messagesCallback: null,
            bc: new BroadcastChannel(e),
            subFns: []
        };
        return t.bc.onmessage = function(e) {
            t.messagesCallback && t.messagesCallback(e.data)
        }, t
    }

    function i(e) {
        e.bc.close(), e.subFns = []
    }

    function a(e, t) {
        try {
            return e.bc.postMessage(t, !1), DO.PROMISE_RESOLVED_VOID
        } catch (e) {
            return Promise.reject(e)
        }
    }

    function u(e, t) {
        e.messagesCallback = t
    }

    function s() {
        if ("undefined" != typeof globalThis && globalThis.Deno && globalThis.Deno.args) return !0;
        if ("undefined" == typeof window && "undefined" == typeof self || "function" != typeof BroadcastChannel) return !1;
        if (BroadcastChannel._pubkey) throw new Error("BroadcastChannel: Do not overwrite window.BroadcastChannel with this module, this is not a polyfill");
        return !0
    }

    function c() {
        return 150
    }
    t.NativeMethod = {
        create: o,
        close: i,
        onMessage: u,
        postMessage: a,
        canBeUsed: s,
        type: n,
        averageResponseTime: c,
        microSeconds: r
    }
});

function CO(e) {
    const t = kO() - e.ttl,
        r = e.map[Symbol.iterator]();
    for (;;) {
        const n = r.next().value;
        if (!n) break;
        const o = n[0];
        if (!(n[1] < t)) break;
        e.map.delete(o)
    }
}

function kO() {
    return Date.now()
}
var LO = Object.freeze({
        __proto__: null,
        ObliviousSet: class {
            ttl;
            map = new Map;
            _to = !1;
            constructor(e) {
                this.ttl = e
            }
            has(e) {
                const t = this.map.get(e);
                return !(void 0 === t || t < kO() - this.ttl && (this.map.delete(e), 1))
            }
            add(e) {
                this.map.delete(e), this.map.set(e, kO()), this._to || (this._to = !0, setTimeout(() => {
                    this._to = !1, CO(this)
                }, 0))
            }
            clear() {
                this.map.clear()
            }
        },
        removeTooOldValues: CO,
        now: kO
    }),
    jO = t(function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.fillOptionsWithDefaults = function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                t = JSON.parse(JSON.stringify(e));
            return void 0 === t.webWorkerSupport && (t.webWorkerSupport = !0), t.idb || (t.idb = {}), t.idb.ttl || (t.idb.ttl = 45e3), t.idb.fallbackInterval || (t.idb.fallbackInterval = 150), e.idb && "function" == typeof e.idb.onclose && (t.idb.onclose = e.idb.onclose), t.localstorage || (t.localstorage = {}), t.localstorage.removeTimeout || (t.localstorage.removeTimeout = 6e4), e.methods && (t.methods = e.methods), t.node || (t.node = {}), t.node.ttl || (t.node.ttl = 12e4), t.node.maxParallelWrites || (t.node.maxParallelWrites = 2048), void 0 === t.node.useFastPath && (t.node.useFastPath = !0), t
        }
    }),
    XO = r(LO),
    UO = t(function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.TRANSACTION_SETTINGS = t.IndexedDBMethod = void 0, t.averageResponseTime = _, t.canBeUsed = E, t.cleanOldMessages = p, t.close = b, t.commitIndexedDBTransaction = s, t.create = v, t.createDatabase = c, t.getAllMessages = function(e) {
            var t = e.transaction(o, "readonly", i),
                r = t.objectStore(o),
                n = [];
            return new Promise(function(e) {
                r.openCursor().onsuccess = function(r) {
                    var o = r.target.result;
                    o ? (n.push(o.value), o.continue()) : (s(t), e(n))
                }
            })
        }, t.getIdb = u, t.getMessagesHigherThan = l, t.getOldMessages = h, t.microSeconds = void 0, t.onMessage = w, t.postMessage = m, t.removeMessagesById = d, t.type = void 0, t.writeMessage = f;
        var r = t.microSeconds = DO.microSeconds,
            n = "pubkey.broadcast-channel-0-",
            o = "messages",
            i = t.TRANSACTION_SETTINGS = {
                durability: "relaxed"
            },
            a = t.type = "idb";

        function u() {
            if ("undefined" != typeof indexedDB) return indexedDB;
            if ("undefined" != typeof window) {
                if (void 0 !== window.mozIndexedDB) return window.mozIndexedDB;
                if (void 0 !== window.webkitIndexedDB) return window.webkitIndexedDB;
                if (void 0 !== window.msIndexedDB) return window.msIndexedDB
            }
            return !1
        }

        function s(e) {
            e.commit && e.commit()
        }

        function c(e) {
            var t = u(),
                r = n + e,
                i = t.open(r);
            return i.onupgradeneeded = function(e) {
                e.target.result.createObjectStore(o, {
                    keyPath: "id",
                    autoIncrement: !0
                })
            }, new Promise(function(e, t) {
                i.onerror = function(e) {
                    return t(e)
                }, i.onsuccess = function() {
                    e(i.result)
                }
            })
        }

        function f(e, t, r) {
            var n = {
                    uuid: t,
                    time: Date.now(),
                    data: r
                },
                a = e.transaction([o], "readwrite", i);
            return new Promise(function(e, t) {
                a.oncomplete = function() {
                    return e()
                }, a.onerror = function(e) {
                    return t(e)
                }, a.objectStore(o).add(n), s(a)
            })
        }

        function l(e, t) {
            var r = e.transaction(o, "readonly", i),
                n = r.objectStore(o),
                a = [],
                u = IDBKeyRange.bound(t + 1, 1 / 0);
            if (n.getAll) {
                var c = n.getAll(u);
                return new Promise(function(e, t) {
                    c.onerror = function(e) {
                        return t(e)
                    }, c.onsuccess = function(t) {
                        e(t.target.result)
                    }
                })
            }
            return new Promise(function(e, o) {
                var i = function() {
                    try {
                        return u = IDBKeyRange.bound(t + 1, 1 / 0), n.openCursor(u)
                    } catch (e) {
                        return n.openCursor()
                    }
                }();
                i.onerror = function(e) {
                    return o(e)
                }, i.onsuccess = function(n) {
                    var o = n.target.result;
                    o ? o.value.id < t + 1 ? o.continue(t + 1) : (a.push(o.value), o.continue()) : (s(r), e(a))
                }
            })
        }

        function d(e, t) {
            if (e.closed) return Promise.resolve([]);
            var r = e.db.transaction(o, "readwrite", i).objectStore(o);
            return Promise.all(t.map(function(e) {
                var t = r.delete(e);
                return new Promise(function(e) {
                    t.onsuccess = function() {
                        return e()
                    }
                })
            }))
        }

        function h(e, t) {
            var r = Date.now() - t,
                n = e.transaction(o, "readonly", i),
                a = n.objectStore(o),
                u = [];
            return new Promise(function(e) {
                a.openCursor().onsuccess = function(t) {
                    var o = t.target.result;
                    if (o) {
                        var i = o.value;
                        i.time < r ? (u.push(i), o.continue()) : (s(n), e(u))
                    } else e(u)
                }
            })
        }

        function p(e) {
            return h(e.db, e.options.idb.ttl).then(function(t) {
                return d(e, t.map(function(e) {
                    return e.id
                }))
            })
        }

        function v(e, t) {
            return t = (0, jO.fillOptionsWithDefaults)(t), c(e).then(function(r) {
                var n = {
                    closed: !1,
                    lastCursorId: 0,
                    channelName: e,
                    options: t,
                    uuid: (0, DO.randomToken)(),
                    eMIs: new XO.ObliviousSet(2 * t.idb.ttl),
                    writeBlockPromise: DO.PROMISE_RESOLVED_VOID,
                    messagesCallback: null,
                    readQueuePromises: [],
                    db: r
                };
                return r.onclose = function() {
                    n.closed = !0, t.idb.onclose && t.idb.onclose()
                }, y(n), n
            })
        }

        function y(e) {
            e.closed || g(e).then(function() {
                return (0, DO.sleep)(e.options.idb.fallbackInterval)
            }).then(function() {
                return y(e)
            })
        }

        function g(e) {
            return e.closed ? DO.PROMISE_RESOLVED_VOID : e.messagesCallback ? l(e.db, e.lastCursorId).then(function(t) {
                var r = t.filter(function(e) {
                    return !!e
                }).map(function(t) {
                    return t.id > e.lastCursorId && (e.lastCursorId = t.id), t
                }).filter(function(t) {
                    return function(e, t) {
                        return !(e.uuid === t.uuid || t.eMIs.has(e.id) || e.data.time < t.messagesCallbackTime)
                    }(t, e)
                }).sort(function(e, t) {
                    return e.time - t.time
                });
                return r.forEach(function(t) {
                    e.messagesCallback && (e.eMIs.add(t.id), e.messagesCallback(t.data))
                }), DO.PROMISE_RESOLVED_VOID
            }) : DO.PROMISE_RESOLVED_VOID
        }

        function b(e) {
            e.closed = !0, e.db.close()
        }

        function m(e, t) {
            return e.writeBlockPromise = e.writeBlockPromise.then(function() {
                return f(e.db, e.uuid, t)
            }).then(function() {
                0 === (0, DO.randomInt)(0, 10) && p(e)
            }), e.writeBlockPromise
        }

        function w(e, t, r) {
            e.messagesCallbackTime = r, e.messagesCallback = t, g(e)
        }

        function E() {
            return !!u()
        }

        function _(e) {
            return 2 * e.idb.fallbackInterval
        }
        t.IndexedDBMethod = {
            create: v,
            close: b,
            onMessage: w,
            postMessage: m,
            canBeUsed: E,
            type: a,
            averageResponseTime: _,
            microSeconds: r
        }
    }),
    BO = t(function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.LocalstorageMethod = void 0, t.addStorageEventListener = s, t.averageResponseTime = p, t.canBeUsed = h, t.close = l, t.create = f, t.getLocalStorage = i, t.microSeconds = void 0, t.onMessage = d, t.postMessage = u, t.removeStorageEventListener = c, t.storageKey = a, t.type = void 0;
        var r = t.microSeconds = DO.microSeconds,
            n = "pubkey.broadcastChannel-",
            o = t.type = "localstorage";

        function i() {
            var e;
            if ("undefined" == typeof window) return null;
            try {
                e = window.localStorage, e = window["ie8-eventlistener/storage"] || window.localStorage
            } catch (e) {}
            return e
        }

        function a(e) {
            return n + e
        }

        function u(e, t) {
            return new Promise(function(r) {
                (0, DO.sleep)().then(function() {
                    var n = a(e.channelName),
                        o = {
                            token: (0, DO.randomToken)(),
                            time: Date.now(),
                            data: t,
                            uuid: e.uuid
                        },
                        u = JSON.stringify(o);
                    i().setItem(n, u);
                    var s = document.createEvent("Event");
                    s.initEvent("storage", !0, !0), s.key = n, s.newValue = u, window.dispatchEvent(s), r()
                })
            })
        }

        function s(e, t) {
            var r = a(e),
                n = function(e) {
                    e.key === r && t(JSON.parse(e.newValue))
                };
            return window.addEventListener("storage", n), n
        }

        function c(e) {
            window.removeEventListener("storage", e)
        }

        function f(e, t) {
            if (t = (0, jO.fillOptionsWithDefaults)(t), !h()) throw new Error("BroadcastChannel: localstorage cannot be used");
            var r = (0, DO.randomToken)(),
                n = new XO.ObliviousSet(t.localstorage.removeTimeout),
                o = {
                    channelName: e,
                    uuid: r,
                    eMIs: n
                };
            return o.listener = s(e, function(e) {
                o.messagesCallback && e.uuid !== r && e.token && !n.has(e.token) && (e.data.time && e.data.time < o.messagesCallbackTime || (n.add(e.token), o.messagesCallback(e.data)))
            }), o
        }

        function l(e) {
            c(e.listener)
        }

        function d(e, t, r) {
            e.messagesCallbackTime = r, e.messagesCallback = t
        }

        function h() {
            var e = i();
            if (!e) return !1;
            try {
                var t = "__broadcastchannel_check";
                e.setItem(t, "works"), e.removeItem(t)
            } catch (e) {
                return !1
            }
            return !0
        }

        function p() {
            var e = navigator.userAgent.toLowerCase();
            return e.includes("safari") && !e.includes("chrome") ? 240 : 120
        }
        t.LocalstorageMethod = {
            create: f,
            close: l,
            onMessage: d,
            postMessage: u,
            canBeUsed: h,
            type: o,
            averageResponseTime: p,
            microSeconds: r
        }
    }),
    FO = t(function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.SimulateMethod = t.SIMULATE_DELAY_TIME = void 0, t.averageResponseTime = l, t.canBeUsed = f, t.close = a, t.create = i, t.microSeconds = void 0, t.onMessage = c, t.postMessage = s, t.type = void 0;
        var r = t.microSeconds = DO.microSeconds,
            n = t.type = "simulate",
            o = new Set;

        function i(e) {
            var t = {
                time: r(),
                name: e,
                messagesCallback: null
            };
            return o.add(t), t
        }

        function a(e) {
            o.delete(e)
        }
        var u = t.SIMULATE_DELAY_TIME = 5;

        function s(e, t) {
            return new Promise(function(r) {
                return setTimeout(function() {
                    Array.from(o).forEach(function(r) {
                        r.name === e.name && r !== e && r.messagesCallback && r.time < t.time && r.messagesCallback(t)
                    }), r()
                }, u)
            })
        }

        function c(e, t) {
            e.messagesCallback = t
        }

        function f() {
            return !0
        }

        function l() {
            return u
        }
        t.SimulateMethod = {
            create: i,
            close: a,
            onMessage: c,
            postMessage: s,
            canBeUsed: f,
            type: n,
            averageResponseTime: l,
            microSeconds: r
        }
    }),
    VO = t(function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.chooseMethod = function(e) {
            var t = [].concat(e.methods, r).filter(Boolean);
            if (e.type) {
                if ("simulate" === e.type) return FO.SimulateMethod;
                var n = t.find(function(t) {
                    return t.type === e.type
                });
                if (n) return n;
                throw new Error("method-type " + e.type + " not found")
            }
            e.webWorkerSupport || (t = t.filter(function(e) {
                return "idb" !== e.type
            }));
            var o = t.find(function(e) {
                return e.canBeUsed()
            });
            if (o) return o;
            throw new Error("No usable method found in " + JSON.stringify(r.map(function(e) {
                return e.type
            })))
        };
        var r = [xO.NativeMethod, UO.IndexedDBMethod, BO.LocalstorageMethod]
    }),
    zO = t(function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.OPEN_BROADCAST_CHANNELS = t.BroadcastChannel = void 0, t.clearNodeFolder = function(e) {
            e = (0, jO.fillOptionsWithDefaults)(e);
            var t = (0, VO.chooseMethod)(e);
            return "node" === t.type ? t.clearNodeFolder().then(function() {
                return !0
            }) : DO.PROMISE_RESOLVED_FALSE
        }, t.enforceOptions = function(e) {
            r = e
        };
        var r, n = t.OPEN_BROADCAST_CHANNELS = new Set,
            o = 0,
            i = t.BroadcastChannel = function(e, t) {
                this.id = o++, n.add(this), this.name = e, r && (t = r), this.options = (0, jO.fillOptionsWithDefaults)(t), this.method = (0, VO.chooseMethod)(this.options), this._iL = !1, this._onML = null, this._addEL = {
                        message: [],
                        internal: []
                    }, this._uMP = new Set, this._befC = [], this._prepP = null,
                    function(e) {
                        var t = e.method.create(e.name, e.options);
                        (0, DO.isPromise)(t) ? (e._prepP = t, t.then(function(t) {
                            e._state = t
                        })) : e._state = t
                    }(this)
            };

        function a(e, t, r) {
            var n = {
                time: e.method.microSeconds(),
                type: t,
                data: r
            };
            return (e._prepP ? e._prepP : DO.PROMISE_RESOLVED_VOID).then(function() {
                var t = e.method.postMessage(e._state, n);
                return e._uMP.add(t), t.catch().then(function() {
                    return e._uMP.delete(t)
                }), t
            })
        }

        function u(e) {
            return e._addEL.message.length > 0 || e._addEL.internal.length > 0
        }

        function s(e, t, r) {
            e._addEL[t].push(r),
                function(e) {
                    if (!e._iL && u(e)) {
                        var t = function(t) {
                                e._addEL[t.type].forEach(function(e) {
                                    t.time >= e.time && e.fn(t.data)
                                })
                            },
                            r = e.method.microSeconds();
                        e._prepP ? e._prepP.then(function() {
                            e._iL = !0, e.method.onMessage(e._state, t, r)
                        }) : (e._iL = !0, e.method.onMessage(e._state, t, r))
                    }
                }(e)
        }

        function c(e, t, r) {
            e._addEL[t] = e._addEL[t].filter(function(e) {
                    return e !== r
                }),
                function(e) {
                    if (e._iL && !u(e)) {
                        e._iL = !1;
                        var t = e.method.microSeconds();
                        e.method.onMessage(e._state, null, t)
                    }
                }(e)
        }
        i._pubkey = !0, i.prototype = {
            postMessage: function(e) {
                if (this.closed) throw new Error("BroadcastChannel.postMessage(): Cannot post message after channel has closed " + JSON.stringify(e));
                return a(this, "message", e)
            },
            postInternal: function(e) {
                return a(this, "internal", e)
            },
            set onmessage(e) {
                var t = {
                    time: this.method.microSeconds(),
                    fn: e
                };
                c(this, "message", this._onML), e && "function" == typeof e ? (this._onML = t, s(this, "message", t)) : this._onML = null
            },
            addEventListener: function(e, t) {
                s(this, e, {
                    time: this.method.microSeconds(),
                    fn: t
                })
            },
            removeEventListener: function(e, t) {
                c(this, e, this._addEL[e].find(function(e) {
                    return e.fn === t
                }))
            },
            close: function() {
                var e = this;
                if (!this.closed) {
                    n.delete(this), this.closed = !0;
                    var t = this._prepP ? this._prepP : DO.PROMISE_RESOLVED_VOID;
                    return this._onML = null, this._addEL.message = [], t.then(function() {
                        return Promise.all(Array.from(e._uMP))
                    }).then(function() {
                        return Promise.all(e._befC.map(function(e) {
                            return e()
                        }))
                    }).then(function() {
                        return e.method.close(e._state)
                    })
                }
            },
            get type() {
                return this.method.type
            },
            get isClosed() {
                return this.closed
            }
        }
    }),
    HO = "[object process]" === Object.prototype.toString.call("undefined" != typeof process ? process : 0) ? function(e) {
        process.on("exit", function() {
            return e()
        }), process.on("beforeExit", function() {
            return e().then(function() {
                return process.exit()
            })
        }), process.on("SIGINT", function() {
            return e().then(function() {
                return process.exit()
            })
        }), process.on("uncaughtException", function(t) {
            return e().then(function() {
                process.exit(101)
            })
        })
    } : function(e) {
        if ("function" == typeof WorkerGlobalScope && self instanceof WorkerGlobalScope) {
            var t = self.close.bind(self);
            self.close = function() {
                return e(), t()
            }
        } else {
            if ("function" != typeof window.addEventListener) return;
            window.addEventListener("beforeunload", function() {
                e()
            }, !0), window.addEventListener("unload", function() {
                e()
            }, !0)
        }
    },
    WO = new Set,
    YO = !1;

function GO() {
    var e = [];
    return WO.forEach(function(t) {
        e.push(t()), WO.delete(t)
    }), Promise.all(e)
}
var KO, qO = Object.freeze({
        __proto__: null,
        add: function(e) {
            if (YO || (YO = !0, HO(GO)), "function" != typeof e) throw new Error("Listener is no function");
            return WO.add(e), {
                remove: function() {
                    return WO.delete(e)
                },
                run: function() {
                    return WO.delete(e), e()
                }
            }
        },
        runAll: GO,
        removeAll: function() {
            WO.clear()
        },
        getSize: function() {
            return WO.size
        }
    }),
    $O = r(qO),
    QO = t(function(e, t) {
        function r(e, t) {
            var r = {
                context: "leader",
                action: t,
                token: e.token
            };
            return e.broadcastChannel.postInternal(r)
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.beLeader = function(e) {
            e.isLeader = !0, e._hasLeader = !0;
            var t = (0, $O.add)(function() {
                return e.die()
            });
            e._unl.push(t);
            var n = function(t) {
                "leader" === t.context && "apply" === t.action && r(e, "tell"), "leader" !== t.context || "tell" !== t.action || e._dpLC || (e._dpLC = !0, e._dpL(), r(e, "tell"))
            };
            return e.broadcastChannel.addEventListener("internal", n), e._lstns.push(n), r(e, "tell")
        }, t.sendLeaderMessage = r
    }),
    JO = t(function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.LeaderElectionWebLock = void 0;
        var r = t.LeaderElectionWebLock = function(e, t) {
                var r = this;
                this.broadcastChannel = e, e._befC.push(function() {
                    return r.die()
                }), this._options = t, this.isLeader = !1, this.isDead = !1, this.token = (0, DO.randomToken)(), this._lstns = [], this._unl = [], this._dpL = function() {}, this._dpLC = !1, this._wKMC = {}, this.lN = "pubkey-bc||" + e.method.type + "||" + e.name
            },
            n = "LeaderElectionWebLock.die() called";
        r.prototype = {
            hasLeader: function() {
                var e = this;
                return navigator.locks.query().then(function(t) {
                    var r = t.held ? t.held.filter(function(t) {
                        return t.name === e.lN
                    }) : [];
                    return !!(r && r.length > 0)
                })
            },
            awaitLeadership: function() {
                var e = this;
                if (!this._wLMP) {
                    this._wKMC.c = new AbortController;
                    var t = new Promise(function(t, r) {
                        e._wKMC.res = t, e._wKMC.rej = r
                    });
                    this._wLMP = new Promise(function(r, o) {
                        navigator.locks.request(e.lN, {
                            signal: e._wKMC.c.signal
                        }, function() {
                            return e._wKMC.c = void 0, (0, QO.beLeader)(e), r(), t
                        }).catch(function(t) {
                            t.message && t.message === n || (e._wKMC.rej && e._wKMC.rej(t), o(t))
                        })
                    })
                }
                return this._wLMP
            },
            set onduplicate(e) {},
            die: function() {
                var e = this;
                return this._lstns.forEach(function(t) {
                    return e.broadcastChannel.removeEventListener("internal", t)
                }), this._lstns = [], this._unl.forEach(function(e) {
                    return e.remove()
                }), this._unl = [], this.isLeader && (this.isLeader = !1), this.isDead = !0, this._wKMC.res && this._wKMC.res(), this._wKMC.c && this._wKMC.c.abort(new Error(n)), (0, QO.sendLeaderMessage)(this, "death")
            }
        }
    }),
    ZO = t(function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.createLeaderElection = function(e, t) {
            if (e._leaderElector) throw new Error("BroadcastChannel already has a leader-elector");
            t = function(e, t) {
                return e || (e = {}), (e = JSON.parse(JSON.stringify(e))).fallbackInterval || (e.fallbackInterval = 3e3), e.responseTime || (e.responseTime = t.method.averageResponseTime(t.options)), e
            }(t, e);
            var n = (0, DO.supportsWebLockAPI)() ? new JO.LeaderElectionWebLock(e, t) : new r(e, t);
            return e._befC.push(function() {
                return n.die()
            }), e._leaderElector = n, n
        };
        var r = function(e, t) {
            var r = this;
            this.broadcastChannel = e, this._options = t, this.isLeader = !1, this._hasLeader = !1, this.isDead = !1, this.token = (0, DO.randomToken)(), this._aplQ = DO.PROMISE_RESOLVED_VOID, this._aplQC = 0, this._unl = [], this._lstns = [], this._dpL = function() {}, this._dpLC = !1;
            var n = function(e) {
                "leader" === e.context && ("death" === e.action && (r._hasLeader = !1), "tell" === e.action && (r._hasLeader = !0))
            };
            this.broadcastChannel.addEventListener("internal", n), this._lstns.push(n)
        };
        r.prototype = {
            hasLeader: function() {
                return Promise.resolve(this._hasLeader)
            },
            applyOnce: function(e) {
                var t = this;
                return this.isLeader ? (0, DO.sleep)(0, !0) : this.isDead ? (0, DO.sleep)(0, !1) : this._aplQC > 1 ? this._aplQ : (this._aplQC = this._aplQC + 1, this._aplQ = this._aplQ.then(function() {
                    return function() {
                        if (t.isLeader) return DO.PROMISE_RESOLVED_TRUE;
                        var r, n = !1,
                            o = new Promise(function(e) {
                                r = function() {
                                    n = !0, e()
                                }
                            }),
                            i = function(e) {
                                "leader" === e.context && e.token != t.token && ("apply" === e.action && e.token > t.token && r(), "tell" === e.action && (r(), t._hasLeader = !0))
                            };
                        t.broadcastChannel.addEventListener("internal", i);
                        var a = e ? 4 * t._options.responseTime : t._options.responseTime;
                        return (0, QO.sendLeaderMessage)(t, "apply").then(function() {
                            return Promise.race([(0, DO.sleep)(a), o.then(function() {
                                return Promise.reject(new Error)
                            })])
                        }).then(function() {
                            return (0, QO.sendLeaderMessage)(t, "apply")
                        }).then(function() {
                            return Promise.race([(0, DO.sleep)(a), o.then(function() {
                                return Promise.reject(new Error)
                            })])
                        }).catch(function() {}).then(function() {
                            return t.broadcastChannel.removeEventListener("internal", i), !n && (0, QO.beLeader)(t).then(function() {
                                return !0
                            })
                        })
                    }()
                }).then(function() {
                    t._aplQC = t._aplQC - 1
                }), this._aplQ.then(function() {
                    return t.isLeader
                }))
            },
            awaitLeadership: function() {
                return this._aLP || (this._aLP = function(e) {
                    return e.isLeader ? DO.PROMISE_RESOLVED_VOID : new Promise(function(t) {
                        var r = !1;

                        function n() {
                            r || (r = !0, e.broadcastChannel.removeEventListener("internal", i), t(!0))
                        }
                        e.applyOnce().then(function() {
                            e.isLeader && n()
                        });
                        var o = function() {
                            return (0, DO.sleep)(e._options.fallbackInterval).then(function() {
                                if (!e.isDead && !r) return e.isLeader ? void n() : e.applyOnce(!0).then(function() {
                                    e.isLeader ? n() : o()
                                })
                            })
                        };
                        o();
                        var i = function(t) {
                            "leader" === t.context && "death" === t.action && (e._hasLeader = !1, e.applyOnce().then(function() {
                                e.isLeader && n()
                            }))
                        };
                        e.broadcastChannel.addEventListener("internal", i), e._lstns.push(i)
                    })
                }(this)), this._aLP
            },
            set onduplicate(e) {
                this._dpL = e
            },
            die: function() {
                var e = this;
                return this._lstns.forEach(function(t) {
                    return e.broadcastChannel.removeEventListener("internal", t)
                }), this._lstns = [], this._unl.forEach(function(e) {
                    return e.remove()
                }), this._unl = [], this.isLeader && (this._hasLeader = !1, this.isLeader = !1), this.isDead = !0, (0, QO.sendLeaderMessage)(this, "death")
            }
        }
    }),
    eR = t(function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), Object.defineProperty(t, "BroadcastChannel", {
            enumerable: !0,
            get: function() {
                return zO.BroadcastChannel
            }
        }), Object.defineProperty(t, "OPEN_BROADCAST_CHANNELS", {
            enumerable: !0,
            get: function() {
                return zO.OPEN_BROADCAST_CHANNELS
            }
        }), Object.defineProperty(t, "beLeader", {
            enumerable: !0,
            get: function() {
                return QO.beLeader
            }
        }), Object.defineProperty(t, "clearNodeFolder", {
            enumerable: !0,
            get: function() {
                return zO.clearNodeFolder
            }
        }), Object.defineProperty(t, "createLeaderElection", {
            enumerable: !0,
            get: function() {
                return ZO.createLeaderElection
            }
        }), Object.defineProperty(t, "enforceOptions", {
            enumerable: !0,
            get: function() {
                return zO.enforceOptions
            }
        })
    }),
    tR = {
        BroadcastChannel: eR.BroadcastChannel,
        createLeaderElection: eR.createLeaderElection,
        clearNodeFolder: eR.clearNodeFolder,
        enforceOptions: eR.enforceOptions,
        beLeader: eR.beLeader
    },
    rR = 0,
    nR = 0,
    oR = {},
    iR = {};

function aR(e, t, r) {
    return "_root" == t ? r : e !== r ? function(e) {
        return KO || (KO = e.matches ? e.matches : e.webkitMatchesSelector ? e.webkitMatchesSelector : e.mozMatchesSelector ? e.mozMatchesSelector : e.msMatchesSelector ? e.msMatchesSelector : e.oMatchesSelector ? e.oMatchesSelector : fR.matchesSelector)
    }(e).call(e, t) ? e : e.parentNode ? (rR++, aR(e.parentNode, t, r)) : void 0 : void 0
}

function uR(e, t, r, n) {
    oR[e.id] || (oR[e.id] = {}), oR[e.id][t] || (oR[e.id][t] = {}), oR[e.id][t][r] || (oR[e.id][t][r] = []), oR[e.id][t][r].push(n)
}

function sR(e, t, r, n) {
    if (oR[e.id])
        if (t)
            if (n || r)
                if (n) {
                    if (oR[e.id][t][r])
                        for (var o = 0; o < oR[e.id][t][r].length; o++)
                            if (oR[e.id][t][r][o] === n) {
                                oR[e.id][t][r].splice(o, 1);
                                break
                            }
                } else delete oR[e.id][t][r];
    else oR[e.id][t] = {};
    else
        for (var i in oR[e.id]) oR[e.id].hasOwnProperty(i) && (oR[e.id][i] = {})
}

function cR(e, t, r, n) {
    if (this.element) {
        e instanceof Array || (e = [e]), r || "function" != typeof t || (r = t, t = "_root");
        var o, i = this.id;
        for (o = 0; o < e.length; o++) n ? sR(this, e[o], t, r) : (oR[i] && oR[i][e[o]] || fR.addEvent(this, e[o], a(e[o])), uR(this, e[o], t, r));
        return this
    }

    function a(e) {
        return function(t) {
            ! function(e, t, r) {
                if (oR[e][r]) {
                    var n, o, i = t.target || t.srcElement,
                        a = {},
                        u = 0,
                        s = 0;
                    for (n in rR = 0, oR[e][r]) oR[e][r].hasOwnProperty(n) && (o = aR(i, n, iR[e].element)) && fR.matchesEvent(r, iR[e].element, o, "_root" == n, t) && (rR++, oR[e][r][n].match = o, a[rR] = oR[e][r][n]);
                    for (t.stopPropagation = function() {
                            t.cancelBubble = !0
                        }, u = 0; u <= rR; u++)
                        if (a[u])
                            for (s = 0; s < a[u].length; s++) {
                                if (!1 === a[u][s].call(a[u].match, t)) return void fR.cancel(t);
                                if (t.cancelBubble) return
                            }
                }
            }(i, t, e)
        }
    }
}

function fR(e, t) {
    if (!(this instanceof fR)) {
        for (var r in iR)
            if (iR[r].element === e) return iR[r];
        return nR++, iR[nR] = new fR(e, nR), iR[nR]
    }
    this.element = e, this.id = t
}
fR.prototype.on = function(e, t, r) {
    return cR.call(this, e, t, r)
}, fR.prototype.off = function(e, t, r) {
    return cR.call(this, e, t, r, !0)
}, fR.matchesSelector = function() {}, fR.cancel = function(e) {
    e.preventDefault(), e.stopPropagation()
}, fR.addEvent = function(e, t, r) {
    var n = "blur" == t || "focus" == t,
        o = G_.passiveEvents ? {
            capture: n,
            passive: !1
        } : n;
    e.element.addEventListener(t, r, o)
}, fR.matchesEvent = function() {
    return !0
};
const lR = fR.addEvent,
    dR = void 0 === window.PointerEvent && void 0 !== window.MSPointerEvent,
    hR = {
        pointerdown: "MSPointerDown",
        pointerup: "MSPointerUp",
        pointercancel: "MSPointerCancel",
        pointermove: "MSPointerMove",
        pointerenter: "MSPointerEnter",
        pointerleave: "MSPointerLeave",
        pointerover: "MSPointerOver",
        pointerout: "MSPointerOut"
    },
    pR = "onmspointerenter" in document,
    vR = "onmspointerleave" in document;

function yR(e, t) {
    return null == e || e != e ? t : e
}
fR.addEvent = function(e, t, r) {
    dR && hR[t] && (t = hR[t]), "transitionend" === t && (lR(e, "webkitTransitionEnd", r), lR(e, "otransitionend", r)), "mouseenter" === t && (t = "mouseover"), "mouseleave" === t && (t = "mouseout"), "MSPointerEnter" !== t || pR || (t = "MSPointerOver"), "MSPointerLeave" !== t || vR || (t = "MSPointerOut"), lR(e, t, r)
}, fR.matchesEvent = function(e, t, r, n, o) {
    return !("mouseenter" === e || "mouseleave" === e || !pR && "MSPointerEnter" === e || !vR && "MSPointerLeave" === e) || function(e, t, r, n) {
        return !n.relatedTarget || (!r || e === t) && t !== n.relatedTarget && !t.contains(n.relatedTarget)
    }(t, r, n, o)
};
var gR = self !== top,
    bR = function() {
        var e = document.createElement("video"),
            t = {
                request: ["requestFullscreen", "webkitRequestFullscreen", "webkitRequestFullScreen", "mozRequestFullScreen", "msRequestFullscreen"],
                exit: ["exitFullscreen", "webkitCancelFullScreen", "webkitExitFullscreen", "mozCancelFullScreen", "msExitFullscreen"],
                enabled: ["fullscreenEnabled", "webkitFullscreenEnabled", "mozFullScreenEnabled", "msFullscreenEnabled"],
                element: ["fullscreenElement", "webkitFullscreenElement", "webkitCurrentFullScreenElement", "mozFullScreenElement", "msFullscreenElement"],
                change: ["fullscreenchange", "webkitfullscreenchange", "mozfullscreenchange", "MSFullscreenChange"],
                error: ["fullscreenerror", "webkitfullscreenerror", "mozfullscreenerror", "MSFullscreenError"]
            },
            r = {};
        for (var n in t)
            for (var o = 0, i = t[n].length; o < i; o++)
                if (t[n][o] in e || t[n][o] in document || "on" + t[n][o].toLowerCase() in document) {
                    r[n] = t[n][o];
                    break
                }
        return r
    }(),
    mR = {
        ENTER: "enter",
        EXIT: "exit",
        CHANGE: "change",
        ERROR: "error"
    },
    wR = [],
    ER = {};

function _R() {
    var e = Array.prototype.slice.apply(arguments),
        t = e.shift();
    ER[t].forEach(function(t) {
        "function" == typeof t && t.apply(t, e)
    })
}

function TR(e) {
    return function(t, r) {
        -1 !== wR.indexOf(t) && e.call(this, t, r)
    }
}

function SR(e) {
    var t = null;
    if ("VIDEO" === e.tagName) t = e;
    else {
        var r = e.getElementsByTagName("video");
        r[0] && (t = r[0])
    }
    return t
}
Object.keys(mR).forEach(function(e) {
    wR.push(mR[e]), ER[mR[e]] = []
});
var AR = null,
    IR = function() {},
    OR = [];

function RR(e) {
    var t = SR(e);
    if (t && t.webkitEnterFullscreen) {
        try {
            t.readyState < t.HAVE_CURRENT_DATA ? t.addEventListener("loadeddata", function r() {
                t.removeEventListener("loadeddata", r, !1);
                try {
                    t.webkitEnterFullscreen()
                } catch (t) {
                    return MR("cannot_enter_fullscreen", e)
                }
            }, !1) : t.webkitEnterFullscreen(), AR = t
        } catch (t) {
            return MR("not_supported", e)
        }
        return !0
    }
    return MR(void 0 === bR.request ? "not_supported" : "not_enabled", e)
}
var NR = function(e) {
        var t = OR[OR.length - 1];
        t && (e !== t.element && e !== AR || !t.hasEntered) && ("VIDEO" === e.tagName && (AR = e), 1 === OR.length && DR.onenter(DR.element), t.enter.call(t.element, e || t.element), t.hasEntered = !0, _R(mR.ENTER, DR.element))
    },
    PR = function() {
        AR = null;
        var e = OR.pop();
        e && (e.exit.call(e.element), _R(mR.EXIT, e.element), DR.element || (OR.forEach(function(e) {
            e.exit.call(e.element), _R(mR.EXIT, e.element)
        }), OR = [], DR.onexit()))
    },
    MR = function(e, t) {
        if (OR.length > 0) {
            var r = OR.pop();
            t = t || r.element, r.error.call(t, e), DR.onerror(t, e), _R(mR.ERROR, t, e)
        }
    },
    DR = {
        request: function(e, t, r, n) {
            if (e = e || document.body, OR.push({
                    element: e,
                    enter: t || IR,
                    exit: r || IR,
                    error: n || IR
                }), void 0 === bR.request) return RR(e);
            if (gR && !1 === document[bR.enabled]) return RR(e);
            try {
                e[bR.request]()
            } catch (t) {
                MR("not_enabled", e)
            }
        },
        exit: function() {
            !document[bR.exit] && DR.element ? DR.element[bR.exit]() : document[bR.exit]()
        },
        toggle: function(e, t, r, n) {
            DR.element ? DR.exit() : DR.request(e, t, r, n)
        },
        videoEnabled: function(e) {
            if (DR.enabled) return !0;
            var t = SR(e = e || document.body);
            return !(!t || void 0 === t.webkitSupportsFullscreen) && (t.readyState < t.HAVE_METADATA ? "maybe" : t.webkitSupportsFullscreen)
        },
        on: TR(function(e, t) {
            ER[e].push(t)
        }),
        off: TR(function(e, t) {
            var r = ER[e].indexOf(t);
            r > -1 && ER[e].splice(r, 1)
        }),
        onenter: IR,
        onexit: IR,
        onchange: IR,
        onerror: IR
    };
try {
    Object.defineProperties(DR, {
        element: {
            enumerable: !0,
            get: function() {
                return AR && AR.webkitDisplayingFullscreen ? AR : document[bR.element] || null
            }
        },
        enabled: {
            enumerable: !0,
            get: function() {
                return document[bR.enabled] || !1
            }
        }
    })
} catch (e) {
    DR.element = null, DR.enabled = !1
}
bR.change && document.addEventListener(bR.change, function(e) {
    if (DR.onchange(DR.element), _R(mR.CHANGE, DR.element), DR.element) {
        var t = OR[OR.length - 2];
        t && t.element === DR.element ? PR() : NR(DR.element)
    } else PR()
}, !1), document.addEventListener("webkitbeginfullscreen", function(e) {
    var t = !0;
    if (OR.length > 0)
        for (var r = 0, n = OR.length; r < n; r++)
            if (SR(OR[r].element) === e.srcElement) {
                t = !1;
                break
            }
    t && OR.push({
        element: e.srcElement,
        enter: IR,
        exit: IR,
        error: IR
    }), DR.onchange(e.srcElement), _R(mR.CHANGE, DR.srcElement), NR(e.srcElement)
}, !0), document.addEventListener("webkitendfullscreen", function(e) {
    DR.onchange(e.srcElement), _R(mR.CHANGE, e.srcElement), PR(e.srcElement)
}, !0), bR.error && document.addEventListener(bR.error, function(e) {
    MR("not_allowed")
}, !1);
var xR = Object.prototype.hasOwnProperty,
    CR = ZI(function(e, t) {
        if (IA(t) || MA(t)) rA(t, DA(t), e);
        else
            for (var r in t) xR.call(t, r) && tA(e, r, t[r])
    }),
    kR = t(function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.Tracker = void 0;
        var r = function() {
            function e() {}
            return e.getAttributeTypeMap = function() {
                return e.attributeTypeMap
            }, e.attributeTypeMap = [{
                name: "name",
                baseName: "name",
                type: "string"
            }, {
                name: "version",
                baseName: "version",
                type: "string"
            }], e
        }();
        t.Tracker = r
    });
let LR;
const jR = new Uint8Array(16);

function XR() {
    if (!LR && (LR = "undefined" != typeof crypto && crypto.getRandomValues && crypto.getRandomValues.bind(crypto), !LR)) throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
    return LR(jR)
}
var UR = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i;

function BR(e) {
    return "string" == typeof e && UR.test(e)
}
const FR = [];
for (let e = 0; e < 256; ++e) FR.push((e + 256).toString(16).slice(1));

function VR(e, t = 0) {
    return FR[e[t + 0]] + FR[e[t + 1]] + FR[e[t + 2]] + FR[e[t + 3]] + "-" + FR[e[t + 4]] + FR[e[t + 5]] + "-" + FR[e[t + 6]] + FR[e[t + 7]] + "-" + FR[e[t + 8]] + FR[e[t + 9]] + "-" + FR[e[t + 10]] + FR[e[t + 11]] + FR[e[t + 12]] + FR[e[t + 13]] + FR[e[t + 14]] + FR[e[t + 15]]
}
let zR, HR, WR = 0,
    YR = 0;

function GR(e) {
    if (!BR(e)) throw TypeError("Invalid UUID");
    let t;
    const r = new Uint8Array(16);
    return r[0] = (t = parseInt(e.slice(0, 8), 16)) >>> 24, r[1] = t >>> 16 & 255, r[2] = t >>> 8 & 255, r[3] = 255 & t, r[4] = (t = parseInt(e.slice(9, 13), 16)) >>> 8, r[5] = 255 & t, r[6] = (t = parseInt(e.slice(14, 18), 16)) >>> 8, r[7] = 255 & t, r[8] = (t = parseInt(e.slice(19, 23), 16)) >>> 8, r[9] = 255 & t, r[10] = (t = parseInt(e.slice(24, 36), 16)) / 1099511627776 & 255, r[11] = t / 4294967296 & 255, r[12] = t >>> 24 & 255, r[13] = t >>> 16 & 255, r[14] = t >>> 8 & 255, r[15] = 255 & t, r
}

function KR(e, t, r) {
    function n(e, n, o, i) {
        var a;
        if ("string" == typeof e && (e = function(e) {
                e = unescape(encodeURIComponent(e));
                const t = [];
                for (let r = 0; r < e.length; ++r) t.push(e.charCodeAt(r));
                return t
            }(e)), "string" == typeof n && (n = GR(n)), 16 !== (null === (a = n) || void 0 === a ? void 0 : a.length)) throw TypeError("Namespace must be array-like (16 iterable integer values, 0-255)");
        let u = new Uint8Array(16 + e.length);
        if (u.set(n), u.set(e, n.length), u = r(u), u[6] = 15 & u[6] | t, u[8] = 63 & u[8] | 128, o) {
            i = i || 0;
            for (let e = 0; e < 16; ++e) o[i + e] = u[e];
            return o
        }
        return VR(u)
    }
    try {
        n.name = e
    } catch (e) {}
    return n.DNS = "6ba7b810-9dad-11d1-80b4-00c04fd430c8", n.URL = "6ba7b811-9dad-11d1-80b4-00c04fd430c8", n
}

function qR(e) {
    return 14 + (e + 64 >>> 9 << 4) + 1
}

function $R(e, t) {
    const r = (65535 & e) + (65535 & t);
    return (e >> 16) + (t >> 16) + (r >> 16) << 16 | 65535 & r
}

function QR(e, t, r, n, o, i) {
    return $R(function(e, t) {
        return e << t | e >>> 32 - t
    }($R($R(t, e), $R(n, i)), o), r)
}

function JR(e, t, r, n, o, i, a) {
    return QR(t & r | ~t & n, e, t, o, i, a)
}

function ZR(e, t, r, n, o, i, a) {
    return QR(t & n | r & ~n, e, t, o, i, a)
}

function eN(e, t, r, n, o, i, a) {
    return QR(t ^ r ^ n, e, t, o, i, a)
}

function tN(e, t, r, n, o, i, a) {
    return QR(r ^ (t | ~n), e, t, o, i, a)
}
const rN = KR("v3", 48, function(e) {
    if ("string" == typeof e) {
        const t = unescape(encodeURIComponent(e));
        e = new Uint8Array(t.length);
        for (let r = 0; r < t.length; ++r) e[r] = t.charCodeAt(r)
    }
    return function(e) {
        const t = [],
            r = 32 * e.length,
            n = "0123456789abcdef";
        for (let o = 0; o < r; o += 8) {
            const r = e[o >> 5] >>> o % 32 & 255,
                i = parseInt(n.charAt(r >>> 4 & 15) + n.charAt(15 & r), 16);
            t.push(i)
        }
        return t
    }(function(e, t) {
        e[t >> 5] |= 128 << t % 32, e[qR(t) - 1] = t;
        let r = 1732584193,
            n = -271733879,
            o = -1732584194,
            i = 271733878;
        for (let t = 0; t < e.length; t += 16) {
            const a = r,
                u = n,
                s = o,
                c = i;
            r = JR(r, n, o, i, e[t], 7, -680876936), i = JR(i, r, n, o, e[t + 1], 12, -389564586), o = JR(o, i, r, n, e[t + 2], 17, 606105819), n = JR(n, o, i, r, e[t + 3], 22, -1044525330), r = JR(r, n, o, i, e[t + 4], 7, -176418897), i = JR(i, r, n, o, e[t + 5], 12, 1200080426), o = JR(o, i, r, n, e[t + 6], 17, -1473231341), n = JR(n, o, i, r, e[t + 7], 22, -45705983), r = JR(r, n, o, i, e[t + 8], 7, 1770035416), i = JR(i, r, n, o, e[t + 9], 12, -1958414417), o = JR(o, i, r, n, e[t + 10], 17, -42063), n = JR(n, o, i, r, e[t + 11], 22, -1990404162), r = JR(r, n, o, i, e[t + 12], 7, 1804603682), i = JR(i, r, n, o, e[t + 13], 12, -40341101), o = JR(o, i, r, n, e[t + 14], 17, -1502002290), n = JR(n, o, i, r, e[t + 15], 22, 1236535329), r = ZR(r, n, o, i, e[t + 1], 5, -165796510), i = ZR(i, r, n, o, e[t + 6], 9, -1069501632), o = ZR(o, i, r, n, e[t + 11], 14, 643717713), n = ZR(n, o, i, r, e[t], 20, -373897302), r = ZR(r, n, o, i, e[t + 5], 5, -701558691), i = ZR(i, r, n, o, e[t + 10], 9, 38016083), o = ZR(o, i, r, n, e[t + 15], 14, -660478335), n = ZR(n, o, i, r, e[t + 4], 20, -405537848), r = ZR(r, n, o, i, e[t + 9], 5, 568446438), i = ZR(i, r, n, o, e[t + 14], 9, -1019803690), o = ZR(o, i, r, n, e[t + 3], 14, -187363961), n = ZR(n, o, i, r, e[t + 8], 20, 1163531501), r = ZR(r, n, o, i, e[t + 13], 5, -1444681467), i = ZR(i, r, n, o, e[t + 2], 9, -51403784), o = ZR(o, i, r, n, e[t + 7], 14, 1735328473), n = ZR(n, o, i, r, e[t + 12], 20, -1926607734), r = eN(r, n, o, i, e[t + 5], 4, -378558), i = eN(i, r, n, o, e[t + 8], 11, -2022574463), o = eN(o, i, r, n, e[t + 11], 16, 1839030562), n = eN(n, o, i, r, e[t + 14], 23, -35309556), r = eN(r, n, o, i, e[t + 1], 4, -1530992060), i = eN(i, r, n, o, e[t + 4], 11, 1272893353), o = eN(o, i, r, n, e[t + 7], 16, -155497632), n = eN(n, o, i, r, e[t + 10], 23, -1094730640), r = eN(r, n, o, i, e[t + 13], 4, 681279174), i = eN(i, r, n, o, e[t], 11, -358537222), o = eN(o, i, r, n, e[t + 3], 16, -722521979), n = eN(n, o, i, r, e[t + 6], 23, 76029189), r = eN(r, n, o, i, e[t + 9], 4, -640364487), i = eN(i, r, n, o, e[t + 12], 11, -421815835), o = eN(o, i, r, n, e[t + 15], 16, 530742520), n = eN(n, o, i, r, e[t + 2], 23, -995338651), r = tN(r, n, o, i, e[t], 6, -198630844), i = tN(i, r, n, o, e[t + 7], 10, 1126891415), o = tN(o, i, r, n, e[t + 14], 15, -1416354905), n = tN(n, o, i, r, e[t + 5], 21, -57434055), r = tN(r, n, o, i, e[t + 12], 6, 1700485571), i = tN(i, r, n, o, e[t + 3], 10, -1894986606), o = tN(o, i, r, n, e[t + 10], 15, -1051523), n = tN(n, o, i, r, e[t + 1], 21, -2054922799), r = tN(r, n, o, i, e[t + 8], 6, 1873313359), i = tN(i, r, n, o, e[t + 15], 10, -30611744), o = tN(o, i, r, n, e[t + 6], 15, -1560198380), n = tN(n, o, i, r, e[t + 13], 21, 1309151649), r = tN(r, n, o, i, e[t + 4], 6, -145523070), i = tN(i, r, n, o, e[t + 11], 10, -1120210379), o = tN(o, i, r, n, e[t + 2], 15, 718787259), n = tN(n, o, i, r, e[t + 9], 21, -343485551), r = $R(r, a), n = $R(n, u), o = $R(o, s), i = $R(i, c)
        }
        return [r, n, o, i]
    }(function(e) {
        if (0 === e.length) return [];
        const t = 8 * e.length,
            r = new Uint32Array(qR(t));
        for (let n = 0; n < t; n += 8) r[n >> 5] |= (255 & e[n / 8]) << n % 32;
        return r
    }(e), 8 * e.length))
});
var nN = {
    randomUUID: "undefined" != typeof crypto && crypto.randomUUID && crypto.randomUUID.bind(crypto)
};

function oN(e, t, r, n) {
    switch (e) {
        case 0:
            return t & r ^ ~t & n;
        case 1:
        case 3:
            return t ^ r ^ n;
        case 2:
            return t & r ^ t & n ^ r & n
    }
}

function iN(e, t) {
    return e << t | e >>> 32 - t
}
const aN = KR("v5", 80, function(e) {
    const t = [1518500249, 1859775393, 2400959708, 3395469782],
        r = [1732584193, 4023233417, 2562383102, 271733878, 3285377520];
    if ("string" == typeof e) {
        const t = unescape(encodeURIComponent(e));
        e = [];
        for (let r = 0; r < t.length; ++r) e.push(t.charCodeAt(r))
    } else Array.isArray(e) || (e = Array.prototype.slice.call(e));
    e.push(128);
    const n = e.length / 4 + 2,
        o = Math.ceil(n / 16),
        i = new Array(o);
    for (let t = 0; t < o; ++t) {
        const r = new Uint32Array(16);
        for (let n = 0; n < 16; ++n) r[n] = e[64 * t + 4 * n] << 24 | e[64 * t + 4 * n + 1] << 16 | e[64 * t + 4 * n + 2] << 8 | e[64 * t + 4 * n + 3];
        i[t] = r
    }
    i[o - 1][14] = 8 * (e.length - 1) / Math.pow(2, 32), i[o - 1][14] = Math.floor(i[o - 1][14]), i[o - 1][15] = 8 * (e.length - 1) & 4294967295;
    for (let e = 0; e < o; ++e) {
        const n = new Uint32Array(80);
        for (let t = 0; t < 16; ++t) n[t] = i[e][t];
        for (let e = 16; e < 80; ++e) n[e] = iN(n[e - 3] ^ n[e - 8] ^ n[e - 14] ^ n[e - 16], 1);
        let o = r[0],
            a = r[1],
            u = r[2],
            s = r[3],
            c = r[4];
        for (let e = 0; e < 80; ++e) {
            const r = Math.floor(e / 20),
                i = iN(o, 5) + oN(r, a, u, s) + c + t[r] + n[e] >>> 0;
            c = s, s = u, u = iN(a, 30) >>> 0, a = o, o = i
        }
        r[0] = r[0] + o >>> 0, r[1] = r[1] + a >>> 0, r[2] = r[2] + u >>> 0, r[3] = r[3] + s >>> 0, r[4] = r[4] + c >>> 0
    }
    return [r[0] >> 24 & 255, r[0] >> 16 & 255, r[0] >> 8 & 255, 255 & r[0], r[1] >> 24 & 255, r[1] >> 16 & 255, r[1] >> 8 & 255, 255 & r[1], r[2] >> 24 & 255, r[2] >> 16 & 255, r[2] >> 8 & 255, 255 & r[2], r[3] >> 24 & 255, r[3] >> 16 & 255, r[3] >> 8 & 255, 255 & r[3], r[4] >> 24 & 255, r[4] >> 16 & 255, r[4] >> 8 & 255, 255 & r[4]]
});
var uN = Object.freeze({
        __proto__: null,
        v1: function(e, t, r) {
            let n = t && r || 0;
            const o = t || new Array(16);
            let i = (e = e || {}).node || zR,
                a = void 0 !== e.clockseq ? e.clockseq : HR;
            if (null == i || null == a) {
                const t = e.random || (e.rng || XR)();
                null == i && (i = zR = [1 | t[0], t[1], t[2], t[3], t[4], t[5]]), null == a && (a = HR = 16383 & (t[6] << 8 | t[7]))
            }
            let u = void 0 !== e.msecs ? e.msecs : Date.now(),
                s = void 0 !== e.nsecs ? e.nsecs : YR + 1;
            const c = u - WR + (s - YR) / 1e4;
            if (c < 0 && void 0 === e.clockseq && (a = a + 1 & 16383), (c < 0 || u > WR) && void 0 === e.nsecs && (s = 0), s >= 1e4) throw new Error("uuid.v1(): Can't create more than 10M uuids/sec");
            WR = u, YR = s, HR = a, u += 122192928e5;
            const f = (1e4 * (268435455 & u) + s) % 4294967296;
            o[n++] = f >>> 24 & 255, o[n++] = f >>> 16 & 255, o[n++] = f >>> 8 & 255, o[n++] = 255 & f;
            const l = u / 4294967296 * 1e4 & 268435455;
            o[n++] = l >>> 8 & 255, o[n++] = 255 & l, o[n++] = l >>> 24 & 15 | 16, o[n++] = l >>> 16 & 255, o[n++] = a >>> 8 | 128, o[n++] = 255 & a;
            for (let e = 0; e < 6; ++e) o[n + e] = i[e];
            return t || VR(o)
        },
        v3: rN,
        v4: function(e, t, r) {
            if (nN.randomUUID && !t && !e) return nN.randomUUID();
            const n = (e = e || {}).random || (e.rng || XR)();
            if (n[6] = 15 & n[6] | 64, n[8] = 63 & n[8] | 128, t) {
                r = r || 0;
                for (let e = 0; e < 16; ++e) t[r + e] = n[e];
                return t
            }
            return VR(n)
        },
        v5: aN,
        NIL: "00000000-0000-0000-0000-000000000000",
        version: function(e) {
            if (!BR(e)) throw TypeError("Invalid UUID");
            return parseInt(e.slice(14, 15), 16)
        },
        validate: BR,
        stringify: function(e, t = 0) {
            const r = VR(e, t);
            if (!BR(r)) throw TypeError("Stringified UUID is invalid");
            return r
        },
        parse: GR
    }),
    sN = r(uN),
    cN = t(function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.Envelope = void 0;
        var r = function() {
            function e(e, t) {
                this.event = e, this.eid = (0, sN.v4)(), this.ts_ms = Date.now(), this.created_at = Date.now(), this._tracker = new kR.Tracker, this._globalBPO = t
            }
            return Object.defineProperty(e.prototype, "tracker", {
                get: function() {
                    return this._tracker
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "global", {
                get: function() {
                    return this._globalBPO
                },
                enumerable: !1,
                configurable: !0
            }), e.getAttributeTypeMap = function() {
                return e.attributeTypeMap
            }, e.attributeTypeMap = [{
                name: "eid",
                baseName: "eid",
                type: "string"
            }, {
                name: "ts_ms",
                baseName: "ts_ms",
                type: "number"
            }, {
                name: "created_at",
                baseName: "created_at",
                type: "number"
            }, {
                name: "event",
                baseName: "event",
                type: "Event"
            }, {
                name: "global",
                baseName: "global",
                type: "Event"
            }, {
                name: "tracker",
                baseName: "tracker",
                type: "Tracker"
            }], e
        }();
        t.Envelope = r
    }),
    fN = t(function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.Event = void 0;
        var r = function() {
            function e(e, t, r) {
                this.name = e, this.ts_ms = Date.now(), this.version = t, this.fields = r
            }
            return e.getAttributeTypeMap = function() {
                return e.attributeTypeMap
            }, e.attributeTypeMap = [{
                name: "name",
                baseName: "name",
                type: "string"
            }, {
                name: "ts_ms",
                baseName: "ts_ms",
                type: "number"
            }, {
                name: "version",
                baseName: "version",
                type: "number"
            }, {
                name: "fields",
                baseName: "fields",
                type: "object"
            }], e
        }();
        t.Event = r
    }),
    lN = t(function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.EventContext = void 0;
        var r = function() {
            function e(e, t, r) {
                this.name = e, this.ts_ms = Date.now(), this.version = t, this.fields = r
            }
            return e.getAttributeTypeMap = function() {
                return e.attributeTypeMap
            }, e.attributeTypeMap = [{
                name: "name",
                baseName: "name",
                type: "string"
            }, {
                name: "ts_ms",
                baseName: "ts_ms",
                type: "number"
            }, {
                name: "version",
                baseName: "version",
                type: "number"
            }, {
                name: "fields",
                baseName: "fields",
                type: "object"
            }], e
        }();
        t.EventContext = r
    }),
    dN = t(function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.GlobalContext = void 0;
        t.GlobalContext = function(e, t, r) {
            this.name = e, this.ts_ms = Date.now(), this.version = t, this.fields = r
        }
    }),
    hN = t(function(t, r) {
        var n = e && e.__createBinding || (Object.create ? function(e, t, r, n) {
                void 0 === n && (n = r);
                var o = Object.getOwnPropertyDescriptor(t, r);
                o && !("get" in o ? !t.__esModule : o.writable || o.configurable) || (o = {
                    enumerable: !0,
                    get: function() {
                        return t[r]
                    }
                }), Object.defineProperty(e, n, o)
            } : function(e, t, r, n) {
                void 0 === n && (n = r), e[n] = t[r]
            }),
            o = e && e.__exportStar || function(e, t) {
                for (var r in e) "default" === r || Object.prototype.hasOwnProperty.call(t, r) || n(t, e, r)
            };
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.ObjectSerializer = void 0, o(cN, r), o(fN, r), o(lN, r), o(kR, r), o(dN, r);
        var i = fN,
            a = lN,
            u = kR,
            s = ["string", "boolean", "double", "integer", "long", "float", "number", "any"],
            c = {},
            f = {
                Envelope: cN.Envelope,
                Event: i.Event,
                Tracker: u.Tracker,
                EventContext: a.EventContext
            },
            l = function() {
                function e() {}
                return e.findCorrectType = function(e, t) {
                    if (null == e) return t;
                    if (-1 !== s.indexOf(t.toLowerCase())) return t;
                    if ("Date" === t) return t;
                    if (c[t]) return t;
                    if (!f[t]) return t;
                    var r = f[t].discriminator;
                    if (null == r) return t;
                    if (e[r]) {
                        var n = e[r];
                        return f[n] ? n : t
                    }
                    return t
                }, e.serialize = function(t, r) {
                    if (null == t) return t;
                    if (-1 !== s.indexOf(r.toLowerCase())) return t;
                    if (0 === r.lastIndexOf("Array<", 0)) {
                        var n = r.replace("Array<", "");
                        n = n.substring(0, n.length - 1);
                        var o = [];
                        for (var i in t) {
                            var a = t[i];
                            o.push(e.serialize(a, n))
                        }
                        return o
                    }
                    if ("Date" === r) return t.toISOString();
                    if (c[r]) return t;
                    if (!f[r]) return t;
                    r = this.findCorrectType(t, r);
                    var u = f[r].getAttributeTypeMap(),
                        l = {};
                    for (var i in u) {
                        var d = u[i];
                        l[d.baseName] = e.serialize(t[d.name], d.type)
                    }
                    return l
                }, e.deserialize = function(t, r) {
                    if (r = e.findCorrectType(t, r), null == t) return t;
                    if (-1 !== s.indexOf(r.toLowerCase())) return t;
                    if (0 === r.lastIndexOf("Array<", 0)) {
                        var n = r.replace("Array<", "");
                        n = n.substring(0, n.length - 1);
                        var o = [];
                        for (var i in t) {
                            var a = t[i];
                            o.push(e.deserialize(a, n))
                        }
                        return o
                    }
                    if ("Date" === r) return new Date(t);
                    if (c[r]) return t;
                    if (!f[r]) return t;
                    var u = new f[r],
                        l = f[r].getAttributeTypeMap();
                    for (var i in l) {
                        var d = l[i];
                        u[d.name] = e.deserialize(t[d.baseName], d.type)
                    }
                    return u
                }, e
            }();
        r.ObjectSerializer = l
    }),
    pN = t(function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.formatRequestEvent = t.parseJwt = t.getCookie = void 0, t.getCookie = function(e) {
            if ("undefined" == typeof document) return null;
            var t = document.cookie.match(new RegExp("(;\\s)?".concat(e, "=")));
            if (!t || 0 == t.length || void 0 === t.index) return null;
            var r = document.cookie.indexOf(";", t.index + 1),
                n = t.index + t[0].length,
                o = -1 === r ? document.cookie.substr(n) : document.cookie.substring(n, r);
            return decodeURIComponent(o)
        }, t.parseJwt = function(e) {
            var t = e.split(".")[1].replace(/-/g, "+").replace(/_/g, "/"),
                r = decodeURIComponent(atob(t).split("").map(function(e) {
                    return "%" + ("00" + e.charCodeAt(0).toString(16)).slice(-2)
                }).join(""));
            return JSON.parse(r)
        }, t.formatRequestEvent = function(e) {
            var t = e.split(".");
            if (t.length <= 2) return e;
            var r = t.pop();
            return "".concat(t.join("_"), ".").concat(r)
        }
    }),
    vN = t(function(t, r) {
        var n, o = e && e.__awaiter || function(e, t, r, n) {
                return new(r || (r = Promise))(function(o, i) {
                    function a(e) {
                        try {
                            s(n.next(e))
                        } catch (e) {
                            i(e)
                        }
                    }

                    function u(e) {
                        try {
                            s(n.throw(e))
                        } catch (e) {
                            i(e)
                        }
                    }

                    function s(e) {
                        e.done ? o(e.value) : function(e) {
                            return e instanceof r ? e : new r(function(t) {
                                t(e)
                            })
                        }(e.value).then(a, u)
                    }
                    s((n = n.apply(e, t || [])).next())
                })
            },
            i = e && e.__generator || function(e, t) {
                var r, n, o, i, a = {
                    label: 0,
                    sent: function() {
                        if (1 & o[0]) throw o[1];
                        return o[1]
                    },
                    trys: [],
                    ops: []
                };
                return i = {
                    next: u(0),
                    throw: u(1),
                    return: u(2)
                }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                    return this
                }), i;

                function u(u) {
                    return function(s) {
                        return function(u) {
                            if (r) throw new TypeError("Generator is already executing.");
                            for (; i && (i = 0, u[0] && (a = 0)), a;) try {
                                if (r = 1, n && (o = 2 & u[0] ? n.return : u[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, u[1])).done) return o;
                                switch (n = 0, o && (u = [2 & u[0], o.value]), u[0]) {
                                    case 0:
                                    case 1:
                                        o = u;
                                        break;
                                    case 4:
                                        return a.label++, {
                                            value: u[1],
                                            done: !1
                                        };
                                    case 5:
                                        a.label++, n = u[1], u = [0];
                                        continue;
                                    case 7:
                                        u = a.ops.pop(), a.trys.pop();
                                        continue;
                                    default:
                                        if (!((o = (o = a.trys).length > 0 && o[o.length - 1]) || 6 !== u[0] && 2 !== u[0])) {
                                            a = 0;
                                            continue
                                        }
                                        if (3 === u[0] && (!o || u[1] > o[0] && u[1] < o[3])) {
                                            a.label = u[1];
                                            break
                                        }
                                        if (6 === u[0] && a.label < o[1]) {
                                            a.label = o[1], o = u;
                                            break
                                        }
                                        if (o && a.label < o[2]) {
                                            a.label = o[2], a.ops.push(u);
                                            break
                                        }
                                        o[2] && a.ops.pop(), a.trys.pop();
                                        continue
                                }
                                u = t.call(e, a)
                            } catch (e) {
                                u = [6, e], n = 0
                            } finally {
                                r = o = 0
                            }
                            if (5 & u[0]) throw u[1];
                            return {
                                value: u[0] ? u[1] : void 0,
                                done: !0
                            }
                        }([u, s])
                    }
                }
            },
            a = e && e.__values || function(e) {
                var t = "function" == typeof Symbol && Symbol.iterator,
                    r = t && e[t],
                    n = 0;
                if (r) return r.call(e);
                if (e && "number" == typeof e.length) return {
                    next: function() {
                        return e && n >= e.length && (e = void 0), {
                            value: e && e[n++],
                            done: !e
                        }
                    }
                };
                throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
            },
            u = e && e.__read || function(e, t) {
                var r = "function" == typeof Symbol && e[Symbol.iterator];
                if (!r) return e;
                var n, o, i = r.call(e),
                    a = [];
                try {
                    for (;
                        (void 0 === t || t-- > 0) && !(n = i.next()).done;) a.push(n.value)
                } catch (e) {
                    o = {
                        error: e
                    }
                } finally {
                    try {
                        n && !n.done && (r = i.return) && r.call(i)
                    } finally {
                        if (o) throw o.error
                    }
                }
                return a
            };
        Object.defineProperty(r, "__esModule", {
                value: !0
            }), r.BigPictureClient = r.Configuration = r.Service = void 0,
            function(e) {
                e.FRESNEL_PROD = "https://fresnel-events.vimeocdn.com", e.FRESNEL_PROD_CN = "https://fresnel-events.videoji.cn", e.FRESNEL_DEV = "https://fresnel-event-staging.vimeows.com", e.EVENTS_PROD = "https://lensflare.vimeo.com"
            }(n = r.Service || (r.Service = {}));
        var s = function(e, t, r, n) {
            void 0 === t && (t = null), void 0 === r && (r = null), void 0 === n && (n = ""), this.service = e, this.globalBPO = t, this.contexts = r, this.endpoint = n
        };
        r.Configuration = s;
        var c = function() {
            function e() {}
            return Object.defineProperty(e, "isInitalized", {
                get: function() {
                    return Boolean(e.conf.globalBPO)
                },
                enumerable: !1,
                configurable: !0
            }), e.configure = function(t) {
                e.conf = t, e.WAIT_QUEUE.length > 0 && (e.WAIT_QUEUE.map(function(t) {
                    var r = t.event,
                        n = t.contexts;
                    n ? e.sendEventWithContexts(r, n) : e.sendEvent(r)
                }), e.WAIT_QUEUE = [])
            }, e.updateObject = function(t, r) {
                return o(this, void 0, void 0, function() {
                    var n, o, s, c, f, l, d;
                    return i(this, function(i) {
                        try {
                            for (n = a(Object.entries(t)), o = n.next(); !o.done; o = n.next())
                                if (s = u(o.value, 2), c = s[0], f = s[1], c in r) {
                                    if (f instanceof Object) return r[c] instanceof Object ? (e.updateObject(f, r[c]), [2]) : (r[c] = f, [2]);
                                    r[c] = f
                                }
                        } catch (e) {
                            l = {
                                error: e
                            }
                        } finally {
                            try {
                                o && !o.done && (d = n.return) && d.call(n)
                            } finally {
                                if (l) throw l.error
                            }
                        }
                        return [2]
                    })
                })
            }, e.updateContext = function(t) {
                return o(this, void 0, void 0, function() {
                    return i(this, function(r) {
                        return "global" == t.context && e.conf.globalBPO && e.updateObject(t.fields, e.conf.globalBPO.fields), [2]
                    })
                })
            }, e.sendEvent = function(t, r) {
                return o(this, void 0, void 0, function() {
                    var n, o, a, u, s, c;
                    return i(this, function(i) {
                        switch (i.label) {
                            case 0:
                                if (null == t) throw new Error("Required parameter event was null or undefined when calling sendEvent.");
                                return e.isInitalized ? (n = JSON.stringify(hN.ObjectSerializer.serialize([new cN.Envelope(t, this.conf.globalBPO)], "Array<Envelope>")), o = (0, pN.formatRequestEvent)(t.name), a = "" !== this.conf.endpoint ? this.conf.endpoint : this.conf.service, u = "".concat(a, "/add/").concat(encodeURIComponent(o)), navigator.sendBeacon && !r ? [3, 2] : (s = {
                                    method: "POST",
                                    headers: {
                                        "Content-Type": "application/json",
                                        "User-Agent": navigator.userAgent,
                                        Origin: location.origin,
                                        Referer: document.referrer
                                    },
                                    body: n
                                }, r && (s.headers.Authorization = r), [4, fetch(u, s)])) : (e.WAIT_QUEUE.push({
                                    event: t
                                }), e.waitAndFlushQueue(), [2]);
                            case 1:
                                return i.sent(), [3, 3];
                            case 2:
                                c = new Blob([n]), navigator.sendBeacon(u, c), i.label = 3;
                            case 3:
                                return [2]
                        }
                    })
                })
            }, e.sendEventWithContexts = function(t, r, n) {
                return o(this, void 0, void 0, function() {
                    var o, s, c, f, l, d, h, p, v, y, g, b, m, w, E, _;
                    return i(this, function(i) {
                        switch (i.label) {
                            case 0:
                                if (null == t) throw new Error("Required parameter event was null or undefined when calling sendEvent.");
                                if (!e.isInitalized) return e.WAIT_QUEUE.push({
                                    event: t,
                                    contexts: r
                                }), e.waitAndFlushQueue(), [2];
                                o = new cN.Envelope(t, this.conf.globalBPO), (s = hN.ObjectSerializer.serialize([o], "Array<Envelope>"))[0].contexts = {};
                                try {
                                    for (c = a(Object.entries(r)), f = c.next(); !f.done; f = c.next()) l = u(f.value, 2), d = l[0], h = l[1], p = hN.ObjectSerializer.serialize(h, "EventContext"), s[0].contexts[d] = p
                                } catch (e) {
                                    E = {
                                        error: e
                                    }
                                } finally {
                                    try {
                                        f && !f.done && (_ = c.return) && _.call(c)
                                    } finally {
                                        if (E) throw E.error
                                    }
                                }
                                return v = JSON.stringify(s), y = (0, pN.formatRequestEvent)(t.name), g = "" !== this.conf.endpoint ? this.conf.endpoint : this.conf.service, b = "".concat(g, "/add/").concat(encodeURIComponent(y)), navigator.sendBeacon && !n ? [3, 2] : (m = {
                                    method: "POST",
                                    headers: {
                                        "Content-Type": "application/json",
                                        "User-Agent": navigator.userAgent,
                                        Origin: location.origin,
                                        Referer: document.referrer
                                    },
                                    body: v
                                }, n && (m.headers.Authorization = n), [4, fetch(b, m)]);
                            case 1:
                                return i.sent(), [3, 3];
                            case 2:
                                w = new Blob([v]), navigator.sendBeacon(b, w), i.label = 3;
                            case 3:
                                return [2]
                        }
                    })
                })
            }, e.waitAndFlushQueue = function() {
                e.flushQueueTimeoutHandler || (e.flushQueueTimeoutHandler = setTimeout(function() {
                    e.WAIT_QUEUE.length > 0 && (e.WAIT_QUEUE = [])
                }, e.FLUSH_QUEUE_TIMEOUT))
            }, e.FLUSH_QUEUE_TIMEOUT = 1e4, e.conf = new s(n.FRESNEL_PROD), e.WAIT_QUEUE = [], e
        }();
        r.BigPictureClient = c
    }),
    yN = t(function(e, t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }),
    gN = t(function(t, r) {
        var n = e && e.__createBinding || (Object.create ? function(e, t, r, n) {
                void 0 === n && (n = r);
                var o = Object.getOwnPropertyDescriptor(t, r);
                o && !("get" in o ? !t.__esModule : o.writable || o.configurable) || (o = {
                    enumerable: !0,
                    get: function() {
                        return t[r]
                    }
                }), Object.defineProperty(e, n, o)
            } : function(e, t, r, n) {
                void 0 === n && (n = r), e[n] = t[r]
            }),
            o = e && e.__exportStar || function(e, t) {
                for (var r in e) "default" === r || Object.prototype.hasOwnProperty.call(t, r) || n(t, e, r)
            };
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), o(vN, r), o(hN, r), o(yN, r)
    });

function bN(e, t, r, n) {
    if (!KT(e)) return e;
    for (var o = -1, i = (t = IS(t, e)).length, a = i - 1, u = e; null != u && ++o < i;) {
        var s = OS(t[o]),
            c = r;
        if ("__proto__" === s || "constructor" === s || "prototype" === s) return e;
        if (o != a) {
            var f = u[s];
            void 0 === (c = n ? n(f, s, u) : void 0) && (c = KT(f) ? f : hA(t[o + 1]) ? [] : {})
        }
        tA(u, s, c), u = u[s]
    }
    return e
}

function mN(e, t) {
    return null != e && t in Object(e)
}

function wN(e, t) {
    return function(e, t, r) {
        for (var n = -1, o = t.length, i = {}; ++n < o;) {
            var a = t[n],
                u = RS(e, a);
            r(0, a) && bN(i, IS(a, e), u)
        }
        return i
    }(e, t, function(t, r) {
        return function(e, t) {
            return null != e && function(e, t, r) {
                for (var n = -1, o = (t = IS(t, e)).length, i = !1; ++n < o;) {
                    var a = OS(t[n]);
                    if (!(i = null != e && r(e, a))) break;
                    e = e[a]
                }
                return i || ++n != o ? i : !!(o = null == e ? 0 : e.length) && pA(o) && hA(a, o) && (DT(e) || uA(e))
            }(e, t, mN)
        }(e, r)
    })
}
var EN = LT ? LT.isConcatSpreadable : void 0;

function _N(e) {
    return DT(e) || uA(e) || !!(EN && e && e[EN])
}

function TN(e, t, r, n, o) {
    var i = -1,
        a = e.length;
    for (r || (r = _N), o || (o = []); ++i < a;) {
        var u = e[i];
        t > 0 && r(u) ? t > 1 ? TN(u, t - 1, r, n, o) : WA(o, u) : n || (o[o.length] = u)
    }
    return o
}

function SN(e) {
    return null != e && e.length ? TN(e, 1) : []
}
var AN, IN, ON, RN, NN, PN, MN, DN = function(e) {
        return BI(LI(e, void 0, SN), e + "")
    }(function(e, t) {
        return null == e ? {} : wN(e, t)
    }),
    xN = {},
    CN = [],
    kN = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;

function LN(e, t) {
    for (var r in t) e[r] = t[r];
    return e
}

function jN(e) {
    var t = e.parentNode;
    t && t.removeChild(e)
}

function XN(e, t, r) {
    var n, o, i, a = {};
    for (i in t) "key" == i ? n = t[i] : "ref" == i ? o = t[i] : a[i] = t[i];
    if (arguments.length > 2 && (a.children = arguments.length > 3 ? AN.call(arguments, 2) : r), "function" == typeof e && null != e.defaultProps)
        for (i in e.defaultProps) void 0 === a[i] && (a[i] = e.defaultProps[i]);
    return UN(e, a, n, o, null)
}

function UN(e, t, r, n, o) {
    var i = {
        type: e,
        props: t,
        key: r,
        ref: n,
        __k: null,
        __: null,
        __b: 0,
        __e: null,
        __d: void 0,
        __c: null,
        __h: null,
        constructor: void 0,
        __v: null == o ? ++ON : o
    };
    return null == o && null != IN.vnode && IN.vnode(i), i
}

function BN(e) {
    return e.children
}

function FN(e, t) {
    this.props = e, this.context = t
}

function VN(e, t) {
    if (null == t) return e.__ ? VN(e.__, e.__.__k.indexOf(e) + 1) : null;
    for (var r; t < e.__k.length; t++)
        if (null != (r = e.__k[t]) && null != r.__e) return r.__e;
    return "function" == typeof e.type ? VN(e) : null
}

function zN(e) {
    var t, r;
    if (null != (e = e.__) && null != e.__c) {
        for (e.__e = e.__c.base = null, t = 0; t < e.__k.length; t++)
            if (null != (r = e.__k[t]) && null != r.__e) {
                e.__e = e.__c.base = r.__e;
                break
            }
        return zN(e)
    }
}

function HN(e) {
    (!e.__d && (e.__d = !0) && RN.push(e) && !WN.__r++ || PN !== IN.debounceRendering) && ((PN = IN.debounceRendering) || NN)(WN)
}

function WN() {
    for (var e; WN.__r = RN.length;) e = RN.sort(function(e, t) {
        return e.__v.__b - t.__v.__b
    }), RN = [], e.some(function(e) {
        var t, r, n, o, i, a;
        e.__d && (i = (o = (t = e).__v).__e, (a = t.__P) && (r = [], (n = LN({}, o)).__v = o.__v + 1, eP(a, o, n, t.__n, void 0 !== a.ownerSVGElement, null != o.__h ? [i] : null, r, null == i ? VN(o) : i, o.__h), tP(r, o), o.__e != i && zN(o)))
    })
}

function YN(e, t, r, n, o, i, a, u, s, c) {
    var f, l, d, h, p, v, y, g = n && n.__k || CN,
        b = g.length;
    for (r.__k = [], f = 0; f < t.length; f++)
        if (null != (h = r.__k[f] = null == (h = t[f]) || "boolean" == typeof h ? null : "string" == typeof h || "number" == typeof h || "bigint" == typeof h ? UN(null, h, null, null, h) : Array.isArray(h) ? UN(BN, {
                children: h
            }, null, null, null) : h.__b > 0 ? UN(h.type, h.props, h.key, null, h.__v) : h)) {
            if (h.__ = r, h.__b = r.__b + 1, null === (d = g[f]) || d && h.key == d.key && h.type === d.type) g[f] = void 0;
            else
                for (l = 0; l < b; l++) {
                    if ((d = g[l]) && h.key == d.key && h.type === d.type) {
                        g[l] = void 0;
                        break
                    }
                    d = null
                }
            eP(e, h, d = d || xN, o, i, a, u, s, c), p = h.__e, (l = h.ref) && d.ref != l && (y || (y = []), d.ref && y.push(d.ref, null, h), y.push(l, h.__c || p, h)), null != p ? (null == v && (v = p), "function" == typeof h.type && h.__k === d.__k ? h.__d = s = GN(h, s, e) : s = qN(e, h, d, g, p, s), "function" == typeof r.type && (r.__d = s)) : s && d.__e == s && s.parentNode != e && (s = VN(d))
        }
    for (r.__e = v, f = b; f--;) null != g[f] && ("function" == typeof r.type && null != g[f].__e && g[f].__e == r.__d && (r.__d = VN(n, f + 1)), oP(g[f], g[f]));
    if (y)
        for (f = 0; f < y.length; f++) nP(y[f], y[++f], y[++f])
}

function GN(e, t, r) {
    for (var n, o = e.__k, i = 0; o && i < o.length; i++)(n = o[i]) && (n.__ = e, t = "function" == typeof n.type ? GN(n, t, r) : qN(r, n, n, o, n.__e, t));
    return t
}

function KN(e, t) {
    return t = t || [], null == e || "boolean" == typeof e || (Array.isArray(e) ? e.some(function(e) {
        KN(e, t)
    }) : t.push(e)), t
}

function qN(e, t, r, n, o, i) {
    var a, u, s;
    if (void 0 !== t.__d) a = t.__d, t.__d = void 0;
    else if (null == r || o != i || null == o.parentNode) e: if (null == i || i.parentNode !== e) e.appendChild(o), a = null;
        else {
            for (u = i, s = 0;
                (u = u.nextSibling) && s < n.length; s += 2)
                if (u == o) break e;
            e.insertBefore(o, i), a = i
        }
    return void 0 !== a ? a : o.nextSibling
}

function $N(e, t, r) {
    "-" === t[0] ? e.setProperty(t, r) : e[t] = null == r ? "" : "number" != typeof r || kN.test(t) ? r : r + "px"
}

function QN(e, t, r, n, o) {
    var i;
    e: if ("style" === t)
        if ("string" == typeof r) e.style.cssText = r;
        else {
            if ("string" == typeof n && (e.style.cssText = n = ""), n)
                for (t in n) r && t in r || $N(e.style, t, "");
            if (r)
                for (t in r) n && r[t] === n[t] || $N(e.style, t, r[t])
        }
    else if ("o" === t[0] && "n" === t[1]) i = t !== (t = t.replace(/Capture$/, "")), t = t.toLowerCase() in e ? t.toLowerCase().slice(2) : t.slice(2), e.l || (e.l = {}), e.l[t + i] = r, r ? n || e.addEventListener(t, i ? ZN : JN, i) : e.removeEventListener(t, i ? ZN : JN, i);
    else if ("dangerouslySetInnerHTML" !== t) {
        if (o) t = t.replace(/xlink[H:h]/, "h").replace(/sName$/, "s");
        else if ("href" !== t && "list" !== t && "form" !== t && "tabIndex" !== t && "download" !== t && t in e) try {
            e[t] = null == r ? "" : r;
            break e
        } catch (e) {}
        "function" == typeof r || (null != r && (!1 !== r || "a" === t[0] && "r" === t[1]) ? e.setAttribute(t, r) : e.removeAttribute(t))
    }
}

function JN(e) {
    this.l[e.type + !1](IN.event ? IN.event(e) : e)
}

function ZN(e) {
    this.l[e.type + !0](IN.event ? IN.event(e) : e)
}

function eP(e, t, r, n, o, i, a, u, s) {
    var c, f, l, d, h, p, v, y, g, b, m, w = t.type;
    if (void 0 !== t.constructor) return null;
    null != r.__h && (s = r.__h, u = t.__e = r.__e, t.__h = null, i = [u]), (c = IN.__b) && c(t);
    try {
        e: if ("function" == typeof w) {
            if (y = t.props, g = (c = w.contextType) && n[c.__c], b = c ? g ? g.props.value : c.__ : n, r.__c ? v = (f = t.__c = r.__c).__ = f.__E : ("prototype" in w && w.prototype.render ? t.__c = f = new w(y, b) : (t.__c = f = new FN(y, b), f.constructor = w, f.render = iP), g && g.sub(f), f.props = y, f.state || (f.state = {}), f.context = b, f.__n = n, l = f.__d = !0, f.__h = []), null == f.__s && (f.__s = f.state), null != w.getDerivedStateFromProps && (f.__s == f.state && (f.__s = LN({}, f.__s)), LN(f.__s, w.getDerivedStateFromProps(y, f.__s))), d = f.props, h = f.state, l) null == w.getDerivedStateFromProps && null != f.componentWillMount && f.componentWillMount(), null != f.componentDidMount && f.__h.push(f.componentDidMount);
            else {
                if (null == w.getDerivedStateFromProps && y !== d && null != f.componentWillReceiveProps && f.componentWillReceiveProps(y, b), !f.__e && null != f.shouldComponentUpdate && !1 === f.shouldComponentUpdate(y, f.__s, b) || t.__v === r.__v) {
                    f.props = y, f.state = f.__s, t.__v !== r.__v && (f.__d = !1), f.__v = t, t.__e = r.__e, t.__k = r.__k, t.__k.forEach(function(e) {
                        e && (e.__ = t)
                    }), f.__h.length && a.push(f);
                    break e
                }
                null != f.componentWillUpdate && f.componentWillUpdate(y, f.__s, b), null != f.componentDidUpdate && f.__h.push(function() {
                    f.componentDidUpdate(d, h, p)
                })
            }
            f.context = b, f.props = y, f.state = f.__s, (c = IN.__r) && c(t), f.__d = !1, f.__v = t, f.__P = e, c = f.render(f.props, f.state, f.context), f.state = f.__s, null != f.getChildContext && (n = LN(LN({}, n), f.getChildContext())), l || null == f.getSnapshotBeforeUpdate || (p = f.getSnapshotBeforeUpdate(d, h)), m = null != c && c.type === BN && null == c.key ? c.props.children : c, YN(e, Array.isArray(m) ? m : [m], t, r, n, o, i, a, u, s), f.base = t.__e, t.__h = null, f.__h.length && a.push(f), v && (f.__E = f.__ = null), f.__e = !1
        } else null == i && t.__v === r.__v ? (t.__k = r.__k, t.__e = r.__e) : t.__e = rP(r.__e, t, r, n, o, i, a, s);
        (c = IN.diffed) && c(t)
    }
    catch (e) {
        t.__v = null, (s || null != i) && (t.__e = u, t.__h = !!s, i[i.indexOf(u)] = null), IN.__e(e, t, r)
    }
}

function tP(e, t) {
    IN.__c && IN.__c(t, e), e.some(function(t) {
        try {
            e = t.__h, t.__h = [], e.some(function(e) {
                e.call(t)
            })
        } catch (e) {
            IN.__e(e, t.__v)
        }
    })
}

function rP(e, t, r, n, o, i, a, u) {
    var s, c, f, l = r.props,
        d = t.props,
        h = t.type,
        p = 0;
    if ("svg" === h && (o = !0), null != i)
        for (; p < i.length; p++)
            if ((s = i[p]) && "setAttribute" in s == !!h && (h ? s.localName === h : 3 === s.nodeType)) {
                e = s, i[p] = null;
                break
            }
    if (null == e) {
        if (null === h) return document.createTextNode(d);
        e = o ? document.createElementNS("http://www.w3.org/2000/svg", h) : document.createElement(h, d.is && d), i = null, u = !1
    }
    if (null === h) l === d || u && e.data === d || (e.data = d);
    else {
        if (i = i && AN.call(e.childNodes), c = (l = r.props || xN).dangerouslySetInnerHTML, f = d.dangerouslySetInnerHTML, !u) {
            if (null != i)
                for (l = {}, p = 0; p < e.attributes.length; p++) l[e.attributes[p].name] = e.attributes[p].value;
            (f || c) && (f && (c && f.__html == c.__html || f.__html === e.innerHTML) || (e.innerHTML = f && f.__html || ""))
        }
        if (function(e, t, r, n, o) {
                var i;
                for (i in r) "children" === i || "key" === i || i in t || QN(e, i, null, r[i], n);
                for (i in t) o && "function" != typeof t[i] || "children" === i || "key" === i || "value" === i || "checked" === i || r[i] === t[i] || QN(e, i, t[i], r[i], n)
            }(e, d, l, o, u), f) t.__k = [];
        else if (p = t.props.children, YN(e, Array.isArray(p) ? p : [p], t, r, n, o && "foreignObject" !== h, i, a, i ? i[0] : r.__k && VN(r, 0), u), null != i)
            for (p = i.length; p--;) null != i[p] && jN(i[p]);
        u || ("value" in d && void 0 !== (p = d.value) && (p !== e.value || "progress" === h && !p || "option" === h && p !== l.value) && QN(e, "value", p, l.value, !1), "checked" in d && void 0 !== (p = d.checked) && p !== e.checked && QN(e, "checked", p, l.checked, !1))
    }
    return e
}

function nP(e, t, r) {
    try {
        "function" == typeof e ? e(t) : e.current = t
    } catch (e) {
        IN.__e(e, r)
    }
}

function oP(e, t, r) {
    var n, o;
    if (IN.unmount && IN.unmount(e), (n = e.ref) && (n.current && n.current !== e.__e || nP(n, null, t)), null != (n = e.__c)) {
        if (n.componentWillUnmount) try {
            n.componentWillUnmount()
        } catch (e) {
            IN.__e(e, t)
        }
        n.base = n.__P = null
    }
    if (n = e.__k)
        for (o = 0; o < n.length; o++) n[o] && oP(n[o], t, "function" != typeof e.type);
    r || null == e.__e || jN(e.__e), e.__e = e.__d = void 0
}

function iP(e, t, r) {
    return this.constructor(e, r)
}

function aP(e, t, r) {
    var n, o, i;
    IN.__ && IN.__(e, t), o = (n = "function" == typeof r) ? null : r && r.__k || t.__k, i = [], eP(t, e = (!n && r || t).__k = XN(BN, null, [e]), o || xN, xN, void 0 !== t.ownerSVGElement, !n && r ? [r] : o ? null : t.firstChild ? AN.call(t.childNodes) : null, i, !n && r ? r : o ? o.__e : t.firstChild, n), tP(i, e)
}

function uP(e, t) {
    aP(e, t, uP)
}

function sP(e, t, r) {
    var n, o, i, a = LN({}, e.props);
    for (i in t) "key" == i ? n = t[i] : "ref" == i ? o = t[i] : a[i] = t[i];
    return arguments.length > 2 && (a.children = arguments.length > 3 ? AN.call(arguments, 2) : r), UN(e.type, a, n || e.key, o || e.ref, null)
}

function cP(e, t) {
    var r = {
        __c: t = "__cC" + MN++,
        __: e,
        Consumer: function(e, t) {
            return e.children(t)
        },
        Provider: function(e) {
            var r, n;
            return this.getChildContext || (r = [], (n = {})[t] = this, this.getChildContext = function() {
                return n
            }, this.shouldComponentUpdate = function(e) {
                this.props.value !== e.value && r.some(HN)
            }, this.sub = function(e) {
                r.push(e);
                var t = e.componentWillUnmount;
                e.componentWillUnmount = function() {
                    r.splice(r.indexOf(e), 1), t && t.call(e)
                }
            }), e.children
        }
    };
    return r.Provider.__ = r.Consumer.contextType = r
}
AN = CN.slice, IN = {
    __e: function(e, t) {
        for (var r, n, o; t = t.__;)
            if ((r = t.__c) && !r.__) try {
                if ((n = r.constructor) && null != n.getDerivedStateFromError && (r.setState(n.getDerivedStateFromError(e)), o = r.__d), null != r.componentDidCatch && (r.componentDidCatch(e), o = r.__d), o) return r.__E = r
            } catch (t) {
                e = t
            }
        throw e
    }
}, ON = 0, FN.prototype.setState = function(e, t) {
    var r;
    r = null != this.__s && this.__s !== this.state ? this.__s : this.__s = LN({}, this.state), "function" == typeof e && (e = e(LN({}, r), this.props)), e && LN(r, e), null != e && this.__v && (t && this.__h.push(t), HN(this))
}, FN.prototype.forceUpdate = function(e) {
    this.__v && (this.__e = !0, e && this.__h.push(e), HN(this))
}, FN.prototype.render = BN, RN = [], NN = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, WN.__r = 0, MN = 0;
var fP, lP, dP, hP = 0,
    pP = [],
    vP = IN.__b,
    yP = IN.__r,
    gP = IN.diffed,
    bP = IN.__c,
    mP = IN.unmount;

function wP(e, t) {
    IN.__h && IN.__h(lP, e, hP || t), hP = 0;
    var r = lP.__H || (lP.__H = {
        __: [],
        __h: []
    });
    return e >= r.__.length && r.__.push({}), r.__[e]
}

function EP(e) {
    return hP = 1, _P(LP, e)
}

function _P(e, t, r) {
    var n = wP(fP++, 2);
    return n.t = e, n.__c || (n.__ = [r ? r(t) : LP(void 0, t), function(e) {
        var t = n.t(n.__[0], e);
        n.__[0] !== t && (n.__ = [t, n.__[1]], n.__c.setState({}))
    }], n.__c = lP), n.__
}

function TP(e, t) {
    var r = wP(fP++, 3);
    !IN.__s && kP(r.__H, t) && (r.__ = e, r.__H = t, lP.__H.__h.push(r))
}

function SP(e, t) {
    var r = wP(fP++, 4);
    !IN.__s && kP(r.__H, t) && (r.__ = e, r.__H = t, lP.__h.push(r))
}

function AP(e) {
    return hP = 5, IP(function() {
        return {
            current: e
        }
    }, [])
}

function IP(e, t) {
    var r = wP(fP++, 7);
    return kP(r.__H, t) && (r.__ = e(), r.__H = t, r.__h = e), r.__
}

function OP(e, t) {
    return hP = 8, IP(function() {
        return e
    }, t)
}

function RP(e) {
    var t = lP.context[e.__c],
        r = wP(fP++, 9);
    return r.c = e, t ? (null == r.__ && (r.__ = !0, t.sub(lP)), t.props.value) : e.__
}

function NP(e, t) {
    IN.useDebugValue && IN.useDebugValue(t ? t(e) : e)
}

function PP(e) {
    var t = wP(fP++, 10),
        r = EP();
    return t.__ = e, lP.componentDidCatch || (lP.componentDidCatch = function(e) {
        t.__ && t.__(e), r[1](e)
    }), [r[0], function() {
        r[1](void 0)
    }]
}

function MP() {
    for (var e; e = pP.shift();)
        if (e.__P) try {
            e.__H.__h.forEach(xP), e.__H.__h.forEach(CP), e.__H.__h = []
        } catch (t) {
            e.__H.__h = [], IN.__e(t, e.__v)
        }
}
IN.__b = function(e) {
    lP = null, vP && vP(e)
}, IN.__r = function(e) {
    yP && yP(e), fP = 0;
    var t = (lP = e.__c).__H;
    t && (t.__h.forEach(xP), t.__h.forEach(CP), t.__h = [])
}, IN.diffed = function(e) {
    gP && gP(e);
    var t = e.__c;
    t && t.__H && t.__H.__h.length && (1 !== pP.push(t) && dP === IN.requestAnimationFrame || ((dP = IN.requestAnimationFrame) || function(e) {
        var t, r = function() {
                clearTimeout(n), DP && cancelAnimationFrame(t), setTimeout(e)
            },
            n = setTimeout(r, 100);
        DP && (t = requestAnimationFrame(r))
    })(MP)), lP = null
}, IN.__c = function(e, t) {
    t.some(function(e) {
        try {
            e.__h.forEach(xP), e.__h = e.__h.filter(function(e) {
                return !e.__ || CP(e)
            })
        } catch (r) {
            t.some(function(e) {
                e.__h && (e.__h = [])
            }), t = [], IN.__e(r, e.__v)
        }
    }), bP && bP(e, t)
}, IN.unmount = function(e) {
    mP && mP(e);
    var t, r = e.__c;
    r && r.__H && (r.__H.__.forEach(function(e) {
        try {
            xP(e)
        } catch (e) {
            t = e
        }
    }), t && IN.__e(t, r.__v))
};
var DP = "function" == typeof requestAnimationFrame;

function xP(e) {
    var t = lP,
        r = e.__c;
    "function" == typeof r && (e.__c = void 0, r()), lP = t
}

function CP(e) {
    var t = lP;
    e.__c = e.__(), lP = t
}

function kP(e, t) {
    return !e || e.length !== t.length || t.some(function(t, r) {
        return t !== e[r]
    })
}

function LP(e, t) {
    return "function" == typeof t ? t(e) : t
}

function jP() {
    return jP = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var r = arguments[t];
            for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
        }
        return e
    }, jP.apply(this, arguments)
}

function XP(e, t) {
    return XP = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
        return e.__proto__ = t, e
    }, XP(e, t)
}
var UP, BP, FP, VP = function(e) {
    var t, r;

    function n() {
        return e.apply(this, arguments) || this
    }
    r = e, (t = n).prototype = Object.create(r.prototype), t.prototype.constructor = t, XP(t, r);
    var o = n.prototype;
    return o.componentDidMount = function() {
        this.props.nodeRef.current = this.base
    }, o.componentWillUnmount = function() {
        this.props.nodeRef.current = void 0
    }, o.render = function() {
        return XN(BN, {}, this.props.children)
    }, n
}(FN);
! function(e) {
    e.APPEAR = "appear", e.APPEAR_ACTIVE = "appearActive", e.APPEAR_DONE = "appearDone", e.ENTER = "enter", e.ENTER_ACTIVE = "enterActive", e.ENTER_DONE = "enterDone", e.EXIT = "exit", e.EXIT_ACTIVE = "exitActive", e.EXIT_DONE = "exitDone"
}(BP || (BP = {})),
function(e) {
    e.ENTER = "onEnter", e.ENTERING = "onEntering", e.ENTERED = "onEntered", e.EXIT = "onExit", e.EXITING = "onExiting", e.EXITED = "onExited"
}(FP || (FP = {}));
var zP = ((UP = {})[BP.APPEAR] = [FP.ENTER, BP.APPEAR_ACTIVE], UP[BP.APPEAR_ACTIVE] = [FP.ENTERING, BP.APPEAR_DONE, !0], UP[BP.APPEAR_DONE] = [FP.ENTERED], UP[BP.ENTER] = [FP.ENTER, BP.ENTER_ACTIVE], UP[BP.ENTER_ACTIVE] = [FP.ENTERING, BP.ENTER_DONE, !0], UP[BP.ENTER_DONE] = [FP.ENTERED], UP[BP.EXIT] = [FP.EXIT, BP.EXIT_ACTIVE], UP[BP.EXIT_ACTIVE] = [FP.EXITING, BP.EXIT_DONE, !0], UP[BP.EXIT_DONE] = [FP.EXITED], UP);

function HP(e) {
    var t = e.children,
        r = e.in,
        n = void 0 !== r && r,
        o = e.appear,
        i = void 0 !== o && o,
        a = e.enter,
        u = void 0 === a || a,
        s = e.exit,
        c = void 0 === s || s,
        f = e.duration,
        l = void 0 === f ? 500 : f,
        d = e.alwaysMounted,
        h = void 0 !== d && d,
        p = e.addEndListener,
        v = AP(),
        y = AP(),
        g = !1,
        b = EP(function() {
            return g = !0, n ? i ? BP.APPEAR : BP.APPEAR_DONE : BP.EXIT_DONE
        }),
        m = b[0],
        w = b[1];
    TP(function() {
        var t = window,
            r = t.setTimeout,
            n = t.clearTimeout,
            o = zP[m],
            i = o[1],
            a = o[2],
            u = e[o[0]];
        return null == u || u(v.current), i && (a ? p ? p(v.current, function() {
                return w(i)
            }) : y.current = r(w, l, i) : w(i)),
            function() {
                n(y.current)
            }
    }, [m, l]), SP(function() {
        g || w(n ? u ? BP.ENTER : BP.ENTER_DONE : c ? BP.EXIT : BP.EXIT_DONE)
    }, [n]);
    var E = IP(function() {
        var e = {};
        return Object.keys(zP).forEach(function(t) {
            e[t] = m === t
        }), e
    }, [m]);
    return h || (c ? m !== BP.EXIT_DONE : n) ? XN(VP, {
        nodeRef: v,
        children: t(E, m)
    }) : null
}
var WP, YP = ["children", "styles"];

function GP(e) {
    var t = e.children,
        r = e.styles,
        n = function(e, t) {
            if (null == e) return {};
            var r, n, o = {},
                i = Object.keys(e);
            for (n = 0; n < i.length; n++) t.indexOf(r = i[n]) >= 0 || (o[r] = e[r]);
            return o
        }(e, YP);
    return XN(HP, n, function(e, n) {
        var o = t.props.style,
            i = IP(function() {
                return jP({}, function(e, t) {
                    var r = t[e];
                    switch (e) {
                        case BP.APPEAR_ACTIVE:
                            return jP({}, t[BP.APPEAR], r);
                        case BP.ENTER_ACTIVE:
                            return jP({}, t[BP.ENTER], r);
                        case BP.EXIT_ACTIVE:
                            return jP({}, t[BP.EXIT], r);
                        default:
                            return r
                    }
                }(n, r), o)
            }, [o, r, n]);
        return sP(t, {
            style: i
        })
    })
}

function KP(e, t) {
    for (var r in t) e[r] = t[r];
    return e
}

function qP(e, t) {
    for (var r in e)
        if ("__source" !== r && !(r in t)) return !0;
    for (var n in t)
        if ("__source" !== n && e[n] !== t[n]) return !0;
    return !1
}

function $P(e) {
    this.props = e
}(WP = {})[BP.APPEAR] = "-appear", WP[BP.APPEAR_ACTIVE] = "-appear-active", WP[BP.APPEAR_DONE] = "-appear-done", WP[BP.ENTER] = "-enter", WP[BP.ENTER_ACTIVE] = "-enter-active", WP[BP.ENTER_DONE] = "-enter-done", WP[BP.EXIT] = "-exit", WP[BP.EXIT_ACTIVE] = "-exit-active", WP[BP.EXIT_DONE] = "-exit-done", ($P.prototype = new FN).isPureReactComponent = !0, $P.prototype.shouldComponentUpdate = function(e, t) {
    return qP(this.props, e) || qP(this.state, t)
};
var QP = IN.__b;
IN.__b = function(e) {
    e.type && e.type.__f && e.ref && (e.props.ref = e.ref, e.ref = null), QP && QP(e)
};
var JP = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.forward_ref") || 3911;

function ZP(e) {
    function t(t, r) {
        var n = KP({}, t);
        return delete n.ref, e(n, (r = t.ref || r) && ("object" != typeof r || "current" in r) ? r : null)
    }
    return t.$$typeof = JP, t.render = t, t.prototype.isReactComponent = t.__f = !0, t.displayName = "ForwardRef(" + (e.displayName || e.name) + ")", t
}
var eM = function(e, t) {
        return null == e ? null : KN(KN(e).map(t))
    },
    tM = {
        map: eM,
        forEach: eM,
        count: function(e) {
            return e ? KN(e).length : 0
        },
        only: function(e) {
            var t = KN(e);
            if (1 !== t.length) throw "Children.only";
            return t[0]
        },
        toArray: KN
    },
    rM = IN.__e;
IN.__e = function(e, t, r) {
    if (e.then)
        for (var n, o = t; o = o.__;)
            if ((n = o.__c) && n.__c) return null == t.__e && (t.__e = r.__e, t.__k = r.__k), n.__c(e, t);
    rM(e, t, r)
};
var nM = IN.unmount;

function oM() {
    this.__u = 0, this.t = null, this.__b = null
}

function iM(e) {
    var t = e.__.__c;
    return t && t.__e && t.__e(e)
}

function aM() {
    this.u = null, this.o = null
}
IN.unmount = function(e) {
    var t = e.__c;
    t && t.__R && t.__R(), t && !0 === e.__h && (e.type = null), nM && nM(e)
}, (oM.prototype = new FN).__c = function(e, t) {
    var r = t.__c,
        n = this;
    null == n.t && (n.t = []), n.t.push(r);
    var o = iM(n.__v),
        i = !1,
        a = function() {
            i || (i = !0, r.__R = null, o ? o(u) : u())
        };
    r.__R = a;
    var u = function() {
            if (!--n.__u) {
                if (n.state.__e) {
                    var e = n.state.__e;
                    n.__v.__k[0] = function e(t, r, n) {
                        return t && (t.__v = null, t.__k = t.__k && t.__k.map(function(t) {
                            return e(t, r, n)
                        }), t.__c && t.__c.__P === r && (t.__e && n.insertBefore(t.__e, t.__d), t.__c.__e = !0, t.__c.__P = n)), t
                    }(e, e.__c.__P, e.__c.__O)
                }
                var t;
                for (n.setState({
                        __e: n.__b = null
                    }); t = n.t.pop();) t.forceUpdate()
            }
        },
        s = !0 === t.__h;
    n.__u++ || s || n.setState({
        __e: n.__b = n.__v.__k[0]
    }), e.then(a, a)
}, oM.prototype.componentWillUnmount = function() {
    this.t = []
}, oM.prototype.render = function(e, t) {
    if (this.__b) {
        if (this.__v.__k) {
            var r = document.createElement("div"),
                n = this.__v.__k[0].__c;
            this.__v.__k[0] = function e(t, r, n) {
                return t && (t.__c && t.__c.__H && (t.__c.__H.__.forEach(function(e) {
                    "function" == typeof e.__c && e.__c()
                }), t.__c.__H = null), null != (t = KP({}, t)).__c && (t.__c.__P === n && (t.__c.__P = r), t.__c = null), t.__k = t.__k && t.__k.map(function(t) {
                    return e(t, r, n)
                })), t
            }(this.__b, r, n.__O = n.__P)
        }
        this.__b = null
    }
    var o = t.__e && XN(BN, null, e.fallback);
    return o && (o.__h = null), [XN(BN, null, t.__e ? null : e.children), o]
};
var uM = function(e, t, r) {
    if (++r[1] === r[0] && e.o.delete(t), e.props.revealOrder && ("t" !== e.props.revealOrder[0] || !e.o.size))
        for (r = e.u; r;) {
            for (; r.length > 3;) r.pop()();
            if (r[1] < r[0]) break;
            e.u = r = r[2]
        }
};

function sM(e) {
    return this.getChildContext = function() {
        return e.context
    }, e.children
}

function cM(e) {
    var t = this,
        r = e.i;
    t.componentWillUnmount = function() {
        aP(null, t.l), t.l = null, t.i = null
    }, t.i && t.i !== r && t.componentWillUnmount(), e.__v ? (t.l || (t.i = r, t.l = {
        nodeType: 1,
        parentNode: r,
        childNodes: [],
        appendChild: function(e) {
            this.childNodes.push(e), t.i.appendChild(e)
        },
        insertBefore: function(e, r) {
            this.childNodes.push(e), t.i.appendChild(e)
        },
        removeChild: function(e) {
            this.childNodes.splice(this.childNodes.indexOf(e) >>> 1, 1), t.i.removeChild(e)
        }
    }), aP(XN(sM, {
        context: t.context
    }, e.__v), t.l)) : t.l && t.componentWillUnmount()
}

function fM(e, t) {
    return XN(cM, {
        __v: e,
        i: t
    })
}(aM.prototype = new FN).__e = function(e) {
    var t = this,
        r = iM(t.__v),
        n = t.o.get(e);
    return n[0]++,
        function(o) {
            var i = function() {
                t.props.revealOrder ? (n.push(o), uM(t, e, n)) : o()
            };
            r ? r(i) : i()
        }
}, aM.prototype.render = function(e) {
    this.u = null, this.o = new Map;
    var t = KN(e.children);
    e.revealOrder && "b" === e.revealOrder[0] && t.reverse();
    for (var r = t.length; r--;) this.o.set(t[r], this.u = [1, 0, this.u]);
    return e.children
}, aM.prototype.componentDidUpdate = aM.prototype.componentDidMount = function() {
    var e = this;
    this.o.forEach(function(t, r) {
        uM(e, r, t)
    })
};
var lM = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103,
    dM = /^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|marker(?!H|W|U)|overline|paint|stop|strikethrough|stroke|text(?!L)|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/,
    hM = "undefined" != typeof document,
    pM = function(e) {
        return ("undefined" != typeof Symbol && "symbol" == typeof Symbol() ? /fil|che|rad/i : /fil|che|ra/i).test(e)
    };
FN.prototype.isReactComponent = {}, ["componentWillMount", "componentWillReceiveProps", "componentWillUpdate"].forEach(function(e) {
    Object.defineProperty(FN.prototype, e, {
        configurable: !0,
        get: function() {
            return this["UNSAFE_" + e]
        },
        set: function(t) {
            Object.defineProperty(this, e, {
                configurable: !0,
                writable: !0,
                value: t
            })
        }
    })
});
var vM = IN.event;

function yM() {}

function gM() {
    return this.cancelBubble
}

function bM() {
    return this.defaultPrevented
}
IN.event = function(e) {
    return vM && (e = vM(e)), e.persist = yM, e.isPropagationStopped = gM, e.isDefaultPrevented = bM, e.nativeEvent = e
};
var mM, wM = {
        configurable: !0,
        get: function() {
            return this.class
        }
    },
    EM = IN.vnode;
IN.vnode = function(e) {
    var t = e.type,
        r = e.props,
        n = r;
    if ("string" == typeof t) {
        var o = -1 === t.indexOf("-");
        for (var i in n = {}, r) {
            var a = r[i];
            hM && "children" === i && "noscript" === t || "value" === i && "defaultValue" in r && null == a || ("defaultValue" === i && "value" in r && null == r.value ? i = "value" : "download" === i && !0 === a ? a = "" : /ondoubleclick/i.test(i) ? i = "ondblclick" : /^onchange(textarea|input)/i.test(i + t) && !pM(r.type) ? i = "oninput" : /^onfocus$/i.test(i) ? i = "onfocusin" : /^onblur$/i.test(i) ? i = "onfocusout" : /^on(Ani|Tra|Tou|BeforeInp|Compo)/.test(i) ? i = i.toLowerCase() : o && dM.test(i) ? i = i.replace(/[A-Z0-9]/, "-$&").toLowerCase() : null === a && (a = void 0), n[i] = a)
        }
        "select" == t && n.multiple && Array.isArray(n.value) && (n.value = KN(r.children).forEach(function(e) {
            e.props.selected = -1 != n.value.indexOf(e.props.value)
        })), "select" == t && null != n.defaultValue && (n.value = KN(r.children).forEach(function(e) {
            e.props.selected = n.multiple ? -1 != n.defaultValue.indexOf(e.props.value) : n.defaultValue == e.props.value
        })), e.props = n, r.class != r.className && (wM.enumerable = "className" in r, null != r.className && (n.class = r.className), Object.defineProperty(n, "className", wM))
    }
    e.$$typeof = lM, EM && EM(e)
};
var _M = IN.__r;
IN.__r = function(e) {
    _M && _M(e), mM = e.__c
};
var TM = {
    ReactCurrentDispatcher: {
        current: {
            readContext: function(e) {
                return mM.__n[e.__c].props.value
            }
        }
    }
};

function SM(e) {
    return !!e && e.$$typeof === lM
}
var AM = {
    useState: EP,
    useReducer: _P,
    useEffect: TP,
    useLayoutEffect: SP,
    useRef: AP,
    useImperativeHandle: function(e, t, r) {
        hP = 6, SP(function() {
            "function" == typeof e ? e(t()) : e && (e.current = t())
        }, null == r ? r : r.concat(e))
    },
    useMemo: IP,
    useCallback: OP,
    useContext: RP,
    useDebugValue: NP,
    version: "17.0.2",
    Children: tM,
    render: function(e, t, r) {
        return null == t.__k && (t.textContent = ""), aP(e, t), "function" == typeof r && r(), e ? e.__c : null
    },
    hydrate: function(e, t, r) {
        return uP(e, t), "function" == typeof r && r(), e ? e.__c : null
    },
    unmountComponentAtNode: function(e) {
        return !!e.__k && (aP(null, e), !0)
    },
    createPortal: fM,
    createElement: XN,
    createContext: cP,
    createFactory: function(e) {
        return XN.bind(null, e)
    },
    cloneElement: function(e) {
        return SM(e) ? sP.apply(null, arguments) : e
    },
    createRef: function() {
        return {
            current: null
        }
    },
    Fragment: BN,
    isValidElement: SM,
    findDOMNode: function(e) {
        return e && (e.base || 1 === e.nodeType && e) || null
    },
    Component: FN,
    PureComponent: $P,
    memo: function(e, t) {
        function r(e) {
            var r = this.props.ref,
                n = r == e.ref;
            return !n && r && (r.call ? r(null) : r.current = null), t ? !t(this.props, e) || !n : qP(this.props, e)
        }

        function n(t) {
            return this.shouldComponentUpdate = r, XN(e, t)
        }
        return n.displayName = "Memo(" + (e.displayName || e.name) + ")", n.prototype.isReactComponent = !0, n.__f = !0, n
    },
    forwardRef: ZP,
    flushSync: function(e, t) {
        return e(t)
    },
    unstable_batchedUpdates: function(e, t) {
        return e(t)
    },
    StrictMode: BN,
    Suspense: oM,
    SuspenseList: aM,
    lazy: function(e) {
        var t, r, n;

        function o(o) {
            if (t || (t = e()).then(function(e) {
                    r = e.default || e
                }, function(e) {
                    n = e
                }), n) throw n;
            if (!r) throw t;
            return XN(r, o)
        }
        return o.displayName = "Lazy", o.__f = !0, o
    },
    __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: TM
};
const IM = "undefined" == typeof window || !window.navigator || /ServerSideRendering|^Deno\//.test(window.navigator.userAgent) ? TP : SP;

function OM(e) {
    const t = "function" == typeof e ? function(e) {
            let t;
            const r = new Set,
                n = (e, n) => {
                    const o = "function" == typeof e ? e(t) : e;
                    if (o !== t) {
                        const e = t;
                        t = n ? o : Object.assign({}, t, o), r.forEach(r => r(t, e))
                    }
                },
                o = () => t,
                i = {
                    setState: n,
                    getState: o,
                    subscribe: (e, n, i) => n || i ? ((e, n = o, i = Object.is) => {
                        let a = n(t);

                        function u() {
                            const r = n(t);
                            if (!i(a, r)) {
                                const t = a;
                                e(a = r, t)
                            }
                        }
                        return r.add(u), () => r.delete(u)
                    })(e, n, i) : (r.add(e), () => r.delete(e)),
                    destroy: () => r.clear()
                };
            return t = e(n, o, i), i
        }(e) : e,
        r = (e = t.getState, r = Object.is) => {
            const [, n] = _P(e => e + 1, 0), o = t.getState(), i = AP(o), a = AP(e), u = AP(r), s = AP(!1), c = AP();
            let f;
            void 0 === c.current && (c.current = e(o));
            let l = !1;
            (i.current !== o || a.current !== e || u.current !== r || s.current) && (f = e(o), l = !r(c.current, f)), IM(() => {
                l && (c.current = f), i.current = o, a.current = e, u.current = r, s.current = !1
            });
            const d = AP(o);
            IM(() => {
                const e = () => {
                        try {
                            const e = t.getState(),
                                r = a.current(e);
                            u.current(c.current, r) || (i.current = e, c.current = r, n())
                        } catch (e) {
                            s.current = !0, n()
                        }
                    },
                    r = t.subscribe(e);
                return t.getState() !== d.current && e(), r
            }, []);
            const h = l ? f : c.current;
            return NP(h), h
        };
    return Object.assign(r, t), r[Symbol.iterator] = function() {
        const e = [r, t];
        return {
            next() {
                const t = e.length <= 0;
                return {
                    value: e.shift(),
                    done: t
                }
            }
        }
    }, r
}

function RM() {
    const e = cP(void 0);
    return {
        Provider: ({
            initialStore: t,
            createStore: r,
            children: n
        }) => {
            const o = AP();
            return o.current || (t && (r || (r = () => t)), o.current = r()), XN(e.Provider, {
                value: o.current
            }, n)
        },
        useStore: (t, r = Object.is) => {
            const n = RP(e);
            if (!n) throw new Error("Seems like you have not used zustand provider as an ancestor.");
            return n(t, r)
        },
        useStoreApi: () => {
            const t = RP(e);
            if (!t) throw new Error("Seems like you have not used zustand provider as an ancestor.");
            return IP(() => ({
                getState: t.getState,
                setState: t.setState,
                subscribe: t.subscribe,
                destroy: t.destroy
            }), [t])
        }
    }
}
const NM = e => (t, r, n) => {
        const o = n.subscribe;
        return n.subscribe = (e, t, r) => {
            let i = e;
            if (t) {
                const o = (null == r ? void 0 : r.equalityFn) || Object.is;
                let a = e(n.getState());
                i = r => {
                    const n = e(r);
                    if (!o(a, n)) {
                        const e = a;
                        t(a = n, e)
                    }
                }, (null == r ? void 0 : r.fireImmediately) && t(a, a)
            }
            return o(i)
        }, e(t, r, n)
    },
    PM = (e, t) => (r, n, o) => Object.assign({}, e, t(r, n, o));

function MM(e) {
    let t;
    const r = new Set,
        n = (e, n) => {
            const o = "function" == typeof e ? e(t) : e;
            if (o !== t) {
                const e = t;
                t = n ? o : Object.assign({}, t, o), r.forEach(r => r(t, e))
            }
        },
        o = () => t,
        i = {
            setState: n,
            getState: o,
            subscribe: (e, n, i) => n || i ? ((e, n = o, i = Object.is) => {
                let a = n(t);

                function u() {
                    const r = n(t);
                    if (!i(a, r)) {
                        const t = a;
                        e(a = r, t)
                    }
                }
                return r.add(u), () => r.delete(u)
            })(e, n, i) : (r.add(e), () => r.delete(e)),
            destroy: () => r.clear()
        };
    return t = e(n, o, i), i
}
var DM = 0;

function xM(e, t, r, n, o) {
    var i, a, u = {};
    for (a in t) "ref" == a ? i = t[a] : u[a] = t[a];
    var s = {
        type: e,
        props: u,
        key: r,
        ref: i,
        __k: null,
        __: null,
        __b: 0,
        __e: null,
        __d: void 0,
        __c: null,
        __h: null,
        constructor: void 0,
        __v: --DM,
        __source: n,
        __self: o
    };
    if ("function" == typeof e && (i = e.defaultProps))
        for (a in i) void 0 === u[a] && (u[a] = i[a]);
    return IN.vnode && IN.vnode(s), s
}

function CM(e) {
    var t = -1,
        r = null == e ? 0 : e.length;
    for (this.__data__ = new gS; ++t < r;) this.add(e[t])
}

function kM(e, t) {
    for (var r = -1, n = null == e ? 0 : e.length; ++r < n;)
        if (t(e[r], r, e)) return !0;
    return !1
}

function LM(e, t) {
    return e.has(t)
}

function jM(e, t, r, n, o, i) {
    var a = 1 & r,
        u = e.length,
        s = t.length;
    if (u != s && !(a && s > u)) return !1;
    var c = i.get(e),
        f = i.get(t);
    if (c && f) return c == t && f == e;
    var l = -1,
        d = !0,
        h = 2 & r ? new CM : void 0;
    for (i.set(e, t), i.set(t, e); ++l < u;) {
        var p = e[l],
            v = t[l];
        if (n) var y = a ? n(v, p, l, t, e, i) : n(p, v, l, e, t, i);
        if (void 0 !== y) {
            if (y) continue;
            d = !1;
            break
        }
        if (h) {
            if (!kM(t, function(e, t) {
                    if (!LM(h, t) && (p === e || o(p, e, r, n, i))) return h.push(t)
                })) {
                d = !1;
                break
            }
        } else if (p !== v && !o(p, v, r, n, i)) {
            d = !1;
            break
        }
    }
    return i.delete(e), i.delete(t), d
}

function XM(e) {
    var t = -1,
        r = Array(e.size);
    return e.forEach(function(e, n) {
        r[++t] = [n, e]
    }), r
}

function UM(e) {
    var t = -1,
        r = Array(e.size);
    return e.forEach(function(e) {
        r[++t] = e
    }), r
}
CM.prototype.add = CM.prototype.push = function(e) {
    return this.__data__.set(e, "__lodash_hash_undefined__"), this
}, CM.prototype.has = function(e) {
    return this.__data__.has(e)
};
var BM = LT ? LT.prototype : void 0,
    FM = BM ? BM.valueOf : void 0,
    VM = Object.prototype.hasOwnProperty,
    zM = "[object Arguments]",
    HM = "[object Array]",
    WM = "[object Object]",
    YM = Object.prototype.hasOwnProperty;

function GM(e, t, r, n, o) {
    return e === t || (null == e || null == t || !HT(e) && !HT(t) ? e != e && t != t : function(e, t, r, n, o, i) {
        var a = DT(e),
            u = DT(t),
            s = a ? HM : dI(e),
            c = u ? HM : dI(t),
            f = (s = s == zM ? WM : s) == WM,
            l = (c = c == zM ? WM : c) == WM,
            d = s == c;
        if (d && lA(e)) {
            if (!lA(t)) return !1;
            a = !0, f = !1
        }
        if (d && !f) return i || (i = new QS), a || _A(e) ? jM(e, t, r, n, o, i) : function(e, t, r, n, o, i, a) {
            switch (r) {
                case "[object DataView]":
                    if (e.byteLength != t.byteLength || e.byteOffset != t.byteOffset) return !1;
                    e = e.buffer, t = t.buffer;
                case "[object ArrayBuffer]":
                    return !(e.byteLength != t.byteLength || !i(new pI(e), new pI(t)));
                case "[object Boolean]":
                case "[object Date]":
                case "[object Number]":
                    return lS(+e, +t);
                case "[object Error]":
                    return e.name == t.name && e.message == t.message;
                case "[object RegExp]":
                case "[object String]":
                    return e == t + "";
                case "[object Map]":
                    var u = XM;
                case "[object Set]":
                    var s = 1 & n;
                    if (u || (u = UM), e.size != t.size && !s) return !1;
                    var c = a.get(e);
                    if (c) return c == t;
                    n |= 2, a.set(e, t);
                    var f = jM(u(e), u(t), n, o, i, a);
                    return a.delete(e), f;
                case "[object Symbol]":
                    if (FM) return FM.call(e) == FM.call(t)
            }
            return !1
        }(e, t, s, r, n, o, i);
        if (!(1 & r)) {
            var h = f && YM.call(e, "__wrapped__"),
                p = l && YM.call(t, "__wrapped__");
            if (h || p) {
                var v = h ? e.value() : e,
                    y = p ? t.value() : t;
                return i || (i = new QS), o(v, y, r, n, i)
            }
        }
        return !!d && (i || (i = new QS), function(e, t, r, n, o, i) {
            var a = 1 & r,
                u = qA(e),
                s = u.length;
            if (s != qA(t).length && !a) return !1;
            for (var c = s; c--;) {
                var f = u[c];
                if (!(a ? f in t : VM.call(t, f))) return !1
            }
            var l = i.get(e),
                d = i.get(t);
            if (l && d) return l == t && d == e;
            var h = !0;
            i.set(e, t), i.set(t, e);
            for (var p = a; ++c < s;) {
                var v = e[f = u[c]],
                    y = t[f];
                if (n) var g = a ? n(y, v, f, t, e, i) : n(v, y, f, e, t, i);
                if (!(void 0 === g ? v === y || o(v, y, r, n, i) : g)) {
                    h = !1;
                    break
                }
                p || (p = "constructor" == f)
            }
            if (h && !p) {
                var b = e.constructor,
                    m = t.constructor;
                b == m || !("constructor" in e) || !("constructor" in t) || "function" == typeof b && b instanceof b && "function" == typeof m && m instanceof m || (h = !1)
            }
            return i.delete(e), i.delete(t), h
        }(e, t, r, n, o, i))
    }(e, t, r, n, GM, o))
}

function KM(e, t) {
    return GM(e, t)
}
var qM = [],
    $M = [];

function QM(e, t) {
    if (e && "undefined" != typeof document) {
        var r, n = !0 === t.prepend ? "prepend" : "append",
            o = !0 === t.singleTag,
            i = "string" == typeof t.container ? document.querySelector(t.container) : document.getElementsByTagName("head")[0];
        if (o) {
            var a = qM.indexOf(i); - 1 === a && (a = qM.push(i) - 1, $M[a] = {}), r = $M[a] && $M[a][n] ? $M[a][n] : $M[a][n] = u()
        } else r = u();
        65279 === e.charCodeAt(0) && (e = e.substring(1)), r.styleSheet ? r.styleSheet.cssText += e : r.appendChild(document.createTextNode(e))
    }

    function u() {
        var e = document.createElement("style");
        if (e.setAttribute("type", "text/css"), t.attributes)
            for (var r = Object.keys(t.attributes), o = 0; o < r.length; o++) e.setAttribute(r[o], t.attributes[r[o]]);
        var a = "prepend" === n ? "afterbegin" : "beforeend";
        return i.insertAdjacentElement(a, e), e
    }
}
const JM = e => "object" == typeof e && null !== e,
    ZM = Symbol("skip"),
    eD = e => JM(e) && !(e instanceof RegExp) && !(e instanceof Error) && !(e instanceof Date),
    tD = (e, t, r, n = new WeakMap) => {
        if (r = {
                deep: !1,
                target: {},
                ...r
            }, n.has(e)) return n.get(e);
        n.set(e, r.target);
        const {
            target: o
        } = r;
        delete r.target;
        const i = e => e.map(e => eD(e) ? tD(e, t, r, n) : e);
        if (Array.isArray(e)) return i(e);
        for (const [a, u] of Object.entries(e)) {
            const s = t(a, u, e);
            if (s === ZM) continue;
            let [c, f, {
                shouldRecurse: l = !0
            } = {}] = s;
            "__proto__" !== c && (r.deep && l && eD(f) && (f = Array.isArray(f) ? i(f) : tD(f, t, r, n)), o[c] = f)
        }
        return o
    };
var rD = (e, t, r) => {
    if (!JM(e)) throw new TypeError(`Expected an object, got \`${e}\` (${typeof e})`);
    return tD(e, t, r)
};
rD.mapObjectSkip = ZM;
var nD = function() {
    return nD = Object.assign || function(e) {
        for (var t, r = 1, n = arguments.length; r < n; r++)
            for (var o in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
        return e
    }, nD.apply(this, arguments)
};

function oD(e) {
    return e.toLowerCase()
}
"function" == typeof SuppressedError && SuppressedError;
var iD = [/([a-z0-9])([A-Z])/g, /([A-Z])([A-Z][a-z])/g],
    aD = /[^A-Z0-9]+/gi;

function uD(e, t, r) {
    return t instanceof RegExp ? e.replace(t, r) : t.reduce(function(e, t) {
        return e.replace(t, r)
    }, e)
}
var sD = Object.freeze({
        __proto__: null,
        snakeCase: function(e, t) {
            return void 0 === t && (t = {}),
                function(e, t) {
                    return void 0 === t && (t = {}),
                        function(e, t) {
                            void 0 === t && (t = {});
                            for (var r = t.splitRegexp, n = void 0 === r ? iD : r, o = t.stripRegexp, i = void 0 === o ? aD : o, a = t.transform, u = void 0 === a ? oD : a, s = t.delimiter, c = void 0 === s ? " " : s, f = uD(uD(e, n, "$1\0$2"), i, "\0"), l = 0, d = f.length;
                                "\0" === f.charAt(l);) l++;
                            for (;
                                "\0" === f.charAt(d - 1);) d--;
                            return f.slice(l, d).split("\0").map(u).join(c)
                        }(e, nD({
                            delimiter: "."
                        }, t))
                }(e, nD({
                    delimiter: "_"
                }, t))
        }
    }),
    cD = r(sD);
const {
    snakeCase: fD
} = cD;
var lD = function(e, t) {
    return t = Object.assign({
        deep: !0,
        exclude: [],
        parsingOptions: {}
    }, t), rD(e, function(e, r) {
        return [dD(t.exclude, e) ? e : fD(e, t.parsingOptions), r, hD(e, r, t)]
    }, t)
};

function dD(e, t) {
    return e.some(function(e) {
        return "string" == typeof e ? e === t : e.test(t)
    })
}

function hD(e, t, r) {
    return r.shouldRecurse ? {
        shouldRecurse: r.shouldRecurse(e, t)
    } : void 0
}
const pD = (e, t) => t.some(t => e instanceof t);
let vD, yD;
const gD = new WeakMap,
    bD = new WeakMap,
    mD = new WeakMap;
let wD = {
    get(e, t, r) {
        if (e instanceof IDBTransaction) {
            if ("done" === t) return gD.get(e);
            if ("store" === t) return r.objectStoreNames[1] ? void 0 : r.objectStore(r.objectStoreNames[0])
        }
        return TD(e[t])
    },
    set: (e, t, r) => (e[t] = r, !0),
    has: (e, t) => e instanceof IDBTransaction && ("done" === t || "store" === t) || t in e
};

function ED(e) {
    wD = e(wD)
}

function _D(e) {
    return "function" == typeof e ? function(e) {
        return (yD || (yD = [IDBCursor.prototype.advance, IDBCursor.prototype.continue, IDBCursor.prototype.continuePrimaryKey])).includes(e) ? function(...t) {
            return e.apply(SD(this), t), TD(this.request)
        } : function(...t) {
            return TD(e.apply(SD(this), t))
        }
    }(e) : (e instanceof IDBTransaction && function(e) {
        if (gD.has(e)) return;
        const t = new Promise((t, r) => {
            const n = () => {
                    e.removeEventListener("complete", o), e.removeEventListener("error", i), e.removeEventListener("abort", i)
                },
                o = () => {
                    t(), n()
                },
                i = () => {
                    r(e.error || new DOMException("AbortError", "AbortError")), n()
                };
            e.addEventListener("complete", o), e.addEventListener("error", i), e.addEventListener("abort", i)
        });
        gD.set(e, t)
    }(e), pD(e, vD || (vD = [IDBDatabase, IDBObjectStore, IDBIndex, IDBCursor, IDBTransaction])) ? new Proxy(e, wD) : e)
}

function TD(e) {
    if (e instanceof IDBRequest) return function(e) {
        const t = new Promise((t, r) => {
            const n = () => {
                    e.removeEventListener("success", o), e.removeEventListener("error", i)
                },
                o = () => {
                    t(TD(e.result)), n()
                },
                i = () => {
                    r(e.error), n()
                };
            e.addEventListener("success", o), e.addEventListener("error", i)
        });
        return mD.set(t, e), t
    }(e);
    if (bD.has(e)) return bD.get(e);
    const t = _D(e);
    return t !== e && (bD.set(e, t), mD.set(t, e)), t
}
const SD = e => mD.get(e);

function AD(e, t, {
    blocked: r,
    upgrade: n,
    blocking: o,
    terminated: i
} = {}) {
    const a = indexedDB.open(e, t),
        u = TD(a);
    return n && a.addEventListener("upgradeneeded", e => {
        n(TD(a.result), e.oldVersion, e.newVersion, TD(a.transaction), e)
    }), r && a.addEventListener("blocked", e => r(e.oldVersion, e.newVersion, e)), u.then(e => {
        i && e.addEventListener("close", () => i()), o && e.addEventListener("versionchange", e => o(e.oldVersion, e.newVersion, e))
    }).catch(() => {}), u
}
const ID = ["get", "getKey", "getAll", "getAllKeys", "count"],
    OD = ["put", "add", "delete", "clear"],
    RD = new Map;

function ND(e, t) {
    if (!(e instanceof IDBDatabase) || t in e || "string" != typeof t) return;
    if (RD.get(t)) return RD.get(t);
    const r = t.replace(/FromIndex$/, ""),
        n = t !== r,
        o = OD.includes(r);
    if (!(r in (n ? IDBIndex : IDBObjectStore).prototype) || !o && !ID.includes(r)) return;
    const i = async function(e, ...t) {
        const i = this.transaction(e, o ? "readwrite" : "readonly");
        let a = i.store;
        return n && (a = a.index(t.shift())), (await Promise.all([a[r](...t), o && i.done]))[0]
    };
    return RD.set(t, i), i
}
ED(e => ({ ...e,
    get: (t, r, n) => ND(t, r) || e.get(t, r, n),
    has: (t, r) => !!ND(t, r) || e.has(t, r)
}));
const PD = ["continue", "continuePrimaryKey", "advance"],
    MD = {},
    DD = new WeakMap,
    xD = new WeakMap,
    CD = {
        get(e, t) {
            if (!PD.includes(t)) return e[t];
            let r = MD[t];
            return r || (r = MD[t] = function(...e) {
                DD.set(this, xD.get(this)[t](...e))
            }), r
        }
    };
async function* kD(...e) {
    let t = this;
    if (t instanceof IDBCursor || (t = await t.openCursor(...e)), !t) return;
    const r = new Proxy(t, CD);
    for (xD.set(r, t), mD.set(r, SD(t)); t;) yield r, t = await (DD.get(r) || t.continue()), DD.delete(r)
}

function LD(e, t) {
    return t === Symbol.asyncIterator && pD(e, [IDBIndex, IDBObjectStore, IDBCursor]) || "iterate" === t && pD(e, [IDBIndex, IDBObjectStore])
}
ED(e => ({ ...e,
    get: (t, r, n) => LD(t, r) ? kD : e.get(t, r, n),
    has: (t, r) => LD(t, r) || e.has(t, r)
}));
var jD = t(function(e, t) {
    /*! For license information please see hls-parser.min.js.LICENSE.txt */
    self,
    e.exports = function() {
        return e = {
                851: (e, t, r) => {
                    var n = r(771),
                        o = n.getOptions,
                        i = n.setOptions,
                        a = r(463),
                        u = r(367),
                        s = r(890);
                    e.exports = {
                        parse: a,
                        stringify: u,
                        types: s,
                        getOptions: o,
                        setOptions: i
                    }
                },
                463: (e, t, r) => {
                    function n(e, t) {
                        var r;
                        if ("undefined" == typeof Symbol || null == e[Symbol.iterator]) {
                            if (Array.isArray(e) || (r = i(e)) || t && e && "number" == typeof e.length) {
                                r && (e = r);
                                var n = 0,
                                    o = function() {};
                                return {
                                    s: o,
                                    n: function() {
                                        return n >= e.length ? {
                                            done: !0
                                        } : {
                                            done: !1,
                                            value: e[n++]
                                        }
                                    },
                                    e: function(e) {
                                        throw e
                                    },
                                    f: o
                                }
                            }
                            throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                        }
                        var a, u = !0,
                            s = !1;
                        return {
                            s: function() {
                                r = e[Symbol.iterator]()
                            },
                            n: function() {
                                var e = r.next();
                                return u = e.done, e
                            },
                            e: function(e) {
                                s = !0, a = e
                            },
                            f: function() {
                                try {
                                    u || null == r.return || r.return()
                                } finally {
                                    if (s) throw a
                                }
                            }
                        }
                    }

                    function o(e, t) {
                        return function(e) {
                            if (Array.isArray(e)) return e
                        }(e) || function(e, t) {
                            if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) {
                                var r = [],
                                    n = !0,
                                    o = !1,
                                    i = void 0;
                                try {
                                    for (var a, u = e[Symbol.iterator](); !(n = (a = u.next()).done) && (r.push(a.value), !t || r.length !== t); n = !0);
                                } catch (e) {
                                    o = !0, i = e
                                } finally {
                                    try {
                                        n || null == u.return || u.return()
                                    } finally {
                                        if (o) throw i
                                    }
                                }
                                return r
                            }
                        }(e, t) || i(e, t) || function() {
                            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                        }()
                    }

                    function i(e, t) {
                        if (e) {
                            if ("string" == typeof e) return a(e, t);
                            var r = Object.prototype.toString.call(e).slice(8, -1);
                            return "Object" === r && e.constructor && (r = e.constructor.name), "Map" === r || "Set" === r ? Array.from(e) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? a(e, t) : void 0
                        }
                    }

                    function a(e, t) {
                        (null == t || t > e.length) && (t = e.length);
                        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
                        return n
                    }
                    var u = r(771),
                        s = r(890),
                        c = s.Rendition,
                        f = s.Variant,
                        l = s.SessionData,
                        d = s.Key,
                        h = s.MediaInitializationSection,
                        p = s.DateRange,
                        v = s.SpliceInfo,
                        y = s.MasterPlaylist,
                        g = s.MediaPlaylist,
                        b = s.Segment,
                        m = s.PartialSegment,
                        w = s.RenditionReport;

                    function E(e) {
                        return u.trim(e, '"')
                    }

                    function _(e) {
                        var t = u.splitAt(e, ",");
                        return {
                            duration: u.toNumber(t[0]),
                            title: decodeURIComponent(escape(t[1]))
                        }
                    }

                    function T(e) {
                        var t = u.splitAt(e, "@");
                        return {
                            length: u.toNumber(t[0]),
                            offset: t[1] ? u.toNumber(t[1]) : -1
                        }
                    }

                    function S(e, t) {
                        t.IV && e.compatibleVersion < 2 && (e.compatibleVersion = 2), (t.KEYFORMAT || t.KEYFORMATVERSIONS) && e.compatibleVersion < 5 && (e.compatibleVersion = 5)
                    }

                    function A(e) {
                        var t = u.splitByCommaWithPreservingQuotes(e),
                            r = {};
                        return t.forEach(function(e) {
                            var t, n, i = o(u.splitAt(e, "="), 2),
                                a = i[0],
                                s = i[1],
                                c = E(s);
                            switch (a) {
                                case "URI":
                                    r[a] = c;
                                    break;
                                case "START-DATE":
                                case "END-DATE":
                                    r[a] = new Date(c);
                                    break;
                                case "IV":
                                    r[a] = (t = c, 16 !== (n = u.hexToByteSequence(t)).length && u.INVALIDPLAYLIST("IV must be a 128-bit unsigned integer"), n);
                                    break;
                                case "BYTERANGE":
                                    r[a] = T(c);
                                    break;
                                case "RESOLUTION":
                                    r[a] = function(e) {
                                        var t = u.splitAt(e, "x");
                                        return {
                                            width: u.toNumber(t[0]),
                                            height: u.toNumber(t[1])
                                        }
                                    }(c);
                                    break;
                                case "END-ON-NEXT":
                                case "DEFAULT":
                                case "AUTOSELECT":
                                case "FORCED":
                                case "PRECISE":
                                case "CAN-BLOCK-RELOAD":
                                case "INDEPENDENT":
                                case "GAP":
                                    r[a] = "YES" === c;
                                    break;
                                case "DURATION":
                                case "PLANNED-DURATION":
                                case "BANDWIDTH":
                                case "AVERAGE-BANDWIDTH":
                                case "FRAME-RATE":
                                case "TIME-OFFSET":
                                case "CAN-SKIP-UNTIL":
                                case "HOLD-BACK":
                                case "PART-HOLD-BACK":
                                case "PART-TARGET":
                                case "BYTERANGE-START":
                                case "BYTERANGE-LENGTH":
                                case "LAST-MSN":
                                case "LAST-PART":
                                case "SKIPPED-SEGMENTS":
                                    r[a] = u.toNumber(c);
                                    break;
                                default:
                                    a.startsWith("SCTE35-") ? r[a] = u.hexToByteSequence(c) : a.startsWith("X-") ? r[a] = function(e) {
                                        return e.startsWith('"') ? E(e) : e.startsWith("0x") || e.startsWith("0X") ? u.hexToByteSequence(e) : u.toNumber(e)
                                    }(s) : r[a] = c
                            }
                        }), r
                    }

                    function I() {
                        u.INVALIDPLAYLIST("The file contains both media and master playlist tags.")
                    }

                    function O(e, t, r) {
                        var o, i = (o = t.attributes, new c({
                                type: o.TYPE,
                                uri: o.URI,
                                groupId: o["GROUP-ID"],
                                language: o.LANGUAGE,
                                assocLanguage: o["ASSOC-LANGUAGE"],
                                name: o.NAME,
                                isDefault: o.DEFAULT,
                                autoselect: o.AUTOSELECT,
                                forced: o.FORCED,
                                instreamId: o["INSTREAM-ID"],
                                characteristics: o.CHARACTERISTICS,
                                channels: o.CHANNELS
                            })),
                            a = e[u.camelify(r)],
                            s = function(e, t) {
                                var r, o = !1,
                                    i = n(e);
                                try {
                                    for (i.s(); !(r = i.n()).done;) {
                                        var a = r.value;
                                        if (a.name === t.name) return "All EXT-X-MEDIA tags in the same Group MUST have different NAME attributes.";
                                        a.isDefault && (o = !0)
                                    }
                                } catch (e) {
                                    i.e(e)
                                } finally {
                                    i.f()
                                }
                                return o && t.isDefault ? "EXT-X-MEDIA A Group MUST NOT have more than one member with a DEFAULT attribute of YES." : ""
                            }(a, i);
                        s && u.INVALIDPLAYLIST(s), a.push(i), i.isDefault && (e.currentRenditions[u.camelify(r)] = a.length - 1)
                    }

                    function R(e, t, r, o, i) {
                        var a, s = new f({
                                uri: r,
                                bandwidth: t.BANDWIDTH,
                                averageBandwidth: t["AVERAGE-BANDWIDTH"],
                                codecs: t.CODECS,
                                resolution: t.RESOLUTION,
                                frameRate: t["FRAME-RATE"],
                                hdcpLevel: t["HDCP-LEVEL"]
                            }),
                            c = n(e);
                        try {
                            for (c.s(); !(a = c.n()).done;) {
                                var l = a.value;
                                if ("EXT-X-MEDIA" === l.name) {
                                    var d = l.attributes,
                                        h = d.TYPE;
                                    if (h && d["GROUP-ID"] || u.INVALIDPLAYLIST("EXT-X-MEDIA TYPE attribute is REQUIRED."), t[h] === d["GROUP-ID"] && (O(s, l, h), "CLOSED-CAPTIONS" === h)) {
                                        var p, v = n(s.closedCaptions);
                                        try {
                                            for (v.s(); !(p = v.n()).done;) {
                                                var y = p.value.instreamId;
                                                if (y && y.startsWith("SERVICE") && i.compatibleVersion < 7) {
                                                    i.compatibleVersion = 7;
                                                    break
                                                }
                                            }
                                        } catch (e) {
                                            v.e(e)
                                        } finally {
                                            v.f()
                                        }
                                    }
                                }
                            }
                        } catch (e) {
                            c.e(e)
                        } finally {
                            c.f()
                        }
                        return function(e, t, r) {
                            ["AUDIO", "VIDEO", "SUBTITLES", "CLOSED-CAPTIONS"].forEach(function(n) {
                                "CLOSED-CAPTIONS" === n && "NONE" === e[n] ? (r.isClosedCaptionsNone = !0, t.closedCaptions = []) : e[n] && !t[u.camelify(n)].find(function(t) {
                                    return t.groupId === e[n]
                                }) && u.INVALIDPLAYLIST("".concat(n, " attribute MUST match the value of the GROUP-ID attribute of an EXT-X-MEDIA tag whose TYPE attribute is ").concat(n, "."))
                            })
                        }(t, s, i), s.isIFrameOnly = o, s
                    }

                    function N(e, t) {
                        if (e.method !== t.method) return !1;
                        if (e.uri !== t.uri) return !1;
                        if (e.iv) {
                            if (!t.iv) return !1;
                            if (e.iv.length !== t.iv.length) return !1;
                            for (var r = 0; r < e.iv.length; r++)
                                if (e.iv[r] !== t.iv[r]) return !1
                        } else if (t.iv) return !1;
                        return e.format === t.format && e.formatVersion === t.formatVersion
                    }

                    function P(e, t, r, n, o, i, a) {
                        for (var s = new b({
                                uri: t,
                                mediaSequenceNumber: o,
                                discontinuitySequence: i
                            }), c = !1, f = !1, l = function(t) {
                                var r = e[t],
                                    n = r.name,
                                    o = r.value,
                                    i = r.attributes;
                                if ("EXTINF" === n) !Number.isInteger(o.duration) && a.compatibleVersion < 3 && (a.compatibleVersion = 3), Math.round(o.duration) > a.targetDuration && u.INVALIDPLAYLIST("EXTINF duration, when rounded to the nearest integer, MUST be less than or equal to the target duration"), s.duration = o.duration, s.title = o.title;
                                else if ("EXT-X-BYTERANGE" === n) a.compatibleVersion < 4 && (a.compatibleVersion = 4), s.byterange = o;
                                else if ("EXT-X-DISCONTINUITY" === n) s.parts.length > 0 && u.INVALIDPLAYLIST("EXT-X-DISCONTINUITY must appear before the first EXT-X-PART tag of the Parent Segment."), s.discontinuity = !0;
                                else if ("EXT-X-KEY" === n) s.parts.length > 0 && u.INVALIDPLAYLIST("EXT-X-KEY must appear before the first EXT-X-PART tag of the Parent Segment."), S(a, i), s.key = new d({
                                    method: i.METHOD,
                                    uri: i.URI,
                                    iv: i.IV,
                                    format: i.KEYFORMAT,
                                    formatVersion: i.KEYFORMATVERSIONS
                                });
                                else if ("EXT-X-MAP" === n) s.parts.length > 0 && u.INVALIDPLAYLIST("EXT-X-MAP must appear before the first EXT-X-PART tag of the Parent Segment."), a.compatibleVersion < 5 && (a.compatibleVersion = 5), a.hasMap = !0, s.map = new h({
                                    uri: i.URI,
                                    byterange: i.BYTERANGE
                                });
                                else if ("EXT-X-PROGRAM-DATE-TIME" === n) s.programDateTime = o;
                                else if ("EXT-X-DATERANGE" === n) {
                                    var l = {};
                                    Object.keys(i).forEach(function(e) {
                                        (e.startsWith("SCTE35-") || e.startsWith("X-")) && (l[e] = i[e])
                                    }), s.dateRange = new p({
                                        id: i.ID,
                                        classId: i.CLASS,
                                        start: i["START-DATE"],
                                        end: i["END-DATE"],
                                        duration: i.DURATION,
                                        plannedDuration: i["PLANNED-DURATION"],
                                        endOnNext: i["END-ON-NEXT"],
                                        attributes: l
                                    })
                                } else if ("EXT-X-CUE-OUT" === n) s.markers.push(new v({
                                    type: "OUT",
                                    duration: o
                                }));
                                else if ("EXT-X-CUE-IN" === n) s.markers.push(new v({
                                    type: "IN"
                                }));
                                else if ("EXT-X-CUE-OUT-CONT" === n || "EXT-X-CUE" === n || "EXT-OATCLS-SCTE35" === n || "EXT-X-ASSET" === n || "EXT-X-SCTE35" === n) s.markers.push(new v({
                                    type: "RAW",
                                    tagName: n,
                                    value: o
                                }));
                                else if ("EXT-X-PRELOAD-HINT" !== n || i.TYPE)
                                    if ("EXT-X-PRELOAD-HINT" === n && "PART" === i.TYPE && f) u.INVALIDPLAYLIST("Servers should not add more than one EXT-X-PRELOAD-HINT tag with the same TYPE attribute to a Playlist.");
                                    else if ("EXT-X-PART" !== n && "EXT-X-PRELOAD-HINT" !== n || i.URI) {
                                    if ("EXT-X-PRELOAD-HINT" === n && "MAP" === i.TYPE) c && u.INVALIDPLAYLIST("Servers should not add more than one EXT-X-PRELOAD-HINT tag with the same TYPE attribute to a Playlist."), c = !0, a.hasMap = !0, s.map = new h({
                                        hint: !0,
                                        uri: i.URI,
                                        byterange: {
                                            length: i["BYTERANGE-LENGTH"],
                                            offset: i["BYTERANGE-START"] || 0
                                        }
                                    });
                                    else if ("EXT-X-PART" === n || "EXT-X-PRELOAD-HINT" === n && "PART" === i.TYPE) {
                                        "EXT-X-PART" !== n || i.DURATION || u.INVALIDPLAYLIST("EXT-X-PART: DURATION attribute is mandatory"), "EXT-X-PRELOAD-HINT" === n && (f = !0);
                                        var y = new m({
                                            hint: "EXT-X-PRELOAD-HINT" === n,
                                            uri: i.URI,
                                            byterange: "EXT-X-PART" === n ? i.BYTERANGE : {
                                                length: i["BYTERANGE-LENGTH"],
                                                offset: i["BYTERANGE-START"] || 0
                                            },
                                            duration: i.DURATION,
                                            independent: i.INDEPENDENT,
                                            gap: i.GAP
                                        });
                                        s.parts.push(y)
                                    }
                                } else u.INVALIDPLAYLIST("EXT-X-PART / EXT-X-PRELOAD-HINT: URI attribute is mandatory");
                                else u.INVALIDPLAYLIST("EXT-X-PRELOAD-HINT: TYPE attribute is mandatory")
                            }, y = r; y <= n; y++) l(y);
                        return s
                    }

                    function M(e, t, r, n, o) {
                        var i = t.discontinuity,
                            a = t.key,
                            s = t.map,
                            c = t.byterange,
                            f = t.uri;
                        if (i && (t.discontinuitySequence = r + 1), a || (t.key = n), s || (t.map = o), c && -1 === c.offset) {
                            var l = e.segments;
                            if (l.length > 0) {
                                var d = l[l.length - 1];
                                d.byterange && d.uri === f ? c.offset = d.byterange.offset + d.byterange.length : u.INVALIDPLAYLIST("If offset of EXT-X-BYTERANGE is not present, a previous Media Segment MUST be a sub-range of the same media resource")
                            } else u.INVALIDPLAYLIST("If offset of EXT-X-BYTERANGE is not present, a previous Media Segment MUST appear in the Playlist file")
                        }
                        return e.segments.push(t), [t.discontinuitySequence, t.key, t.map]
                    }

                    function D(e, t) {
                        var r = o(function(e) {
                                var t = e.indexOf(":");
                                return -1 === t ? [e.slice(1).trim(), null] : [e.slice(1, t).trim(), e.slice(t + 1).trim()]
                            }(e), 2),
                            n = r[0],
                            i = r[1],
                            a = function(e) {
                                switch (e) {
                                    case "EXTM3U":
                                    case "EXT-X-VERSION":
                                        return "Basic";
                                    case "EXTINF":
                                    case "EXT-X-BYTERANGE":
                                    case "EXT-X-DISCONTINUITY":
                                    case "EXT-X-KEY":
                                    case "EXT-X-MAP":
                                    case "EXT-X-PROGRAM-DATE-TIME":
                                    case "EXT-X-DATERANGE":
                                    case "EXT-X-CUE-OUT":
                                    case "EXT-X-CUE-IN":
                                    case "EXT-X-CUE-OUT-CONT":
                                    case "EXT-X-CUE":
                                    case "EXT-OATCLS-SCTE35":
                                    case "EXT-X-ASSET":
                                    case "EXT-X-SCTE35":
                                    case "EXT-X-PART":
                                    case "EXT-X-PRELOAD-HINT":
                                        return "Segment";
                                    case "EXT-X-TARGETDURATION":
                                    case "EXT-X-MEDIA-SEQUENCE":
                                    case "EXT-X-DISCONTINUITY-SEQUENCE":
                                    case "EXT-X-ENDLIST":
                                    case "EXT-X-PLAYLIST-TYPE":
                                    case "EXT-X-I-FRAMES-ONLY":
                                    case "EXT-X-SERVER-CONTROL":
                                    case "EXT-X-PART-INF":
                                    case "EXT-X-RENDITION-REPORT":
                                    case "EXT-X-SKIP":
                                        return "MediaPlaylist";
                                    case "EXT-X-MEDIA":
                                    case "EXT-X-STREAM-INF":
                                    case "EXT-X-I-FRAME-STREAM-INF":
                                    case "EXT-X-SESSION-DATA":
                                    case "EXT-X-SESSION-KEY":
                                        return "MasterPlaylist";
                                    case "EXT-X-INDEPENDENT-SEGMENTS":
                                    case "EXT-X-START":
                                        return "MediaorMasterPlaylist";
                                    default:
                                        return "Unknown"
                                }
                            }(n);
                        if (function(e, t) {
                                if ("Segment" === e || "MediaPlaylist" === e) return void 0 === t.isMasterPlaylist ? void(t.isMasterPlaylist = !1) : void(t.isMasterPlaylist && I());
                                if ("MasterPlaylist" === e) {
                                    if (void 0 === t.isMasterPlaylist) return void(t.isMasterPlaylist = !0);
                                    !1 === t.isMasterPlaylist && I()
                                }
                            }(a, t), "Unknown" === a) return null;
                        "MediaPlaylist" === a && "EXT-X-RENDITION-REPORT" !== n && (t.hash[n] && u.INVALIDPLAYLIST("There MUST NOT be more than one Media Playlist tag of each type in any Media Playlist"), t.hash[n] = !0);
                        var s = o(function(e, t) {
                            switch (e) {
                                case "EXTM3U":
                                case "EXT-X-DISCONTINUITY":
                                case "EXT-X-ENDLIST":
                                case "EXT-X-I-FRAMES-ONLY":
                                case "EXT-X-INDEPENDENT-SEGMENTS":
                                case "EXT-X-CUE-IN":
                                    return [null, null];
                                case "EXT-X-VERSION":
                                case "EXT-X-TARGETDURATION":
                                case "EXT-X-MEDIA-SEQUENCE":
                                case "EXT-X-DISCONTINUITY-SEQUENCE":
                                case "EXT-X-CUE-OUT":
                                    return [u.toNumber(t), null];
                                case "EXT-X-KEY":
                                case "EXT-X-MAP":
                                case "EXT-X-DATERANGE":
                                case "EXT-X-MEDIA":
                                case "EXT-X-STREAM-INF":
                                case "EXT-X-I-FRAME-STREAM-INF":
                                case "EXT-X-SESSION-DATA":
                                case "EXT-X-SESSION-KEY":
                                case "EXT-X-START":
                                case "EXT-X-SERVER-CONTROL":
                                case "EXT-X-PART-INF":
                                case "EXT-X-PART":
                                case "EXT-X-PRELOAD-HINT":
                                case "EXT-X-RENDITION-REPORT":
                                case "EXT-X-SKIP":
                                    return [null, A(t)];
                                case "EXTINF":
                                    return [_(t), null];
                                case "EXT-X-BYTERANGE":
                                    return [T(t), null];
                                case "EXT-X-PROGRAM-DATE-TIME":
                                    return [new Date(t), null];
                                default:
                                    return [t, null]
                            }
                        }(n, i), 2);
                        return {
                            name: n,
                            category: a,
                            value: s[0],
                            attributes: s[1]
                        }
                    }

                    function x(e, t) {
                        var r;
                        return t.isMasterPlaylist ? r = function(e, t) {
                            var r, i = new y,
                                a = n(e.entries());
                            try {
                                for (a.s(); !(r = a.n()).done;) {
                                    var s = o(r.value, 2),
                                        c = s[0],
                                        f = s[1],
                                        h = f.name,
                                        p = f.value,
                                        v = f.attributes;
                                    if ("EXT-X-VERSION" === h) i.version = p;
                                    else if ("EXT-X-STREAM-INF" === h) {
                                        var g = e[c + 1];
                                        ("string" != typeof g || g.startsWith("#EXT")) && u.INVALIDPLAYLIST("EXT-X-STREAM-INF must be followed by a URI line");
                                        var b = R(e, v, g, !1, t);
                                        b && i.variants.push(b)
                                    } else if ("EXT-X-I-FRAME-STREAM-INF" === h) {
                                        var m = R(e, v, v.URI, !0, t);
                                        m && i.variants.push(m)
                                    } else "EXT-X-SESSION-DATA" === h ? function() {
                                        var e = new l({
                                            id: v["DATA-ID"],
                                            value: v.VALUE,
                                            uri: v.URI,
                                            language: v.LANGUAGE
                                        });
                                        i.sessionDataList.find(function(t) {
                                            return t.id === e.id && t.language === e.language
                                        }) && u.INVALIDPLAYLIST("A Playlist MUST NOT contain more than one EXT-X-SESSION-DATA tag with the same DATA-ID attribute and the same LANGUAGE attribute."), i.sessionDataList.push(e)
                                    }() : "EXT-X-SESSION-KEY" === h ? function() {
                                        "NONE" === v.METHOD && u.INVALIDPLAYLIST("EXT-X-SESSION-KEY: The value of the METHOD attribute MUST NOT be NONE");
                                        var e = new d({
                                            method: v.METHOD,
                                            uri: v.URI,
                                            iv: v.IV,
                                            format: v.KEYFORMAT,
                                            formatVersion: v.KEYFORMATVERSIONS
                                        });
                                        i.sessionKeyList.find(function(t) {
                                            return N(t, e)
                                        }) && u.INVALIDPLAYLIST("A Master Playlist MUST NOT contain more than one EXT-X-SESSION-KEY tag with the same METHOD, URI, IV, KEYFORMAT, and KEYFORMATVERSIONS attribute values."), S(t, v), i.sessionKeyList.push(e)
                                    }() : "EXT-X-INDEPENDENT-SEGMENTS" === h ? (i.independentSegments && u.INVALIDPLAYLIST("EXT-X-INDEPENDENT-SEGMENTS tag MUST NOT appear more than once in a Playlist"), i.independentSegments = !0) : "EXT-X-START" === h && (i.start && u.INVALIDPLAYLIST("EXT-X-START tag MUST NOT appear more than once in a Playlist"), "number" != typeof v["TIME-OFFSET"] && u.INVALIDPLAYLIST("EXT-X-START: TIME-OFFSET attribute is REQUIRED"), i.start = {
                                        offset: v["TIME-OFFSET"],
                                        precise: v.PRECISE || !1
                                    })
                                }
                            } catch (e) {
                                a.e(e)
                            } finally {
                                a.f()
                            }
                            if (t.isClosedCaptionsNone) {
                                var w, E = n(i.variants);
                                try {
                                    for (E.s(); !(w = E.n()).done;) w.value.closedCaptions.length > 0 && u.INVALIDPLAYLIST("If there is a variant with CLOSED-CAPTIONS attribute of NONE, all EXT-X-STREAM-INF tags MUST have this attribute with a value of NONE")
                                } catch (e) {
                                    E.e(e)
                                } finally {
                                    E.f()
                                }
                            }
                            return i
                        }(e, t) : !(r = function(e, t) {
                            var r, i = new g,
                                a = -1,
                                s = 0,
                                c = !1,
                                f = 0,
                                l = null,
                                d = null,
                                h = !1,
                                p = n(e.entries());
                            try {
                                for (p.s(); !(r = p.n()).done;) {
                                    var v = o(r.value, 2),
                                        y = v[0],
                                        b = v[1],
                                        m = b.name,
                                        E = b.value,
                                        _ = b.attributes;
                                    if ("Segment" !== b.category) {
                                        if ("EXT-X-VERSION" === m) void 0 === i.version ? i.version = E : u.INVALIDPLAYLIST("A Playlist file MUST NOT contain more than one EXT-X-VERSION tag.");
                                        else if ("EXT-X-TARGETDURATION" === m) i.targetDuration = t.targetDuration = E;
                                        else if ("EXT-X-MEDIA-SEQUENCE" === m) i.segments.length > 0 && u.INVALIDPLAYLIST("The EXT-X-MEDIA-SEQUENCE tag MUST appear before the first Media Segment in the Playlist."), i.mediaSequenceBase = s = E;
                                        else if ("EXT-X-DISCONTINUITY-SEQUENCE" === m) i.segments.length > 0 && u.INVALIDPLAYLIST("The EXT-X-DISCONTINUITY-SEQUENCE tag MUST appear before the first Media Segment in the Playlist."), c && u.INVALIDPLAYLIST("The EXT-X-DISCONTINUITY-SEQUENCE tag MUST appear before any EXT-X-DISCONTINUITY tag."), i.discontinuitySequenceBase = f = E;
                                        else if ("EXT-X-ENDLIST" === m) i.endlist = !0;
                                        else if ("EXT-X-PLAYLIST-TYPE" === m) i.playlistType = E;
                                        else if ("EXT-X-I-FRAMES-ONLY" === m) t.compatibleVersion < 4 && (t.compatibleVersion = 4), i.isIFrame = !0;
                                        else if ("EXT-X-INDEPENDENT-SEGMENTS" === m) i.independentSegments && u.INVALIDPLAYLIST("EXT-X-INDEPENDENT-SEGMENTS tag MUST NOT appear more than once in a Playlist"), i.independentSegments = !0;
                                        else if ("EXT-X-START" === m) i.start && u.INVALIDPLAYLIST("EXT-X-START tag MUST NOT appear more than once in a Playlist"), "number" != typeof _["TIME-OFFSET"] && u.INVALIDPLAYLIST("EXT-X-START: TIME-OFFSET attribute is REQUIRED"), i.start = {
                                            offset: _["TIME-OFFSET"],
                                            precise: _.PRECISE || !1
                                        };
                                        else if ("EXT-X-SERVER-CONTROL" === m) _["CAN-BLOCK-RELOAD"] || u.INVALIDPLAYLIST("EXT-X-SERVER-CONTROL: CAN-BLOCK-RELOAD=YES is mandatory for Low-Latency HLS"), i.lowLatencyCompatibility = {
                                            canBlockReload: _["CAN-BLOCK-RELOAD"],
                                            canSkipUntil: _["CAN-SKIP-UNTIL"],
                                            holdBack: _["HOLD-BACK"],
                                            partHoldBack: _["PART-HOLD-BACK"]
                                        };
                                        else if ("EXT-X-PART-INF" === m) _["PART-TARGET"] || u.INVALIDPLAYLIST("EXT-X-PART-INF: PART-TARGET attribute is mandatory"), i.partTargetDuration = _["PART-TARGET"];
                                        else if ("EXT-X-RENDITION-REPORT" === m) _.URI || u.INVALIDPLAYLIST("EXT-X-RENDITION-REPORT: URI attribute is mandatory"), 0 === _.URI.search(/^[a-z]+:/) && u.INVALIDPLAYLIST("EXT-X-RENDITION-REPORT: URI must be relative to the playlist uri"), i.renditionReports.push(new w({
                                            uri: _.URI,
                                            lastMSN: _["LAST-MSN"],
                                            lastPart: _["LAST-PART"]
                                        }));
                                        else if ("EXT-X-SKIP" === m) _["SKIPPED-SEGMENTS"] || u.INVALIDPLAYLIST("EXT-X-SKIP: SKIPPED-SEGMENTS attribute is mandatory"), t.compatibleVersion < 9 && (t.compatibleVersion = 9), i.skip = _["SKIPPED-SEGMENTS"], s += i.skip;
                                        else if ("string" == typeof b) {
                                            -1 === a && u.INVALIDPLAYLIST("A URI line is not preceded by any segment tags"), i.targetDuration || u.INVALIDPLAYLIST("The EXT-X-TARGETDURATION tag is REQUIRED");
                                            var T = P(e, b, a, y - 1, s++, f, t);
                                            if (T) {
                                                var S = o(M(i, T, f, l, d), 3);
                                                f = S[0], l = S[1], d = S[2], !h && T.parts.length > 0 && (h = !0)
                                            }
                                            a = -1
                                        }
                                    } else -1 === a && (a = y), "EXT-X-DISCONTINUITY" === m && (c = !0)
                                }
                            } catch (e) {
                                p.e(e)
                            } finally {
                                p.f()
                            }
                            if (-1 !== a) {
                                var A = P(e, "", a, e.length - 1, s++, f, t);
                                if (A) {
                                    var I = A.parts;
                                    I.length > 0 && !i.endlist && !I[I.length - 1].hint && u.INVALIDPLAYLIST("If the Playlist contains EXT-X-PART tags and does not contain an EXT-X-ENDLIST tag, the Playlist must contain an EXT-X-PRELOAD-HINT tag with a TYPE=PART attribute"), M(i, A, l, d), !h && A.parts.length > 0 && (h = !0)
                                }
                            }
                            return function(e) {
                                for (var t = new Map, r = new Map, o = !1, i = !1, a = e.length - 1; a >= 0; a--) {
                                    var s = e[a],
                                        c = s.programDateTime,
                                        f = s.dateRange;
                                    if (c && (i = !0), f && f.start) {
                                        o = !0, f.endOnNext && (f.end || f.duration) && u.INVALIDPLAYLIST("An EXT-X-DATERANGE tag with an END-ON-NEXT=YES attribute MUST NOT contain DURATION or END-DATE attributes.");
                                        var l = f.start.getTime(),
                                            d = f.duration || 0;
                                        f.end && f.duration && l + 1e3 * d !== f.end.getTime() && u.INVALIDPLAYLIST("END-DATE MUST be equal to the value of the START-DATE attribute plus the value of the DURATION"), f.endOnNext && (f.end = t.get(f.classId)), t.set(f.classId, f.start);
                                        var h = f.end ? f.end.getTime() : f.start.getTime() + 1e3 * (f.duration || 0),
                                            p = r.get(f.classId);
                                        if (p) {
                                            var v, y = n(p);
                                            try {
                                                for (y.s(); !(v = y.n()).done;) {
                                                    var g = v.value;
                                                    (g.start <= l && g.end > l || g.start >= l && g.start < h) && u.INVALIDPLAYLIST("DATERANGE tags with the same CLASS should not overlap")
                                                }
                                            } catch (e) {
                                                y.e(e)
                                            } finally {
                                                y.f()
                                            }
                                            p.push({
                                                start: l,
                                                end: h
                                            })
                                        } else r.set(f.classId, [{
                                            start: l,
                                            end: h
                                        }])
                                    }
                                }
                                o && !i && u.INVALIDPLAYLIST("If a Playlist contains an EXT-X-DATERANGE tag, it MUST also contain at least one EXT-X-PROGRAM-DATE-TIME tag.")
                            }(i.segments), i.lowLatencyCompatibility && function(e, t) {
                                var r = e.lowLatencyCompatibility,
                                    i = e.targetDuration,
                                    a = e.partTargetDuration,
                                    s = e.segments,
                                    c = e.renditionReports,
                                    f = r.canSkipUntil,
                                    l = r.holdBack,
                                    d = r.partHoldBack;
                                if (f < 6 * i && u.INVALIDPLAYLIST("The Skip Boundary must be at least six times the EXT-X-TARGETDURATION."), l < 3 * i && u.INVALIDPLAYLIST("HOLD-BACK must be at least three times the EXT-X-TARGETDURATION."), t) {
                                    void 0 === a && u.INVALIDPLAYLIST("EXT-X-PART-INF is required if a Playlist contains one or more EXT-X-PART tags"), void 0 === d && u.INVALIDPLAYLIST("EXT-X-PART: PART-HOLD-BACK attribute is mandatory"), d < a && u.INVALIDPLAYLIST("PART-HOLD-BACK must be at least PART-TARGET");
                                    var h, p = n(s.entries());
                                    try {
                                        for (p.s(); !(h = p.n()).done;) {
                                            var v = o(h.value, 2),
                                                y = v[0],
                                                g = v[1].parts;
                                            g.length > 0 && y < s.length - 3 && u.INVALIDPLAYLIST("Remove EXT-X-PART tags from the Playlist after they are greater than three target durations from the end of the Playlist.");
                                            var b, m = n(g.entries());
                                            try {
                                                for (m.s(); !(b = m.n()).done;) {
                                                    var w = o(b.value, 2),
                                                        E = w[0],
                                                        _ = w[1].duration;
                                                    void 0 !== _ && (_ > a && u.INVALIDPLAYLIST("PART-TARGET is the maximum duration of any Partial Segment"), E < g.length - 1 && _ < .85 * a && u.INVALIDPLAYLIST("All Partial Segments except the last part of a segment must have a duration of at least 85% of PART-TARGET"))
                                                }
                                            } catch (e) {
                                                m.e(e)
                                            } finally {
                                                m.f()
                                            }
                                        }
                                    } catch (e) {
                                        p.e(e)
                                    } finally {
                                        p.f()
                                    }
                                }
                                var T, S = n(c);
                                try {
                                    for (S.s(); !(T = S.n()).done;) {
                                        var A = T.value,
                                            I = s[s.length - 1];
                                        A.lastMSN || (A.lastMSN = I.mediaSequenceNumber), !A.lastPart && I.parts.length > 0 && (A.lastPart = I.parts.length - 1)
                                    }
                                } catch (e) {
                                    S.e(e)
                                } finally {
                                    S.f()
                                }
                            }(i, h), i
                        }(e, t)).isIFrame && t.hasMap && t.compatibleVersion < 6 && (t.compatibleVersion = 6), t.compatibleVersion > 1 && (!r.version || r.version < t.compatibleVersion) && u.INVALIDPLAYLIST("EXT-X-VERSION needs to be ".concat(t.compatibleVersion, " or higher.")), r
                    }
                    e.exports = function(e) {
                        var t = {
                                version: void 0,
                                isMasterPlaylist: void 0,
                                hasMap: !1,
                                targetDuration: 0,
                                compatibleVersion: 1,
                                isClosedCaptionsNone: !1,
                                hash: {}
                            },
                            r = x(function(e, t) {
                                var r = [];
                                return e.split("\n").forEach(function(e) {
                                    var n = e.trim();
                                    if (n)
                                        if (n.startsWith("#")) {
                                            if (n.startsWith("#EXT")) {
                                                var o = D(n, t);
                                                return void(o && r.push(o))
                                            }
                                        } else r.push(n)
                                }), 0 !== r.length && "EXTM3U" === r[0].name || u.INVALIDPLAYLIST("The EXTM3U tag MUST be the first line."), r
                            }(e, t), t);
                        return r.source = e, r
                    }
                },
                367: (e, t, r) => {
                    function n(e) {
                        return (n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                            return typeof e
                        } : function(e) {
                            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                        })(e)
                    }

                    function o(e, t) {
                        return function(e) {
                            if (Array.isArray(e)) return e
                        }(e) || function(e, t) {
                            if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) {
                                var r = [],
                                    n = !0,
                                    o = !1,
                                    i = void 0;
                                try {
                                    for (var a, u = e[Symbol.iterator](); !(n = (a = u.next()).done) && (r.push(a.value), !t || r.length !== t); n = !0);
                                } catch (e) {
                                    o = !0, i = e
                                } finally {
                                    try {
                                        n || null == u.return || u.return()
                                    } finally {
                                        if (o) throw i
                                    }
                                }
                                return r
                            }
                        }(e, t) || a(e, t) || function() {
                            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                        }()
                    }

                    function i(e, t) {
                        var r;
                        if ("undefined" == typeof Symbol || null == e[Symbol.iterator]) {
                            if (Array.isArray(e) || (r = a(e)) || t && e && "number" == typeof e.length) {
                                r && (e = r);
                                var n = 0,
                                    o = function() {};
                                return {
                                    s: o,
                                    n: function() {
                                        return n >= e.length ? {
                                            done: !0
                                        } : {
                                            done: !1,
                                            value: e[n++]
                                        }
                                    },
                                    e: function(e) {
                                        throw e
                                    },
                                    f: o
                                }
                            }
                            throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                        }
                        var i, u = !0,
                            s = !1;
                        return {
                            s: function() {
                                r = e[Symbol.iterator]()
                            },
                            n: function() {
                                var e = r.next();
                                return u = e.done, e
                            },
                            e: function(e) {
                                s = !0, i = e
                            },
                            f: function() {
                                try {
                                    u || null == r.return || r.return()
                                } finally {
                                    if (s) throw i
                                }
                            }
                        }
                    }

                    function a(e, t) {
                        if (e) {
                            if ("string" == typeof e) return u(e, t);
                            var r = Object.prototype.toString.call(e).slice(8, -1);
                            return "Object" === r && e.constructor && (r = e.constructor.name), "Map" === r || "Set" === r ? Array.from(e) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? u(e, t) : void 0
                        }
                    }

                    function u(e, t) {
                        (null == t || t > e.length) && (t = e.length);
                        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
                        return n
                    }

                    function s(e, t, r) {
                        return (s = "undefined" != typeof Reflect && Reflect.get ? Reflect.get : function(e, t, r) {
                            var n = function(e, t) {
                                for (; !Object.prototype.hasOwnProperty.call(e, t) && null !== (e = p(e)););
                                return e
                            }(e, t);
                            if (n) {
                                var o = Object.getOwnPropertyDescriptor(n, t);
                                return o.get ? o.get.call(r) : o.value
                            }
                        })(e, t, r || e)
                    }

                    function c(e, t) {
                        return !t || "object" !== n(t) && "function" != typeof t ? function(e) {
                            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                            return e
                        }(e) : t
                    }

                    function f(e) {
                        var t = "function" == typeof Map ? new Map : void 0;
                        return (f = function(e) {
                            if (null === e || (r = e, -1 === Function.toString.call(r).indexOf("[native code]"))) return e;
                            var r;
                            if ("function" != typeof e) throw new TypeError("Super expression must either be null or a function");
                            if (void 0 !== t) {
                                if (t.has(e)) return t.get(e);
                                t.set(e, n)
                            }

                            function n() {
                                return l(e, arguments, p(this).constructor)
                            }
                            return n.prototype = Object.create(e.prototype, {
                                constructor: {
                                    value: n,
                                    enumerable: !1,
                                    writable: !0,
                                    configurable: !0
                                }
                            }), h(n, e)
                        })(e)
                    }

                    function l(e, t, r) {
                        return (l = d() ? Reflect.construct : function(e, t, r) {
                            var n = [null];
                            n.push.apply(n, t);
                            var o = new(Function.bind.apply(e, n));
                            return r && h(o, r.prototype), o
                        }).apply(null, arguments)
                    }

                    function d() {
                        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                        if (Reflect.construct.sham) return !1;
                        if ("function" == typeof Proxy) return !0;
                        try {
                            return Date.prototype.toString.call(Reflect.construct(Date, [], function() {})), !0
                        } catch (e) {
                            return !1
                        }
                    }

                    function h(e, t) {
                        return (h = Object.setPrototypeOf || function(e, t) {
                            return e.__proto__ = t, e
                        })(e, t)
                    }

                    function p(e) {
                        return (p = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
                            return e.__proto__ || Object.getPrototypeOf(e)
                        })(e)
                    }
                    var v = r(771),
                        y = ["#EXTINF", "#EXT-X-BYTERANGE", "#EXT-X-DISCONTINUITY", "#EXT-X-STREAM-INF", "#EXT-X-CUE-OUT", "#EXT-X-CUE-IN", "#EXT-X-KEY", "#EXT-X-MAP"],
                        g = ["#EXT-X-MEDIA"],
                        b = function(e) {
                            ! function(e, t) {
                                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                                e.prototype = Object.create(t && t.prototype, {
                                    constructor: {
                                        value: e,
                                        writable: !0,
                                        configurable: !0
                                    }
                                }), t && h(e, t)
                            }(i, e);
                            var t, r, n, o = (t = i, r = d(), function() {
                                var e, n = p(t);
                                if (r) {
                                    var o = p(this).constructor;
                                    e = Reflect.construct(n, arguments, o)
                                } else e = n.apply(this, arguments);
                                return c(this, e)
                            });

                            function i(e) {
                                var t;
                                return function(e, t) {
                                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                                }(this, i), (t = o.call(this)).baseUri = e, t
                            }
                            return (n = [{
                                key: "push",
                                value: function() {
                                    for (var e = this, t = arguments.length, r = new Array(t), n = 0; n < t; n++) r[n] = arguments[n];
                                    for (var o = function() {
                                            var t = u[a];
                                            if (!t.startsWith("#")) return s(p(i.prototype), "push", e).call(e, t), "continue";
                                            if (y.some(function(e) {
                                                    return t.startsWith(e)
                                                })) return s(p(i.prototype), "push", e).call(e, t), "continue";
                                            if (e.includes(t)) {
                                                if (g.some(function(e) {
                                                        return t.startsWith(e)
                                                    })) return "continue";
                                                v.INVALIDPLAYLIST("Redundant item (".concat(t, ")"))
                                            }
                                            s(p(i.prototype), "push", e).call(e, t)
                                        }, a = 0, u = r; a < u.length; a++) o()
                                }
                            }]) && function(e, t) {
                                for (var r = 0; r < t.length; r++) {
                                    var n = t[r];
                                    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
                                }
                            }(i.prototype, n), i
                        }(f(Array));

                    function m(e, t) {
                        var r = 1e3;
                        t && (r = Math.pow(10, t));
                        var n = Math.round(e * r) / r;
                        return t ? n.toFixed(t) : n
                    }

                    function w(e) {
                        var t = ['DATA-ID="'.concat(e.id, '"')];
                        return e.language && t.push('LANGUAGE="'.concat(e.language, '"')), e.value ? t.push('VALUE="'.concat(e.value, '"')) : e.uri && t.push('URI="'.concat(e.uri, '"')), "#EXT-X-SESSION-DATA:".concat(t.join(","))
                    }

                    function E(e, t) {
                        var r = t ? "#EXT-X-SESSION-KEY" : "#EXT-X-KEY",
                            n = ["METHOD=".concat(e.method)];
                        return e.uri && n.push('URI="'.concat(e.uri, '"')), e.iv && (16 !== e.iv.length && v.INVALIDPLAYLIST("IV must be a 128-bit unsigned integer"), n.push("IV=".concat(v.byteSequenceToHex(e.iv)))), e.format && n.push('KEYFORMAT="'.concat(e.format, '"')), e.formatVersion && n.push('KEYFORMATVERSIONS="'.concat(e.formatVersion, '"')), "".concat(r, ":").concat(n.join(","))
                    }

                    function _(e, t) {
                        var r = t.isIFrameOnly ? "#EXT-X-I-FRAME-STREAM-INF" : "#EXT-X-STREAM-INF",
                            n = ["BANDWIDTH=".concat(t.bandwidth)];
                        if (t.averageBandwidth && n.push("AVERAGE-BANDWIDTH=".concat(t.averageBandwidth)), t.isIFrameOnly && n.push('URI="'.concat(t.uri, '"')), t.codecs && n.push('CODECS="'.concat(t.codecs, '"')), t.resolution && n.push("RESOLUTION=".concat(t.resolution.width, "x").concat(t.resolution.height)), t.frameRate && n.push("FRAME-RATE=".concat(m(t.frameRate, 3))), t.hdcpLevel && n.push("HDCP-LEVEL=".concat(t.hdcpLevel)), t.audio.length > 0) {
                            n.push('AUDIO="'.concat(t.audio[0].groupId, '"'));
                            var o, a = i(t.audio);
                            try {
                                for (a.s(); !(o = a.n()).done;) {
                                    var u = o.value;
                                    e.push(T(u))
                                }
                            } catch (e) {
                                a.e(e)
                            } finally {
                                a.f()
                            }
                        }
                        if (t.video.length > 0) {
                            n.push('VIDEO="'.concat(t.video[0].groupId, '"'));
                            var s, c = i(t.video);
                            try {
                                for (c.s(); !(s = c.n()).done;) {
                                    var f = s.value;
                                    e.push(T(f))
                                }
                            } catch (e) {
                                c.e(e)
                            } finally {
                                c.f()
                            }
                        }
                        if (t.subtitles.length > 0) {
                            n.push('SUBTITLES="'.concat(t.subtitles[0].groupId, '"'));
                            var l, d = i(t.subtitles);
                            try {
                                for (d.s(); !(l = d.n()).done;) {
                                    var h = l.value;
                                    e.push(T(h))
                                }
                            } catch (e) {
                                d.e(e)
                            } finally {
                                d.f()
                            }
                        }
                        if (v.getOptions().allowClosedCaptionsNone && 0 === t.closedCaptions.length) n.push("CLOSED-CAPTIONS=NONE");
                        else if (t.closedCaptions.length > 0) {
                            n.push('CLOSED-CAPTIONS="'.concat(t.closedCaptions[0].groupId, '"'));
                            var p, y = i(t.closedCaptions);
                            try {
                                for (y.s(); !(p = y.n()).done;) {
                                    var g = p.value;
                                    e.push(T(g))
                                }
                            } catch (e) {
                                y.e(e)
                            } finally {
                                y.f()
                            }
                        }
                        e.push("".concat(r, ":").concat(n.join(","))), t.isIFrameOnly || e.push("".concat(t.uri))
                    }

                    function T(e) {
                        var t = ["TYPE=".concat(e.type), 'GROUP-ID="'.concat(e.groupId, '"'), 'NAME="'.concat(e.name, '"')];
                        return void 0 !== e.isDefault && t.push("DEFAULT=".concat(e.isDefault ? "YES" : "NO")), void 0 !== e.autoselect && t.push("AUTOSELECT=".concat(e.autoselect ? "YES" : "NO")), void 0 !== e.forced && t.push("FORCED=".concat(e.forced ? "YES" : "NO")), e.language && t.push('LANGUAGE="'.concat(e.language, '"')), e.assocLanguage && t.push('ASSOC-LANGUAGE="'.concat(e.assocLanguage, '"')), e.instreamId && t.push('INSTREAM-ID="'.concat(e.instreamId, '"')), e.characteristics && t.push('CHARACTERISTICS="'.concat(e.characteristics, '"')), e.channels && t.push('CHANNELS="'.concat(e.channels, '"')), e.uri && t.push('URI="'.concat(e.uri, '"')), "#EXT-X-MEDIA:".concat(t.join(","))
                    }

                    function S(e, t, r, n) {
                        var o = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 1,
                            i = !1;
                        if (t.byterange && e.push("#EXT-X-BYTERANGE:".concat(A(t.byterange))), t.discontinuity && e.push("#EXT-X-DISCONTINUITY"), t.key) {
                            var a = E(t.key);
                            a !== r && (e.push(a), r = a)
                        }
                        if (t.map) {
                            var u = function(e) {
                                var t = ['URI="'.concat(e.uri, '"')];
                                return e.byterange && t.push('BYTERANGE="'.concat(A(e.byterange), '"')), "#EXT-X-MAP:".concat(t.join(","))
                            }(t.map);
                            u !== n && (e.push(u), n = u)
                        }
                        if (t.programDateTime && e.push("#EXT-X-PROGRAM-DATE-TIME:".concat(v.formatDate(t.programDateTime))), t.dateRange && e.push(function(e) {
                                var t = ['ID="'.concat(e.id, '"')];
                                return e.start && t.push('START-DATE="'.concat(v.formatDate(e.start), '"')), e.end && t.push('END-DATE="'.concat(e.end, '"')), e.duration && t.push("DURATION=".concat(e.duration)), e.plannedDuration && t.push("PLANNED-DURATION=".concat(e.plannedDuration)), e.classId && t.push('CLASS="'.concat(e.classId, '"')), e.endOnNext && t.push("END-ON-NEXT=YES"), Object.keys(e.attributes).forEach(function(r) {
                                    r.startsWith("X-") ? "number" == typeof e.attributes[r] ? t.push("".concat(r, "=").concat(e.attributes[r])) : t.push("".concat(r, '="').concat(e.attributes[r], '"')) : r.startsWith("SCTE35-") && t.push("".concat(r, "=").concat(v.byteSequenceToHex(e.attributes[r])))
                                }), "#EXT-X-DATERANGE:".concat(t.join(","))
                            }(t.dateRange)), t.markers.length > 0 && I(e, t.markers), t.parts.length > 0 && (i = O(e, t.parts)), i) return [r, n];
                        var s = o < 3 ? Math.round(t.duration) : m(t.duration, function(e) {
                            var t = e.toString(10),
                                r = t.indexOf(".");
                            return -1 === r ? 0 : t.length - r - 1
                        }(t.duration));
                        return e.push("#EXTINF:".concat(s, ",").concat(unescape(encodeURIComponent(t.title || "")))), Array.prototype.push.call(e, "".concat(t.uri)), [r, n]
                    }

                    function A(e) {
                        var t = e.offset,
                            r = e.length;
                        return "".concat(r, "@").concat(t)
                    }

                    function I(e, t) {
                        var r, n = i(t);
                        try {
                            for (n.s(); !(r = n.n()).done;) {
                                var o = r.value;
                                if ("OUT" === o.type) e.push("#EXT-X-CUE-OUT:".concat(o.duration));
                                else if ("IN" === o.type) e.push("#EXT-X-CUE-IN");
                                else if ("RAW" === o.type) {
                                    var a = o.value ? ":".concat(o.value) : "";
                                    e.push("#".concat(o.tagName).concat(a))
                                }
                            }
                        } catch (e) {
                            n.e(e)
                        } finally {
                            n.f()
                        }
                    }

                    function O(e, t) {
                        var r, n = !1,
                            o = i(t);
                        try {
                            for (o.s(); !(r = o.n()).done;) {
                                var a = r.value;
                                if (a.hint) {
                                    var u = [];
                                    if (u.push("TYPE=PART"), u.push('URI="'.concat(a.uri, '"')), a.byterange) {
                                        var s = a.byterange,
                                            c = s.offset,
                                            f = s.length;
                                        u.push("BYTERANGE-START=".concat(c)), f && u.push("BYTERANGE-LENGTH=".concat(f))
                                    }
                                    e.push("#EXT-X-PRELOAD-HINT:".concat(u.join(","))), n = !0
                                } else {
                                    var l = [];
                                    l.push("DURATION=".concat(a.duration)), l.push('URI="'.concat(a.uri, '"')), a.byterange && l.push("BYTERANGE=".concat(A(a.byterange))), a.independent && l.push("INDEPENDENT=YES"), a.gap && l.push("GAP=YES"), e.push("#EXT-X-PART:".concat(l.join(",")))
                                }
                            }
                        } catch (e) {
                            o.e(e)
                        } finally {
                            o.f()
                        }
                        return n
                    }
                    e.exports = function(e) {
                        v.PARAMCHECK(e), v.ASSERT("Not a playlist", "playlist" === e.type);
                        var t = new b(e.uri);
                        return t.push("#EXTM3U"), e.version && t.push("#EXT-X-VERSION:".concat(e.version)), e.independentSegments && t.push("#EXT-X-INDEPENDENT-SEGMENTS"), e.start && t.push("#EXT-X-START:TIME-OFFSET=".concat(m(e.start.offset)).concat(e.start.precise ? ",PRECISE=YES" : "")), e.isMasterPlaylist ? function(e, t) {
                            var r, n = i(t.sessionDataList);
                            try {
                                for (n.s(); !(r = n.n()).done;) {
                                    var o = r.value;
                                    e.push(w(o))
                                }
                            } catch (e) {
                                n.e(e)
                            } finally {
                                n.f()
                            }
                            var a, u = i(t.sessionKeyList);
                            try {
                                for (u.s(); !(a = u.n()).done;) {
                                    var s = a.value;
                                    e.push(E(s, !0))
                                }
                            } catch (e) {
                                u.e(e)
                            } finally {
                                u.f()
                            }
                            var c, f = i(t.variants);
                            try {
                                for (f.s(); !(c = f.n()).done;) _(e, c.value)
                            } catch (e) {
                                f.e(e)
                            } finally {
                                f.f()
                            }
                        }(t, e) : function(e, t) {
                            var r = "",
                                n = "";
                            if (t.targetDuration && e.push("#EXT-X-TARGETDURATION:".concat(t.targetDuration)), t.lowLatencyCompatibility) {
                                var a = t.lowLatencyCompatibility,
                                    u = a.canBlockReload,
                                    s = a.canSkipUntil,
                                    c = a.holdBack,
                                    f = a.partHoldBack,
                                    l = [];
                                l.push("CAN-BLOCK-RELOAD=".concat(u ? "YES" : "NO")), void 0 !== s && l.push("CAN-SKIP-UNTIL=".concat(s)), void 0 !== c && l.push("HOLD-BACK=".concat(c)), void 0 !== f && l.push("PART-HOLD-BACK=".concat(f)), e.push("#EXT-X-SERVER-CONTROL:".concat(l.join(",")))
                            }
                            t.partTargetDuration && e.push("#EXT-X-PART-INF:PART-TARGET=".concat(t.partTargetDuration)), t.mediaSequenceBase && e.push("#EXT-X-MEDIA-SEQUENCE:".concat(t.mediaSequenceBase)), t.discontinuitySequenceBase && e.push("#EXT-X-DISCONTINUITY-SEQUENCE:".concat(t.discontinuitySequenceBase)), t.playlistType && e.push("#EXT-X-PLAYLIST-TYPE:".concat(t.playlistType)), t.isIFrame && e.push("#EXT-X-I-FRAMES-ONLY"), t.skip > 0 && e.push("#EXT-X-SKIP:SKIPPED-SEGMENTS=".concat(t.skip));
                            var d, h = i(t.segments);
                            try {
                                for (h.s(); !(d = h.n()).done;) {
                                    var p = o(S(e, d.value, r, n, t.version), 2);
                                    r = p[0], n = p[1]
                                }
                            } catch (e) {
                                h.e(e)
                            } finally {
                                h.f()
                            }
                            t.endlist && e.push("#EXT-X-ENDLIST");
                            var v, y = i(t.renditionReports);
                            try {
                                for (y.s(); !(v = y.n()).done;) {
                                    var g = v.value,
                                        b = [];
                                    b.push('URI="'.concat(g.uri, '"')), b.push("LAST-MSN=".concat(g.lastMSN)), void 0 !== g.lastPart && b.push("LAST-PART=".concat(g.lastPart)), e.push("#EXT-X-RENDITION-REPORT:".concat(b.join(",")))
                                }
                            } catch (e) {
                                y.e(e)
                            } finally {
                                y.f()
                            }
                        }(t, e), t.join("\n")
                    }
                },
                890: (e, t, r) => {
                    function n(e) {
                        return (n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                            return typeof e
                        } : function(e) {
                            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                        })(e)
                    }

                    function o(e, t) {
                        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                        e.prototype = Object.create(t && t.prototype, {
                            constructor: {
                                value: e,
                                writable: !0,
                                configurable: !0
                            }
                        }), t && i(e, t)
                    }

                    function i(e, t) {
                        return (i = Object.setPrototypeOf || function(e, t) {
                            return e.__proto__ = t, e
                        })(e, t)
                    }

                    function a(e) {
                        var t = function() {
                            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                            if (Reflect.construct.sham) return !1;
                            if ("function" == typeof Proxy) return !0;
                            try {
                                return Date.prototype.toString.call(Reflect.construct(Date, [], function() {})), !0
                            } catch (e) {
                                return !1
                            }
                        }();
                        return function() {
                            var r, n = s(e);
                            if (t) {
                                var o = s(this).constructor;
                                r = Reflect.construct(n, arguments, o)
                            } else r = n.apply(this, arguments);
                            return u(this, r)
                        }
                    }

                    function u(e, t) {
                        return !t || "object" !== n(t) && "function" != typeof t ? function(e) {
                            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                            return e
                        }(e) : t
                    }

                    function s(e) {
                        return (s = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
                            return e.__proto__ || Object.getPrototypeOf(e)
                        })(e)
                    }

                    function c(e, t) {
                        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                    }
                    var f = r(771),
                        l = function e(t) {
                            c(this, e), f.PARAMCHECK(t), this.type = t
                        },
                        d = function(e) {
                            o(r, e);
                            var t = a(r);

                            function r(e) {
                                var n, o = e.isMasterPlaylist,
                                    i = e.uri,
                                    a = e.version,
                                    u = e.independentSegments,
                                    s = void 0 !== u && u,
                                    l = e.start,
                                    d = e.source;
                                return c(this, r), n = t.call(this, "playlist"), f.PARAMCHECK(o), n.isMasterPlaylist = o, n.uri = i, n.version = a, n.independentSegments = s, n.start = l, n.source = d, n
                            }
                            return r
                        }(l),
                        h = function(e) {
                            o(r, e);
                            var t = a(r);

                            function r() {
                                var e, n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                                c(this, r), n.isMasterPlaylist = !0, e = t.call(this, n);
                                var o = n.variants,
                                    i = void 0 === o ? [] : o,
                                    a = n.currentVariant,
                                    u = n.sessionDataList,
                                    s = void 0 === u ? [] : u,
                                    f = n.sessionKeyList,
                                    l = void 0 === f ? [] : f;
                                return e.variants = i, e.currentVariant = a, e.sessionDataList = s, e.sessionKeyList = l, e
                            }
                            return r
                        }(d),
                        p = function(e) {
                            o(r, e);
                            var t = a(r);

                            function r() {
                                var e, n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                                c(this, r), n.isMasterPlaylist = !1, e = t.call(this, n);
                                var o = n.targetDuration,
                                    i = n.mediaSequenceBase,
                                    a = void 0 === i ? 0 : i,
                                    u = n.discontinuitySequenceBase,
                                    s = void 0 === u ? 0 : u,
                                    f = n.endlist,
                                    l = void 0 !== f && f,
                                    d = n.playlistType,
                                    h = n.isIFrame,
                                    p = n.segments,
                                    v = void 0 === p ? [] : p,
                                    y = n.lowLatencyCompatibility,
                                    g = n.partTargetDuration,
                                    b = n.renditionReports,
                                    m = void 0 === b ? [] : b,
                                    w = n.skip,
                                    E = void 0 === w ? 0 : w,
                                    _ = n.hash;
                                return e.targetDuration = o, e.mediaSequenceBase = a, e.discontinuitySequenceBase = s, e.endlist = l, e.playlistType = d, e.isIFrame = h, e.segments = v, e.lowLatencyCompatibility = y, e.partTargetDuration = g, e.renditionReports = m, e.skip = E, e.hash = _, e
                            }
                            return r
                        }(d),
                        v = function(e) {
                            o(r, e);
                            var t = a(r);

                            function r(e) {
                                var n, o = e.uri,
                                    i = e.mimeType,
                                    a = e.data,
                                    u = e.duration,
                                    s = e.title,
                                    f = e.byterange,
                                    l = e.discontinuity,
                                    d = e.mediaSequenceNumber,
                                    h = void 0 === d ? 0 : d,
                                    p = e.discontinuitySequence,
                                    v = void 0 === p ? 0 : p,
                                    y = e.key,
                                    g = e.map,
                                    b = e.programDateTime,
                                    m = e.dateRange,
                                    w = e.markers,
                                    E = void 0 === w ? [] : w,
                                    _ = e.parts,
                                    T = void 0 === _ ? [] : _;
                                return c(this, r), (n = t.call(this, "segment")).uri = o, n.mimeType = i, n.data = a, n.duration = u, n.title = s, n.byterange = f, n.discontinuity = l, n.mediaSequenceNumber = h, n.discontinuitySequence = v, n.key = y, n.map = g, n.programDateTime = b, n.dateRange = m, n.markers = E, n.parts = T, n
                            }
                            return r
                        }(l),
                        y = function(e) {
                            o(r, e);
                            var t = a(r);

                            function r(e) {
                                var n, o = e.hint,
                                    i = void 0 !== o && o,
                                    a = e.uri,
                                    u = e.duration,
                                    s = e.independent,
                                    l = e.byterange,
                                    d = e.gap;
                                return c(this, r), n = t.call(this, "part"), f.PARAMCHECK(a), n.hint = i, n.uri = a, n.duration = u, n.independent = s, n.duration = u, n.byterange = l, n.gap = d, n
                            }
                            return r
                        }(l);
                    e.exports = {
                        Rendition: function e(t) {
                            var r = t.type,
                                n = t.uri,
                                o = t.groupId,
                                i = t.language,
                                a = t.assocLanguage,
                                u = t.name,
                                s = t.isDefault,
                                l = t.autoselect,
                                d = t.forced,
                                h = t.instreamId,
                                p = t.characteristics,
                                v = t.channels;
                            c(this, e), f.PARAMCHECK(r, o, u), f.CONDITIONALASSERT(["SUBTITLES" === r, n], ["CLOSED-CAPTIONS" === r, h], ["CLOSED-CAPTIONS" === r, !n], [d, "SUBTITLES" === r]), this.type = r, this.uri = n, this.groupId = o, this.language = i, this.assocLanguage = a, this.name = u, this.isDefault = s, this.autoselect = l, this.forced = d, this.instreamId = h, this.characteristics = p, this.channels = v
                        },
                        Variant: function e(t) {
                            var r = t.uri,
                                n = t.isIFrameOnly,
                                o = void 0 !== n && n,
                                i = t.bandwidth,
                                a = t.averageBandwidth,
                                u = t.codecs,
                                s = t.resolution,
                                l = t.frameRate,
                                d = t.hdcpLevel,
                                h = t.audio,
                                p = void 0 === h ? [] : h,
                                v = t.video,
                                y = void 0 === v ? [] : v,
                                g = t.subtitles,
                                b = void 0 === g ? [] : g,
                                m = t.closedCaptions,
                                w = void 0 === m ? [] : m,
                                E = t.currentRenditions,
                                _ = void 0 === E ? {
                                    audio: 0,
                                    video: 0,
                                    subtitles: 0,
                                    closedCaptions: 0
                                } : E;
                            c(this, e), f.PARAMCHECK(r, i), this.uri = r, this.isIFrameOnly = o, this.bandwidth = i, this.averageBandwidth = a, this.codecs = u, this.resolution = s, this.frameRate = l, this.hdcpLevel = d, this.audio = p, this.video = y, this.subtitles = b, this.closedCaptions = w, this.currentRenditions = _
                        },
                        SessionData: function e(t) {
                            var r = t.id,
                                n = t.value,
                                o = t.uri,
                                i = t.language;
                            c(this, e), f.PARAMCHECK(r, n || o), f.ASSERT("SessionData cannot have both value and uri, shoud be either.", !(n && o)), this.id = r, this.value = n, this.uri = o, this.language = i
                        },
                        Key: function e(t) {
                            var r = t.method,
                                n = t.uri,
                                o = t.iv,
                                i = t.format,
                                a = t.formatVersion;
                            c(this, e), f.PARAMCHECK(r), f.CONDITIONALPARAMCHECK(["NONE" !== r, n]), f.CONDITIONALASSERT(["NONE" === r, !(n || o || i || a)]), this.method = r, this.uri = n, this.iv = o, this.format = i, this.formatVersion = a
                        },
                        MediaInitializationSection: function e(t) {
                            var r = t.hint,
                                n = void 0 !== r && r,
                                o = t.uri,
                                i = t.mimeType,
                                a = t.byterange;
                            c(this, e), f.PARAMCHECK(o), this.hint = n, this.uri = o, this.mimeType = i, this.byterange = a
                        },
                        DateRange: function e(t) {
                            var r = t.id,
                                n = t.classId,
                                o = t.start,
                                i = t.end,
                                a = t.duration,
                                u = t.plannedDuration,
                                s = t.endOnNext,
                                l = t.attributes,
                                d = void 0 === l ? {} : l;
                            c(this, e), f.PARAMCHECK(r), f.CONDITIONALPARAMCHECK([!0 === s, n]), f.CONDITIONALASSERT([i, o], [i, o <= i], [a, a >= 0], [u, u >= 0]), this.id = r, this.classId = n, this.start = o, this.end = i, this.duration = a, this.plannedDuration = u, this.endOnNext = s, this.attributes = d
                        },
                        SpliceInfo: function e(t) {
                            var r = t.type,
                                n = t.duration,
                                o = t.tagName,
                                i = t.value;
                            c(this, e), f.PARAMCHECK(r), f.CONDITIONALPARAMCHECK(["OUT" === r, n]), f.CONDITIONALPARAMCHECK(["RAW" === r, o]), this.type = r, this.duration = n, this.tagName = o, this.value = i
                        },
                        Playlist: d,
                        MasterPlaylist: h,
                        MediaPlaylist: p,
                        Segment: v,
                        PartialSegment: y,
                        RenditionReport: function e(t) {
                            var r = t.uri,
                                n = t.lastMSN,
                                o = t.lastPart;
                            c(this, e), f.PARAMCHECK(r), this.uri = r, this.lastMSN = n, this.lastPart = o
                        }
                    }
                },
                771: e => {
                    function t(e, t) {
                        return function(e) {
                            if (Array.isArray(e)) return e
                        }(e) || function(e, t) {
                            if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) {
                                var r = [],
                                    n = !0,
                                    o = !1,
                                    i = void 0;
                                try {
                                    for (var a, u = e[Symbol.iterator](); !(n = (a = u.next()).done) && (r.push(a.value), !t || r.length !== t); n = !0);
                                } catch (e) {
                                    o = !0, i = e
                                } finally {
                                    try {
                                        n || null == u.return || u.return()
                                    } finally {
                                        if (o) throw i
                                    }
                                }
                                return r
                            }
                        }(e, t) || n(e, t) || function() {
                            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                        }()
                    }

                    function r(e, t) {
                        var r;
                        if ("undefined" == typeof Symbol || null == e[Symbol.iterator]) {
                            if (Array.isArray(e) || (r = n(e)) || t && e && "number" == typeof e.length) {
                                r && (e = r);
                                var o = 0,
                                    i = function() {};
                                return {
                                    s: i,
                                    n: function() {
                                        return o >= e.length ? {
                                            done: !0
                                        } : {
                                            done: !1,
                                            value: e[o++]
                                        }
                                    },
                                    e: function(e) {
                                        throw e
                                    },
                                    f: i
                                }
                            }
                            throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                        }
                        var a, u = !0,
                            s = !1;
                        return {
                            s: function() {
                                r = e[Symbol.iterator]()
                            },
                            n: function() {
                                var e = r.next();
                                return u = e.done, e
                            },
                            e: function(e) {
                                s = !0, a = e
                            },
                            f: function() {
                                try {
                                    u || null == r.return || r.return()
                                } finally {
                                    if (s) throw a
                                }
                            }
                        }
                    }

                    function n(e, t) {
                        if (e) {
                            if ("string" == typeof e) return o(e, t);
                            var r = Object.prototype.toString.call(e).slice(8, -1);
                            return "Object" === r && e.constructor && (r = e.constructor.name), "Map" === r || "Set" === r ? Array.from(e) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? o(e, t) : void 0
                        }
                    }

                    function o(e, t) {
                        (null == t || t > e.length) && (t = e.length);
                        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
                        return n
                    }
                    var i = {};

                    function a(e) {
                        if (i.strictMode) throw e;
                        i.silent
                    }

                    function u(e) {
                        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 10;
                        if ("number" == typeof e) return e;
                        var r = 10 === t ? Number.parseFloat(e, t) : Number.parseInt(e, t);
                        return Number.isNaN(r) ? 0 : r
                    }
                    e.exports = {
                        THROW: a,
                        ASSERT: function(e) {
                            for (var n = arguments.length, o = new Array(n > 1 ? n - 1 : 0), i = 1; i < n; i++) o[i - 1] = arguments[i];
                            var u, s = r(o.entries());
                            try {
                                for (s.s(); !(u = s.n()).done;) {
                                    var c = t(u.value, 2),
                                        f = c[0];
                                    c[1] || a(new Error("".concat(e, " : Failed at [").concat(f, "]")))
                                }
                            } catch (e) {
                                s.e(e)
                            } finally {
                                s.f()
                            }
                        },
                        CONDITIONALASSERT: function() {
                            for (var e = arguments.length, n = new Array(e), o = 0; o < e; o++) n[o] = arguments[o];
                            var i, u = r(n.entries());
                            try {
                                for (u.s(); !(i = u.n()).done;) {
                                    var s = t(i.value, 2),
                                        c = s[0],
                                        f = t(s[1], 2),
                                        l = f[0],
                                        d = f[1];
                                    l && (d || a(new Error("Conditional Assert : Failed at [".concat(c, "]"))))
                                }
                            } catch (e) {
                                u.e(e)
                            } finally {
                                u.f()
                            }
                        },
                        PARAMCHECK: function() {
                            for (var e = arguments.length, n = new Array(e), o = 0; o < e; o++) n[o] = arguments[o];
                            var i, u = r(n.entries());
                            try {
                                for (u.s(); !(i = u.n()).done;) {
                                    var s = t(i.value, 2),
                                        c = s[0];
                                    void 0 === s[1] && a(new Error("Param Check : Failed at [".concat(c, "]")))
                                }
                            } catch (e) {
                                u.e(e)
                            } finally {
                                u.f()
                            }
                        },
                        CONDITIONALPARAMCHECK: function() {
                            for (var e = arguments.length, n = new Array(e), o = 0; o < e; o++) n[o] = arguments[o];
                            var i, u = r(n.entries());
                            try {
                                for (u.s(); !(i = u.n()).done;) {
                                    var s = t(i.value, 2),
                                        c = s[0],
                                        f = t(s[1], 2),
                                        l = f[0],
                                        d = f[1];
                                    l && void 0 === d && a(new Error("Conditional Param Check : Failed at [".concat(c, "]")))
                                }
                            } catch (e) {
                                u.e(e)
                            } finally {
                                u.f()
                            }
                        },
                        INVALIDPLAYLIST: function(e) {
                            a(new Error("Invalid Playlist : ".concat(e)))
                        },
                        toNumber: u,
                        hexToByteSequence: function(e) {
                            (e.startsWith("0x") || e.startsWith("0X")) && (e = e.slice(2));
                            for (var t = [], r = 0; r < e.length; r += 2) t.push(u(e.slice(r, r + 2), 16));
                            return Buffer.from(t)
                        },
                        byteSequenceToHex: function(e) {
                            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                                r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : e.length;
                            r <= t && a(new Error("end must be larger than start : start=".concat(t, ", end=").concat(r)));
                            for (var n = [], o = t; o < r; o++) n.push("0".concat((255 & e[o]).toString(16).toUpperCase()).slice(-2));
                            return "0x".concat(n.join(""))
                        },
                        tryCatch: function(e, t) {
                            try {
                                return e()
                            } catch (e) {
                                return t(e)
                            }
                        },
                        splitAt: function(e, t) {
                            for (var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0, n = -1, o = 0, i = 0; o < e.length; o++)
                                if (e[o] === t) {
                                    if (i++ === r) return [e.slice(0, o), e.slice(o + 1)];
                                    n = o
                                }
                            return -1 !== n ? [e.slice(0, n), e.slice(n + 1)] : [e]
                        },
                        trim: function(e) {
                            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : " ";
                            return e ? (e = e.trim(), " " === t || (e.startsWith(t) && (e = e.slice(1)), e.endsWith(t) && (e = e.slice(0, -1))), e) : e
                        },
                        splitByCommaWithPreservingQuotes: function(e) {
                            for (var t = [], r = !0, n = 0, o = [], i = 0; i < e.length; i++) {
                                var a = e[i];
                                r && "," === a ? (t.push(e.slice(n, i).trim()), n = i + 1) : '"' !== a && "'" !== a || (r ? (o.push(a), r = !1) : a === o[o.length - 1] ? (o.pop(), r = !0) : o.push(a))
                            }
                            return t.push(e.slice(n).trim()), t
                        },
                        camelify: function(e) {
                            var t, n = [],
                                o = !1,
                                i = r(e);
                            try {
                                for (i.s(); !(t = i.n()).done;) {
                                    var a = t.value;
                                    "-" !== a && "_" !== a ? o ? (n.push(a.toUpperCase()), o = !1) : n.push(a.toLowerCase()) : o = !0
                                }
                            } catch (e) {
                                i.e(e)
                            } finally {
                                i.f()
                            }
                            return n.join("")
                        },
                        formatDate: function(e) {
                            var t = e.getUTCFullYear(),
                                r = ("0" + (e.getUTCMonth() + 1)).slice(-2),
                                n = ("0" + e.getUTCDate()).slice(-2),
                                o = ("0" + e.getUTCHours()).slice(-2),
                                i = ("0" + e.getUTCMinutes()).slice(-2),
                                a = ("0" + e.getUTCSeconds()).slice(-2),
                                u = ("00" + e.getUTCMilliseconds()).slice(-3);
                            return "".concat(t, "-").concat(r, "-").concat(n, "T").concat(o, ":").concat(i, ":").concat(a, ".").concat(u, "Z")
                        },
                        hasOwnProp: function(e, t) {
                            return Object.hasOwnProperty.call(e, t)
                        },
                        setOptions: function() {
                            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                            i = Object.assign(i, e)
                        },
                        getOptions: function() {
                            return Object.assign({}, i)
                        }
                    }
                }
            }, t = {},
            function r(n) {
                if (t[n]) return t[n].exports;
                var o = t[n] = {
                    exports: {}
                };
                return e[n](o, o.exports, r), o.exports
            }(851);
        var e, t
    }()
});

function XD() {
    return XD = Object.assign || function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var r = arguments[t];
            for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
        }
        return e
    }, XD.apply(this, arguments)
}
var UD, BD = ["bottom", "height", "left", "right", "top", "width"],
    FD = new Map,
    VD = function e() {
        var t = [];
        FD.forEach(function(e, r) {
            var n = r.getBoundingClientRect();
            (function(e, t) {
                return void 0 === e && (e = {}), void 0 === t && (t = {}), BD.some(function(r) {
                    return e[r] !== t[r]
                })
            })(n, e.rect) && (e.rect = n, t.push(e))
        }), t.forEach(function(e) {
            e.callbacks.forEach(function(t) {
                return t(e.rect)
            })
        }), UD = window.requestAnimationFrame(e)
    },
    zD = "undefined" != typeof window ? AM.useLayoutEffect : AM.useEffect;

function HD(e, t) {
    void 0 === t && (t = {
        width: 0,
        height: 0
    });
    var r = AM.useState(e.current),
        n = r[0],
        o = r[1],
        i = AM.useReducer(WD, t),
        a = i[0],
        u = i[1],
        s = AM.useRef(!1);
    return zD(function() {
        e.current !== n && o(e.current)
    }), zD(function() {
        if (n && !s.current) {
            s.current = !0;
            var e = n.getBoundingClientRect();
            u({
                rect: e
            })
        }
    }, [n]), AM.useEffect(function() {
        if (n) {
            var e = function(e, t) {
                return {
                    observe: function() {
                        var r = 0 === FD.size;
                        FD.has(e) ? FD.get(e).callbacks.push(t) : FD.set(e, {
                            rect: void 0,
                            hasRectChanged: !1,
                            callbacks: [t]
                        }), r && VD()
                    },
                    unobserve: function() {
                        var r = FD.get(e);
                        if (r) {
                            var n = r.callbacks.indexOf(t);
                            n >= 0 && r.callbacks.splice(n, 1), r.callbacks.length || FD.delete(e), FD.size || cancelAnimationFrame(UD)
                        }
                    }
                }
            }(n, function(e) {
                u({
                    rect: e
                })
            });
            return e.observe(),
                function() {
                    e.unobserve()
                }
        }
    }, [n]), a
}

function WD(e, t) {
    var r = t.rect;
    return e.height !== r.height || e.width !== r.width ? r : e
}
var YD = function() {
        return 50
    },
    GD = function(e) {
        return e
    },
    KD = function(e, t) {
        return e[t ? "offsetWidth" : "offsetHeight"]
    },
    qD = function(e) {
        for (var t = Math.max(e.start - e.overscan, 0), r = Math.min(e.end + e.overscan, e.size - 1), n = [], o = t; o <= r; o++) n.push(o);
        return n
    };

function $D(e) {
    var t, r = e.size,
        n = void 0 === r ? 0 : r,
        o = e.estimateSize,
        i = void 0 === o ? YD : o,
        a = e.overscan,
        u = void 0 === a ? 1 : a,
        s = e.paddingStart,
        c = void 0 === s ? 0 : s,
        f = e.paddingEnd,
        l = void 0 === f ? 0 : f,
        d = e.parentRef,
        h = e.horizontal,
        p = e.scrollToFn,
        v = e.useObserver,
        y = e.initialRect,
        g = e.onScrollElement,
        b = e.scrollOffsetFn,
        m = e.keyExtractor,
        w = void 0 === m ? GD : m,
        E = e.measureSize,
        _ = void 0 === E ? KD : E,
        T = e.rangeExtractor,
        S = void 0 === T ? qD : T,
        A = h ? "width" : "height",
        I = h ? "scrollLeft" : "scrollTop",
        O = AM.useRef({
            scrollOffset: 0,
            measurements: []
        }),
        R = AM.useState(0),
        N = R[0],
        P = R[1];
    O.current.scrollOffset = N;
    var M = (v || HD)(d, y)[A];
    O.current.outerSize = M;
    var D = AM.useCallback(function(e) {
            d.current && (d.current[I] = e)
        }, [d, I]),
        x = p || D;
    p = AM.useCallback(function(e) {
        x(e, D)
    }, [D, x]);
    var C = AM.useState({}),
        k = C[0],
        L = C[1],
        j = AM.useCallback(function() {
            return L({})
        }, []),
        X = AM.useRef([]),
        U = AM.useMemo(function() {
            var e = X.current.length > 0 ? Math.min.apply(Math, X.current) : 0;
            X.current = [];
            for (var t = O.current.measurements.slice(0, e), r = e; r < n; r++) {
                var o = w(r),
                    a = k[o],
                    u = t[r - 1] ? t[r - 1].end : c,
                    s = "number" == typeof a ? a : i(r),
                    f = u + s;
                t[r] = {
                    index: r,
                    start: u,
                    size: s,
                    end: f,
                    key: o
                }
            }
            return t
        }, [i, k, c, n, w]),
        B = ((null == (t = U[n - 1]) ? void 0 : t.end) || c) + l;
    O.current.measurements = U, O.current.totalSize = B;
    var F = g ? g.current : d.current,
        V = AM.useRef(b);
    V.current = b, zD(function() {
        if (F) {
            var e = function(e) {
                var t = V.current ? V.current(e) : F[I];
                P(t)
            };
            return e(), F.addEventListener("scroll", e, {
                    capture: !1,
                    passive: !0
                }),
                function() {
                    F.removeEventListener("scroll", e)
                }
        }
        P(0)
    }, [F, I]);
    var z = function(e) {
            for (var t = e.measurements, r = e.outerSize, n = e.scrollOffset, o = t.length - 1, i = QD(0, o, function(e) {
                    return t[e].start
                }, n), a = i; a < o && t[a].end < n + r;) a++;
            return {
                start: i,
                end: a
            }
        }(O.current),
        H = z.start,
        W = z.end,
        Y = AM.useMemo(function() {
            return S({
                start: H,
                end: W,
                overscan: u,
                size: U.length
            })
        }, [H, W, u, U.length, S]),
        G = AM.useRef(_);
    G.current = _;
    var K = AM.useMemo(function() {
            for (var e = [], t = function(t, r) {
                    var n = Y[t],
                        o = XD(XD({}, U[n]), {}, {
                            measureRef: function(e) {
                                if (e) {
                                    var t = G.current(e, h);
                                    if (t !== o.size) {
                                        var r = O.current.scrollOffset;
                                        o.start < r && D(r + (t - o.size)), X.current.push(n), L(function(e) {
                                            var r;
                                            return XD(XD({}, e), {}, ((r = {})[o.key] = t, r))
                                        })
                                    }
                                }
                            }
                        });
                    e.push(o)
                }, r = 0, n = Y.length; r < n; r++) t(r);
            return e
        }, [Y, D, h, U]),
        q = AM.useRef(!1);
    zD(function() {
        q.current && L({}), q.current = !0
    }, [i]);
    var $ = AM.useCallback(function(e, t) {
            var r = (void 0 === t ? {} : t).align,
                n = void 0 === r ? "start" : r,
                o = O.current,
                i = o.scrollOffset,
                a = o.outerSize;
            "auto" === n && (n = e <= i ? "start" : e >= i + a ? "end" : "start"), "start" === n ? p(e) : "end" === n ? p(e - a) : "center" === n && p(e - a / 2)
        }, [p]),
        Q = AM.useCallback(function(e, t) {
            var r = void 0 === t ? {} : t,
                o = r.align,
                i = void 0 === o ? "auto" : o,
                a = function(e, t) {
                    if (null == e) return {};
                    var r, n, o = {},
                        i = Object.keys(e);
                    for (n = 0; n < i.length; n++) r = i[n], t.indexOf(r) >= 0 || (o[r] = e[r]);
                    return o
                }(r, ["align"]),
                u = O.current,
                s = u.measurements,
                c = u.scrollOffset,
                f = u.outerSize,
                l = s[Math.max(0, Math.min(e, n - 1))];
            if (l) {
                if ("auto" === i)
                    if (l.end >= c + f) i = "end";
                    else {
                        if (!(l.start <= c)) return;
                        i = "start"
                    }
                var d = "center" === i ? l.start + l.size / 2 : "end" === i ? l.end : l.start;
                $(d, XD({
                    align: i
                }, a))
            }
        }, [$, n]),
        J = AM.useCallback(function() {
            for (var e = arguments.length, t = new Array(e), r = 0; r < e; r++) t[r] = arguments[r];
            Q.apply(void 0, t), requestAnimationFrame(function() {
                Q.apply(void 0, t)
            })
        }, [Q]);
    return {
        virtualItems: K,
        totalSize: B,
        scrollToOffset: $,
        scrollToIndex: J,
        measure: j
    }
}
var QD = function(e, t, r, n) {
    for (; e <= t;) {
        var o = (e + t) / 2 | 0,
            i = r(o);
        if (i < n) e = o + 1;
        else {
            if (!(i > n)) return o;
            t = o - 1
        }
    }
    return e > 0 ? e - 1 : 0
};
export {
    fR as $, dT as A, h_ as B, u_ as C, DI as D, dO as E, o_ as F, pO as G, hT as H, tO as I, i_ as J, vO as K, e_ as L, yO as M, a_ as N, NS as O, gO as P, mO as Q, PT as R, TO as S, vT as T, yT as U, cT as V, MO as W, NO as X, PO as Y, tR as Z, SO as _, __ as a, p_ as a0, bS as a1, qT as a2, yR as a3, DR as a4, qI as a5, aT as a6, uT as a7, y_ as a8, CR as a9, fM as aA, QM as aB, Z_ as aC, aP as aD, lD as aE, AD as aF, GS as aG, $S as aH, KS as aI, K_ as aJ, m_ as aK, MT as aL, jD as aM, $D as aN, gN as aa, DN as ab, IT as ac, MM as ad, NM as ae, PM as af, RM as ag, xM as ah, OM as ai, TP as aj, EP as ak, AP as al, OP as am, PP as an, SP as ao, IP as ap, KM as aq, w_ as ar, GP as as, ZP as at, XN as au, BN as av, RP as aw, cP as ax, KN as ay, sP as az, J_ as b, T_ as c, l_ as d, ZE as e, b_ as f, iT as g, oT as h, f_ as i, I_ as j, nT as k, d_ as l, v_ as m, rT as n, t_ as o, eT as p, r_ as q, _T as r, G_ as s, E_ as t, fT as u, s_ as v, sT as w, tT as x, g_ as y, c_ as z
};

//# debugId=513f0d98-cddc-5210-b652-1b17a142037f