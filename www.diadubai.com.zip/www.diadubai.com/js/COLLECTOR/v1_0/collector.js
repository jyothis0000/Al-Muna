(() => {
    var t = {
            767(t) {
                t.exports = function() {
                    "use strict";

                    function t(t) {
                        for (var e = 1; e < arguments.length; e++) {
                            var a = arguments[e];
                            for (var i in a) "__proto__" !== i && (t[i] = a[i])
                        }
                        return t
                    }
                    return function e(a, i) {
                        function n(e, n, o) {
                            if ("undefined" != typeof document) {
                                "number" == typeof(o = t({}, i, o)).expires && (o.expires = new Date(Date.now() + 864e5 * o.expires)), o.expires && (o.expires = o.expires.toUTCString()), e = encodeURIComponent(e).replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent).replace(/[()]/g, escape);
                                var r = "";
                                for (var s in o) o[s] && (r += "; " + s, !0 !== o[s] && (r += "=" + o[s].split(";")[0]));
                                return document.cookie = e + "=" + a.write(n, e) + r
                            }
                        }
                        return Object.create({
                            set: n,
                            get: function(t) {
                                if ("undefined" != typeof document && (!arguments.length || t)) {
                                    for (var e = document.cookie ? document.cookie.split("; ") : [], i = {}, n = 0; n < e.length; n++) {
                                        var o = e[n].split("="),
                                            r = o.slice(1).join("=");
                                        try {
                                            var s = decodeURIComponent(o[0]);
                                            if (s in i || (i[s] = a.read(r, s)), t === s) break
                                        } catch {}
                                    }
                                    return t ? i[t] : i
                                }
                            },
                            remove: function(e, a) {
                                n(e, "", t({}, a, {
                                    expires: -1
                                }))
                            },
                            withAttributes: function(a) {
                                return e(this.converter, t({}, this.attributes, a))
                            },
                            withConverter: function(a) {
                                return e(t({}, this.converter, a), this.attributes)
                            }
                        }, {
                            attributes: {
                                value: Object.freeze(i)
                            },
                            converter: {
                                value: Object.freeze(a)
                            }
                        })
                    }({
                        read: function(t) {
                            return '"' === t[0] && (t = t.slice(1, -1)), t.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent)
                        },
                        write: function(t) {
                            return encodeURIComponent(t).replace(/%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g, decodeURIComponent)
                        }
                    }, {
                        path: "/"
                    })
                }()
            },
            334(t, e) {
                "use strict";
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.configuration = void 0, e.configuration = new class {
                    constructor() {
                        this.getScriptURL = () => (document.currentScript || document.querySelector('script[src*="v1_0/collector.js"]')).src, this.DOMAIN = window.location.hostname, this.ORIGIN_URL = `${new URL(this.getScriptURL()).origin}`, this.RELATIVE_PATH = window.location.pathname
                    }
                }
            },
            661(t, e) {
                "use strict";
                var a, i, n = this && this.__awaiter || function(t, e, a, i) {
                        return new(a || (a = Promise))(function(n, o) {
                            function r(t) {
                                try {
                                    c(i.next(t))
                                } catch (t) {
                                    o(t)
                                }
                            }

                            function s(t) {
                                try {
                                    c(i.throw(t))
                                } catch (t) {
                                    o(t)
                                }
                            }

                            function c(t) {
                                var e;
                                t.done ? n(t.value) : (e = t.value, e instanceof a ? e : new a(function(t) {
                                    t(e)
                                })).then(r, s)
                            }
                            c((i = i.apply(t, e || [])).next())
                        })
                    },
                    o = this && this.__rest || function(t, e) {
                        var a = {};
                        for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && e.indexOf(i) < 0 && (a[i] = t[i]);
                        if (null != t && "function" == typeof Object.getOwnPropertySymbols) {
                            var n = 0;
                            for (i = Object.getOwnPropertySymbols(t); n < i.length; n++) e.indexOf(i[n]) < 0 && Object.prototype.propertyIsEnumerable.call(t, i[n]) && (a[i[n]] = t[i[n]])
                        }
                        return a
                    };
                Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), e.Api = e.HttpClient = e.ContentType = e.ResultType = void 0,
                    function(t) {
                        t[t.Value0 = 0] = "Value0", t[t.Value1 = 1] = "Value1", t[t.Value2 = 2] = "Value2", t[t.Value3 = 3] = "Value3", t[t.Value4 = 4] = "Value4", t[t.Value5 = 5] = "Value5", t[t.Value6 = 6] = "Value6", t[t.Value7 = 7] = "Value7"
                    }(a || (e.ResultType = a = {})),
                    function(t) {
                        t.Json = "application/json", t.FormData = "multipart/form-data", t.UrlEncoded = "application/x-www-form-urlencoded", t.Text = "text/plain"
                    }(i || (e.ContentType = i = {}));
                class r {
                    constructor(t = {}) {
                        this.baseUrl = "", this.securityData = null, this.abortControllers = new Map, this.customFetch = (...t) => fetch(...t), this.baseApiParams = {
                            credentials: "same-origin",
                            headers: {},
                            redirect: "follow",
                            referrerPolicy: "no-referrer"
                        }, this.setSecurityData = t => {
                            this.securityData = t
                        }, this.contentFormatters = {
                            [i.Json]: t => null === t || "object" != typeof t && "string" != typeof t ? t : JSON.stringify(t),
                            [i.Text]: t => null !== t && "string" != typeof t ? JSON.stringify(t) : t,
                            [i.FormData]: t => Object.keys(t || {}).reduce((e, a) => {
                                const i = t[a];
                                return e.append(a, i instanceof Blob ? i : "object" == typeof i && null !== i ? JSON.stringify(i) : `${i}`), e
                            }, new FormData),
                            [i.UrlEncoded]: t => this.toQueryString(t)
                        }, this.createAbortSignal = t => {
                            if (this.abortControllers.has(t)) {
                                const e = this.abortControllers.get(t);
                                return e ? e.signal : void 0
                            }
                            const e = new AbortController;
                            return this.abortControllers.set(t, e), e.signal
                        }, this.abortRequest = t => {
                            const e = this.abortControllers.get(t);
                            e && (e.abort(), this.abortControllers.delete(t))
                        }, this.request = t => n(this, void 0, void 0, function*() {
                            var {
                                body: e,
                                secure: a,
                                path: r,
                                type: s,
                                query: c,
                                format: l,
                                baseUrl: u,
                                cancelToken: d
                            } = t, p = o(t, ["body", "secure", "path", "type", "query", "format", "baseUrl", "cancelToken"]);
                            const m = ("boolean" == typeof a ? a : this.baseApiParams.secure) && this.securityWorker && (yield this.securityWorker(this.securityData)) || {},
                                h = this.mergeRequestParams(p, m),
                                f = c && this.toQueryString(c),
                                g = this.contentFormatters[s || i.Json],
                                b = l || h.format;
                            return this.customFetch(`${u||this.baseUrl||""}${r}${f?`?${f}`:""}`, Object.assign(Object.assign({}, h), {
                                headers: Object.assign(Object.assign({}, h.headers || {}), s && s !== i.FormData ? {
                                    "Content-Type": s
                                } : {}),
                                signal: d ? this.createAbortSignal(d) : h.signal,
                                body: null == e ? null : g(e)
                            })).then(t => n(this, void 0, void 0, function*() {
                                const e = t;
                                e.data = null, e.error = null;
                                const a = b ? yield t[b]().then(t => (e.ok ? e.data = t : e.error = t, e)).catch(t => (e.error = t, e)): e;
                                if (d && this.abortControllers.delete(d), !t.ok) throw a;
                                return a
                            }))
                        }), Object.assign(this, t)
                    }
                    encodeQueryParam(t, e) {
                        return `${encodeURIComponent(t)}=${encodeURIComponent("number"==typeof e?e:`${e}`)}`
                    }
                    addQueryParam(t, e) {
                        return this.encodeQueryParam(e, t[e])
                    }
                    addArrayQueryParam(t, e) {
                        return t[e].map(t => this.encodeQueryParam(e, t)).join("&")
                    }
                    toQueryString(t) {
                        const e = t || {};
                        return Object.keys(e).filter(t => void 0 !== e[t]).map(t => Array.isArray(e[t]) ? this.addArrayQueryParam(e, t) : this.addQueryParam(e, t)).join("&")
                    }
                    addQueryParams(t) {
                        const e = this.toQueryString(t);
                        return e ? `?${e}` : ""
                    }
                    mergeRequestParams(t, e) {
                        return Object.assign(Object.assign(Object.assign(Object.assign({}, this.baseApiParams), t), e || {}), {
                            headers: Object.assign(Object.assign(Object.assign({}, this.baseApiParams.headers || {}), t.headers || {}), e && e.headers || {})
                        })
                    }
                }
                e.HttpClient = r, e.Api = class extends r {
                    constructor() {
                        super(...arguments), this.api = {
                            interactionCreate: (t, e = {}) => "false" == localStorage.getItem("amais-dxp-subject-consent") ? {
                                message: "not allowed"
                            } : this.request(Object.assign({
                                path: "/api/v1/interaction",
                                method: "POST",
                                body: t,
                                secure: !0,
                                type: i.Json,
                                format: "json"
                            }, e))
                        }
                    }
                }
            },
            624(t, e, a) {
                "use strict";
                var i = this && this.__awaiter || function(t, e, a, i) {
                    return new(a || (a = Promise))(function(n, o) {
                        function r(t) {
                            try {
                                c(i.next(t))
                            } catch (t) {
                                o(t)
                            }
                        }

                        function s(t) {
                            try {
                                c(i.throw(t))
                            } catch (t) {
                                o(t)
                            }
                        }

                        function c(t) {
                            var e;
                            t.done ? n(t.value) : (e = t.value, e instanceof a ? e : new a(function(t) {
                                t(e)
                            })).then(r, s)
                        }
                        c((i = i.apply(t, e || [])).next())
                    })
                };
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.AmaisDxpApi = void 0;
                const n = a(767),
                    o = a(860),
                    r = a(334),
                    s = a(661),
                    c = a(58);
                e.AmaisDxpApi = class {
                    constructor() {
                        this._inIframe = () => {
                            try {
                                return window.self !== window.top
                            } catch (t) {
                                return !1
                            }
                        }, this._getSubjectId = () => {
                            let t = n.get("amais-dxp-subject");
                            if (t)(e = new Date).setFullYear(e.getFullYear() + 1), n.set("amais-dxp-subject", t, {
                                expires: e,
                                sameSite: "None",
                                secure: !0
                            });
                            else {
                                var e = new Date,
                                    a = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(t) {
                                        const e = 16 * Math.random() | 0;
                                        return ("x" == t ? e : 3 & e | 8).toString(16)
                                    });
                                e.setFullYear(e.getFullYear() + 1), n.set("amais-dxp-subject", a, {
                                    expires: e,
                                    sameSite: "None",
                                    secure: !0
                                }), t = n.get("amais-dxp-subject")
                            }
                            return t
                        }, this._getLocationWithoutQueryString = () => `${window.location.origin}${window.location.pathname}`, this._populateTitleIfExists = t => {
                            !document.title || t.objectMetadata && t.objectMetadata.canonicalTitle || (t.objectMetadata = t.objectMetadata || {}, t.objectMetadata.canonicalTitle = document.title)
                        }, this._getLocalStoragePrevUrlIfExists = t => t ? localStorage.getItem("amais-dxp-pre-prev-page") : null, this._getCanonicalUrlFromHtmlOrLocation = () => {
                            var t = document.querySelector('link[rel="canonical"]');
                            return t ? t.getAttribute("href") : this._getLocationWithoutQueryString()
                        }, this._getCanonicalUrlIfExists = t => t ? localStorage.getItem("amais-dxp-prev-canonical-url") : this._getCanonicalUrlFromHtmlOrLocation(), this._populateCanonicalUrlIfExists = (t, e) => {
                            var a = this._getCanonicalUrlIfExists(t);
                            null == a || e.objectMetadata && e.objectMetadata.canonicalURL || (e.objectMetadata = e.objectMetadata || {}, e.objectMetadata.canonicalURL = a), e.objectMetadata && e.objectMetadata.canonicalURL && (e.objectMetadata.canonicalURL = e.objectMetadata.canonicalURL.replace(/([^:]\/)\/+/g, "$1").replace(/\/+$/, ""))
                        }, this._populateReferrerUrlIfExists = (t, e) => {
                            var a = this._getLocalStoragePrevUrlIfExists(t);
                            (document.referrer && null != document.referrer && "" != document.referrer || a && null != a) && (e.objectMetadata = e.objectMetadata || {}, t || a && null != a && a.includes(document.referrer) || null == document.referrer || "" == document.referrer ? e.objectMetadata.referrerUrl = a || "" : e.objectMetadata.referrerUrl = document.referrer || a || "", e.objectMetadata && e.objectMetadata.referrerUrl && (e.objectMetadata.referrerUrl = e.objectMetadata.referrerUrl.replace(/([^:]\/)\/+/g, "$1").replace(/\/+$/, "")))
                        }, this._populatePageIdIfExists = t => {
                            var e = document.querySelector('meta[name="amais-dxp:page-id"]');
                            if (e) {
                                var a = e.getAttribute("content");
                                a && (t.objectMetadata = t.objectMetadata || {}, t.objectMetadata.pageId = a)
                            }
                        }, this._populateABtestIfExists = t => {
                            var e = document.querySelector('meta[name="amais-dxp:abTest-id"]'),
                                a = document.querySelector('meta[name="amais-dxp:abTest-variant-id"]');
                            if (e && a) {
                                var i = e.getAttribute("content"),
                                    n = a.getAttribute("content");
                                i && n && (t.objectMetadata = t.objectMetadata || {}, t.objectMetadata.abTest = t.objectMetadata.abTest || {}, t.objectMetadata.abTest.id = i, t.objectMetadata.abTest.variantId = n)
                            }
                        }, this._populatePersonalizationIfExists = t => {
                            var e = document.querySelector('meta[name="amais-dxp:personalization-type"]'),
                                a = document.querySelector('meta[name="amais-dxp:segment"]'),
                                i = document.querySelector('meta[name="amais-dxp:segment-id"]');
                            if (e && a && i) {
                                var n = e.getAttribute("content"),
                                    o = a.getAttribute("content"),
                                    r = i.getAttribute("content");
                                n && o && r && (t.objectMetadata = t.objectMetadata || {}, t.objectMetadata.personalizations = t.objectMetadata.personalizations || [], t.objectMetadata.personalizations.push({
                                    personalizationType: n,
                                    segment: o,
                                    segmentId: r
                                }))
                            }
                        }, this._populateUserActivity = (t, e) => {
                            e > 0 && (t.objectMetadata = t.objectMetadata || {}, t.objectMetadata.contentPath = t.objectMetadata.contentPath || {}, t.objectMetadata.contentPath.metadata = t.objectMetadata.contentPath.metadata || {}, t.objectMetadata.contentPath.metadata.ustact = e.toString())
                        }, this._trackLinks = t => i(this, void 0, void 0, function*() {
                            var e = this;
                            window.addEventListener("load", a => i(this, void 0, void 0, function*() {
                                const a = new s.Api,
                                    n = {};
                                n.subject = t, n.userAgent = navigator.userAgent, n.language = navigator.language.substring(0, 100), this._populateTitleIfExists(n), this._populateCanonicalUrlIfExists(!1, n), this._populatePageIdIfExists(n), this._populateReferrerUrlIfExists(!1, n), this._populateABtestIfExists(n), this._populatePersonalizationIfExists(n), a.baseUrl = this.serviceURL;
                                var o = document.getElementsByClassName("cms-dxp-trackable-link");
                                Array.from(o).forEach(function(t) {
                                    t.setAttribute("dxp-click-done", "false"), t.addEventListener("click", function(o) {
                                        return i(this, void 0, void 0, function*() {
                                            if ("true" != t.getAttribute("dxp-click-done")) {
                                                var i = this;
                                                o.stopPropagation(), o.preventDefault(), n.predicate = "Click", n.object = this.href, null != n.object && null != n.object && "" != n.object && (yield a.api.interactionCreate(n, {
                                                    mode: "cors",
                                                    headers: {
                                                        "Content-Type": "application/json-patch+json",
                                                        accept: "text/plain",
                                                        "amais-dxp-tenant-name": e.tenant,
                                                        "amais-dxp-domain": r.configuration.DOMAIN,
                                                        "amais-dxp-api-key": e.apiKey
                                                    }
                                                })), setTimeout(function() {
                                                    t.setAttribute("dxp-click-done", "true"), null == i.onclick && i.click()
                                                }, 1e3)
                                            }
                                        })
                                    })
                                })
                            }))
                        }), this._amaisDxpUserActivity = t => i(this, void 0, void 0, function*() {
                            if (!t.detail.isActive && t.detail.activePeriodTimeInSecs > 3) {
                                const e = new s.Api,
                                    a = {};
                                a.subject = t.detail.subject, a.userAgent = navigator.userAgent, a.language = navigator.language.substring(0, 100), this._populateTitleIfExists(a), this._populateCanonicalUrlIfExists(t.detail.isPreviousPage, a), this._populatePageIdIfExists(a), this._populateReferrerUrlIfExists(t.detail.isPreviousPage, a), this._populateABtestIfExists(a), this._populatePersonalizationIfExists(a), this._populateUserActivity(a, t.detail.activePeriodTimeInSecs), e.baseUrl = this.serviceURL, a.predicate = "Active", a.object = t.detail.isPreviousPage ? localStorage.getItem("amais-dxp-prev-page") : window.location.href, null != a.object && null != a.object && "" != a.object && (yield e.api.interactionCreate(a, {
                                    mode: "cors",
                                    headers: {
                                        "Content-Type": "application/json-patch+json",
                                        accept: "text/plain",
                                        "amais-dxp-tenant-name": this.tenant,
                                        "amais-dxp-domain": r.configuration.DOMAIN,
                                        "amais-dxp-api-key": this.apiKey
                                    }
                                }))
                            }
                        }), this.api = {
                            Client: (t, e, a) => {
                                var i = this;
                                this.apiKey = t, this.tenant = e, this.serviceURL = a, window.addEventListener("beforeunload", function(t) {
                                    var e = localStorage.getItem("amais-dxp-prev-page");
                                    null != e && localStorage.setItem("amais-dxp-pre-prev-page", e), localStorage.setItem("amais-dxp-prev-page", window.location.href);
                                    var a = i._getCanonicalUrlFromHtmlOrLocation();
                                    null != a && localStorage.setItem("amais-dxp-prev-canonical-url", a)
                                })
                            },
                            InitTracker: t => i(this, void 0, void 0, function*() {
                                let e = this._getSubjectId();
                                t.trls && (yield this._trackLinks(e)), t.trua && (document.addEventListener("amais-dxp-user-activity", this._amaisDxpUserActivity), (new o.UserActivity).tracker.Init(5, e)), c.default.addEventListener("change", t => {
                                    t.deleted[0] && "amais-dxp-subject" == t.deleted[0].name && localStorage.setItem("amais-dxp-subject-consent", "false")
                                }), "false" == localStorage.getItem("amais-dxp-subject-consent") && setTimeout(function() {
                                    n.get("amais-dxp-subject") && localStorage.setItem("amais-dxp-subject-consent", "true")
                                }, 5e3)
                            }),
                            interactionCreate: t => i(this, void 0, void 0, function*() {
                                const e = new s.Api;
                                let a = this._getSubjectId();
                                if (t.subject = a, t.object = t.object || window.location.href, t.userAgent = navigator.userAgent, t.language = navigator.language.substring(0, 100), this._populateTitleIfExists(t), this._populateCanonicalUrlIfExists(!1, t), this._populatePageIdIfExists(t), this._populateReferrerUrlIfExists(!1, t), this._populateABtestIfExists(t), this._populatePersonalizationIfExists(t), "Visit" == t.predicate && this._inIframe() && (t.predicate = "Iframe"), e.baseUrl = this.serviceURL, null != t.object && null != t.object && "" != t.object) {
                                    let a = yield e.api.interactionCreate(t, {
                                        mode: "cors",
                                        headers: {
                                            "Content-Type": "application/json-patch+json",
                                            accept: "text/plain",
                                            "amais-dxp-tenant-name": this.tenant,
                                            "amais-dxp-domain": r.configuration.DOMAIN,
                                            "amais-dxp-api-key": this.apiKey
                                        }
                                    });
                                    return JSON.stringify(a)
                                }
                                return JSON.stringify({})
                            }),
                            formInteractionCreate: t => {
                                const e = new s.Api;
                                let a = this._getSubjectId();
                                const n = {};
                                n.subject = a, n.userAgent = navigator.userAgent, n.language = navigator.language.substring(0, 100), this._populateTitleIfExists(n), this._populateCanonicalUrlIfExists(!1, n), this._populatePageIdIfExists(n), this._populateReferrerUrlIfExists(!1, n), this._populateABtestIfExists(n), this._populatePersonalizationIfExists(n), document.querySelectorAll("form").forEach(a => {
                                    a.addEventListener("submit", o => i(this, void 0, void 0, function*() {
                                        var i, o;
                                        n.predicate = "Submit form", n.object = window.location.href, n.subjectMetadata = n.subjectMetadata || {};
                                        var s = new FormData(a),
                                            c = !1;
                                        if (Object.keys(t).forEach(e => {
                                                t[e] && s.get(t[e].name) ? n.subjectMetadata[e] = s.get(t[e].name).toString() : t[e].isRequired && (c = !0)
                                            }), e.baseUrl = this.serviceURL, Object.keys(n.subjectMetadata).length > 0 && !c) {
                                            let t = null;
                                            null != n.object && null != n.object && "" != n.object && (t = yield e.api.interactionCreate(n, {
                                                mode: "cors",
                                                headers: {
                                                    "Content-Type": "application/json-patch+json",
                                                    accept: "text/plain",
                                                    "amais-dxp-tenant-name": this.tenant,
                                                    "amais-dxp-domain": r.configuration.DOMAIN,
                                                    "amais-dxp-api-key": this.apiKey
                                                }
                                            })), n.predicate = "Form Feature Submit", n.object = (null !== (i = window.location.pathname) && void 0 !== i ? i : "") + (null !== (o = window.location.search) && void 0 !== o ? o : ""), n.subjectMetadata = null, null != n.object && null != n.object && "" != n.object && (t = yield e.api.interactionCreate(n, {
                                                mode: "cors",
                                                headers: {
                                                    "Content-Type": "application/json-patch+json",
                                                    accept: "text/plain",
                                                    "amais-dxp-tenant-name": this.tenant,
                                                    "amais-dxp-domain": r.configuration.DOMAIN,
                                                    "amais-dxp-api-key": this.apiKey
                                                }
                                            }))
                                        }
                                    }))
                                })
                            },
                            trackElementEvent: (t, e, a) => i(this, void 0, void 0, function*() {
                                var n = this;
                                let o = this._getSubjectId();
                                window.addEventListener("load", c => i(this, void 0, void 0, function*() {
                                    const c = new s.Api,
                                        l = {};
                                    l.subject = o, l.userAgent = navigator.userAgent, l.language = navigator.language.substring(0, 100), this._populateTitleIfExists(l), this._populateCanonicalUrlIfExists(!1, l), this._populatePageIdIfExists(l), this._populateReferrerUrlIfExists(!1, l), this._populateABtestIfExists(l), this._populatePersonalizationIfExists(l), c.baseUrl = this.serviceURL;
                                    var u = Array.from(document.getElementsByClassName(t));
                                    u.push(document.getElementById(t)), Array.from(u).forEach(function(t) {
                                        t.setAttribute(`dxp-${a.event}-done`, "false"), t.addEventListener(a.event, function(o) {
                                            return i(this, void 0, void 0, function*() {
                                                if ("true" != t.getAttribute(`dxp-${a.event}-done`)) {
                                                    var i = this;
                                                    o.stopPropagation(), o.preventDefault(), l.predicate = e, l.object = t.getAttribute(a.attr), null != l.object && null != l.object && "" != l.object && (yield c.api.interactionCreate(l, {
                                                        mode: "cors",
                                                        headers: {
                                                            "Content-Type": "application/json-patch+json",
                                                            accept: "text/plain",
                                                            "amais-dxp-tenant-name": n.tenant,
                                                            "amais-dxp-domain": r.configuration.DOMAIN,
                                                            "amais-dxp-api-key": n.apiKey
                                                        }
                                                    })), setTimeout(function() {
                                                        t.setAttribute(`dxp-${a.event}-done`, "true"), null == i[`on${a.event}`] && i[a.event]()
                                                    }, 1e3)
                                                }
                                            })
                                        })
                                    })
                                }))
                            })
                        }
                    }
                }
            },
            58(t, e) {
                "use strict";
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.default = cookieStore
            },
            860(t, e) {
                "use strict";
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.UserActivity = void 0, e.UserActivity = class {
                    constructor() {
                        this._updateStorage = () => {
                            var t, e;
                            null == localStorage.getItem("amais-dxp-last-activity") && (localStorage.setItem("amais-dxp-init-activity", (new Date).toISOString()), t = document, e = {
                                isActive: !0,
                                activePeriodTimeInSecs: 0,
                                subject: this.tracker.subject
                            }, t.dispatchEvent && t.dispatchEvent(new CustomEvent("amais-dxp-user-activity", {
                                detail: e
                            }))), localStorage.setItem("amais-dxp-last-activity", (new Date).toISOString())
                        }, this._periodTimeInSecs = () => {
                            const t = localStorage.getItem("amais-dxp-last-activity"),
                                e = localStorage.getItem("amais-dxp-init-activity");
                            if (null != t && null != e) {
                                const a = Math.abs(new Date(t) - new Date(e)),
                                    i = Math.floor(a / 1e3);
                                return Math.floor(i / 60), i
                            }
                            return 0
                        }, this._diffCurrentTimeInSeconds = (t = !1) => {
                            const e = localStorage.getItem("amais-dxp-last-activity"),
                                a = Math.abs(new Date(e) - new Date),
                                i = Math.floor(a / 1e3),
                                n = Math.floor(i / 60);
                            return t && console.log(i + " sec and " + n + " min since last activity"), i
                        }, this._isNeededToSendActivity = (t, e, a, i = !1) => {
                            if (null != localStorage.getItem("amais-dxp-last-activity")) {
                                var n = this._diffCurrentTimeInSeconds();
                                (n >= t || e) && (i && console.log(`No activity from last ${n} seconds...`), o = document, r = {
                                    isPreviousPage: e,
                                    isActive: !1,
                                    activePeriodTimeInSecs: this._periodTimeInSecs(),
                                    subject: a
                                }, o.dispatchEvent && o.dispatchEvent(new CustomEvent("amais-dxp-user-activity", {
                                    detail: r
                                })), localStorage.removeItem("amais-dxp-last-activity"))
                            }
                            var o, r
                        }, this.tracker = {
                            subject: "",
                            Init: (t = 5, e) => {
                                this.tracker.subject = e, this._isNeededToSendActivity(t, !0, e), document.addEventListener("mousemove", this._updateStorage), document.addEventListener("click", this._updateStorage), document.addEventListener("keyup", this._updateStorage), document.addEventListener("keydown", this._updateStorage), setInterval(() => {
                                    this._isNeededToSendActivity(t, !1, e)
                                }, 5e3)
                            }
                        }
                    }
                }
            }
        },
        e = {};

    function a(i) {
        var n = e[i];
        if (void 0 !== n) return n.exports;
        var o = e[i] = {
            exports: {}
        };
        return t[i].call(o.exports, o, o.exports, a), o.exports
    }(() => {
        "use strict";
        const t = a(624);
        setTimeout(function e() {
            if (document && document.body) {
                const e = new t.AmaisDxpApi;
                a = document, i = {
                    service: e
                }, a.dispatchEvent && a.dispatchEvent(new CustomEvent("amais-insight-sdk-ready", {
                    detail: i
                }))
            } else setTimeout(e, 1e3);
            var a, i
        }, 0)
    })()
})();