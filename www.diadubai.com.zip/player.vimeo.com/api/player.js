/*! @vimeo/player v2.30.4 | (c) 2026 Vimeo | MIT License | https://github.com/vimeo/player.js */
((e, t) => {
    "object" == typeof exports && "undefined" != typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define(t) : ((e = "undefined" != typeof globalThis ? globalThis : e || self).Vimeo = e.Vimeo || {}, e.Vimeo.Player = t())
})(this, function() {
    var e = "undefined" != typeof global && "[object global]" === {}.toString.call(global),
        t = "undefined" != typeof Bun,
        r = "undefined" != typeof Deno,
        n = "function" == typeof WebSocketPair && void 0 !== caches ? .default,
        e = e || t || r || n;

    function i(e, t) {
        return 0 === e.indexOf(t.toLowerCase()) ? e : "" + t.toLowerCase() + e.substr(0, 1).toUpperCase() + e.substr(1)
    }

    function l(e) {
        return /^(https?:)?\/\/((((player|www)\.)?vimeo\.com)|((player\.)?[a-zA-Z0-9-]+\.(videoji\.(hk|cn)|vimeo\.work)))(?=$|\/)/.test(e)
    }

    function o(e) {
        return /^https:\/\/player\.((vimeo\.com)|([a-zA-Z0-9-]+\.(videoji\.(hk|cn)|vimeo\.work)))\/video\/\d+/.test(e)
    }

    function a(e) {
        var t, e = 0 < arguments.length && void 0 !== e ? e : {},
            r = e.id,
            e = r || e.url;
        if (!e) throw new Error("An id or url must be passed, either in an options object or as a data-vimeo-id or data-vimeo-url attribute.");
        if (t = e, !isNaN(parseFloat(t)) && isFinite(t) && Math.floor(t) == t) return "https://vimeo.com/" + e;
        if (l(e)) return e.replace("http:", "https:");
        if (r) throw new TypeError(`“${r}” is not a valid video id.`);
        throw new TypeError(`“${e}” is not a vimeo.com url.`)
    }

    function s(t, e, r) {
        let n = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : "addEventListener",
            i = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : "removeEventListener",
            o = "string" == typeof e ? [e] : e;
        return o.forEach(e => {
            t[n](e, r)
        }), {
            cancel: () => o.forEach(e => t[i](e, r))
        }
    }

    function u(t, e) {
        e = 1 < arguments.length && void 0 !== e ? e : document;
        if (t && e && "function" == typeof e.querySelectorAll) {
            var r = e.querySelectorAll("iframe");
            for (let e = 0; e < r.length; e++)
                if (r[e] && r[e].contentWindow === t) return r[e]
        }
        return null
    }
    t = void 0 !== Array.prototype.indexOf, r = "undefined" != typeof window && void 0 !== window.postMessage;
    if (!(e || t && r)) throw new Error("Sorry, the Vimeo Player API is not available in this browser.");
    var c, d, h, f = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};

    function m() {
        if (void 0 === this) throw new TypeError("Constructor WeakMap requires 'new'");
        if (h(this, "_id", "_WeakMap_" + g() + "." + g()), 0 < arguments.length) throw new TypeError("WeakMap iterable is not supported")
    }

    function p(e, t) {
        if (!w(e) || !c.call(e, "_id")) throw new TypeError(t + " method called on incompatible receiver " + typeof e)
    }

    function g() {
        return Math.random().toString().substring(2)
    }

    function w(e) {
        return Object(e) === e
    }(n = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : "undefined" != typeof window ? window : f).WeakMap || (c = Object.prototype.hasOwnProperty, d = Object.defineProperty && (() => {
        try {
            return 1 === Object.defineProperty({}, "x", {
                value: 1
            }).x
        } catch (e) {}
    })(), n.WeakMap = ((h = function(e, t, r) {
        d ? Object.defineProperty(e, t, {
            configurable: !0,
            writable: !0,
            value: r
        }) : e[t] = r
    })(m.prototype, "delete", function(e) {
        var t;
        return p(this, "delete"), !!w(e) && !(!(t = e[this._id]) || t[0] !== e || (delete e[this._id], 0))
    }), h(m.prototype, "get", function(e) {
        var t;
        return p(this, "get"), w(e) && (t = e[this._id]) && t[0] === e ? t[1] : void 0
    }), h(m.prototype, "has", function(e) {
        var t;
        return p(this, "has"), !!w(e) && !(!(t = e[this._id]) || t[0] !== e)
    }), h(m.prototype, "set", function(e, t) {
        var r;
        if (p(this, "set"), w(e)) return (r = e[this._id]) && r[0] === e ? r[1] = t : h(e, this._id, [e, t]), this;
        throw new TypeError("Invalid value used as weak map key")
    }), h(m, "_polyfill", !0), m));
    (function(e) {
        var t, r, n;
        n = function() {
            var t, r, n, i, o, e = Object.prototype.toString,
                a = "undefined" != typeof setImmediate ? function(e) {
                    return setImmediate(e)
                } : setTimeout;
            try {
                Object.defineProperty({}, "x", {}), t = function(e, t, r, n) {
                    return Object.defineProperty(e, t, {
                        value: r,
                        writable: !0,
                        configurable: !1 !== n
                    })
                }
            } catch (e) {
                t = function(e, t, r) {
                    return e[t] = r, e
                }
            }

            function s(e, t) {
                this.fn = e, this.self = t, this.next = void 0
            }

            function l(e, t) {
                w.add(e, t), r = r || a(w.drain)
            }

            function u(e) {
                var t, r = typeof e;
                return "function" == typeof(t = null == e || "object" != r && "function" != r ? t : e.then) && t
            }

            function c() {
                for (var e = 0; e < this.chain.length; e++) {
                    r = t = o = i = n = void 0;
                    var t, r, n = this,
                        i = 1 === this.state ? this.chain[e].success : this.chain[e].failure,
                        o = this.chain[e];
                    try {
                        !1 === i ? o.reject(n.msg) : (t = !0 === i ? n.msg : i.call(void 0, n.msg)) === o.promise ? o.reject(TypeError("Promise-chain cycle")) : (r = u(t)) ? r.call(t, o.resolve, o.reject) : o.resolve(t)
                    } catch (e) {
                        o.reject(e)
                    }
                }
                this.chain.length = 0
            }

            function d(e) {
                var r, n = this;
                if (!n.triggered) {
                    n.triggered = !0, n.def && (n = n.def);
                    try {
                        (r = u(e)) ? l(function() {
                            var t = new m(n);
                            try {
                                r.call(e, function() {
                                    d.apply(t, arguments)
                                }, function() {
                                    h.apply(t, arguments)
                                })
                            } catch (e) {
                                h.call(t, e)
                            }
                        }): (n.msg = e, n.state = 1, 0 < n.chain.length && l(c, n))
                    } catch (e) {
                        h.call(new m(n), e)
                    }
                }
            }

            function h(e) {
                var t = this;
                t.triggered || (t.triggered = !0, (t = t.def ? t.def : t).msg = e, t.state = 2, 0 < t.chain.length && l(c, t))
            }

            function f(e, r, n, i) {
                for (var t = 0; t < r.length; t++)(t => {
                    e.resolve(r[t]).then(function(e) {
                        n(t, e)
                    }, i)
                })(t)
            }

            function m(e) {
                this.def = e, this.triggered = !1
            }

            function p(e) {
                this.promise = e, this.state = 0, this.triggered = !1, this.chain = [], this.msg = void 0
            }

            function g(e) {
                if ("function" != typeof e) throw TypeError("Not a function");
                if (0 !== this.__NPO__) throw TypeError("Not a promise");
                this.__NPO__ = 1;
                var n = new p(this);
                this.then = function(e, t) {
                    var r = {
                        success: "function" != typeof e || e,
                        failure: "function" == typeof t && t
                    };
                    return r.promise = new this.constructor(function(e, t) {
                        if ("function" != typeof e || "function" != typeof t) throw TypeError("Not a function");
                        r.resolve = e, r.reject = t
                    }), n.chain.push(r), 0 !== n.state && l(c, n), r.promise
                }, this.catch = function(e) {
                    return this.then(void 0, e)
                };
                try {
                    e.call(void 0, function(e) {
                        d.call(n, e)
                    }, function(e) {
                        h.call(n, e)
                    })
                } catch (e) {
                    h.call(n, e)
                }
            }
            var w = {
                    add: function(e, t) {
                        o = new s(e, t), i ? i.next = o : n = o, i = o
                    },
                    drain: function() {
                        var e = n;
                        for (n = i = r = void 0; e;) e.fn.call(e.self), e = e.next
                    }
                },
                y = t({}, "constructor", g, !1);
            return t(g.prototype = y, "__NPO__", 0, !1), t(g, "resolve", function(r) {
                return r && "object" == typeof r && 1 === r.__NPO__ ? r : new this(function(e, t) {
                    if ("function" != typeof e || "function" != typeof t) throw TypeError("Not a function");
                    e(r)
                })
            }), t(g, "reject", function(r) {
                return new this(function(e, t) {
                    if ("function" != typeof e || "function" != typeof t) throw TypeError("Not a function");
                    t(r)
                })
            }), t(g, "all", function(t) {
                var a = this;
                return "[object Array]" != e.call(t) ? a.reject(TypeError("Not an array")) : 0 === t.length ? a.resolve([]) : new a(function(r, e) {
                    if ("function" != typeof r || "function" != typeof e) throw TypeError("Not a function");
                    var n = t.length,
                        i = Array(n),
                        o = 0;
                    f(a, t, function(e, t) {
                        i[e] = t, ++o === n && r(i)
                    }, e)
                })
            }), t(g, "race", function(t) {
                var n = this;
                return "[object Array]" != e.call(t) ? n.reject(TypeError("Not an array")) : new n(function(r, e) {
                    if ("function" != typeof r || "function" != typeof e) throw TypeError("Not a function");
                    f(n, t, function(e, t) {
                        r(t)
                    }, e)
                })
            }), g
        }, (r = f)[t = "Promise"] = r[t] || n(), e.exports && (e.exports = r[t])
    })(t = {
        exports: {}
    });
    var y = t.exports;
    let v = new WeakMap;

    function b(e, t, r) {
        var n = v.get(e.element) || {};
        t in n || (n[t] = []), n[t].push(r), v.set(e.element, n)
    }

    function E(e, t) {
        return (v.get(e.element) || {})[t] || []
    }

    function T(e, t, r) {
        var n = v.get(e.element) || {};
        return !n[t] || (r ? (-1 !== (r = n[t].indexOf(r)) && n[t].splice(r, 1), v.set(e.element, n), n[t] && 0 === n[t].length) : (n[t] = [], v.set(e.element, n), !0))
    }

    function k(e) {
        if ("string" == typeof e) try {
            e = JSON.parse(e)
        } catch (e) {
            return console.warn(e), {}
        }
        return e
    }

    function P(t, r, n) {
        if (t.element.contentWindow && t.element.contentWindow.postMessage) {
            let e = {
                method: r
            };
            void 0 !== n && (e.value = n);
            r = parseFloat(navigator.userAgent.toLowerCase().replace(/^.*msie (\d+).*$/, "$1"));
            8 <= r && r < 10 && (e = JSON.stringify(e)), t.element.contentWindow.postMessage(e, t.origin)
        }
    }

    function _(r, n) {
        n = k(n);
        let e = [],
            t;
        var i, o, a;
        n.event ? ("error" === n.event && E(r, n.data.method).forEach(e => {
            var t = new Error(n.data.message);
            t.name = n.data.name, e.reject(t), T(r, n.data.method, e)
        }), e = E(r, "event:" + n.event), t = n.data) : n.method && (i = r, o = n.method, o = !((a = E(i, o)).length < 1) && (T(i, o, i = a.shift()), i)) && (e.push(o), t = n.value), e.forEach(e => {
            try {
                "function" == typeof e ? e.call(r, t) : e.resolve(t)
            } catch (e) {}
        })
    }
    let A = ["airplay", "audio_tracks", "audiotrack", "autopause", "autoplay", "background", "byline", "cc", "chapter_id", "chapters", "chromecast", "color", "colors", "controls", "disable_context_menu", "dnt", "end_time", "fullscreen", "height", "id", "initial_quality", "interactive_params", "keyboard", "loop", "maxheight", "max_quality", "maxwidth", "min_quality", "muted", "play_button_position", "playsinline", "portrait", "preload", "progress_bar", "quality", "quality_selector", "responsive", "skipping_forward", "speed", "start_time", "texttrack", "thumbnail_id", "title", "transcript", "transparent", "unmute_button", "url", "vimeo_logo", "volume", "watch_full_video", "width"];

    function M(n, e) {
        e = 1 < arguments.length && void 0 !== e ? e : {};
        return A.reduce((e, t) => {
            var r = n.getAttribute("data-vimeo-" + t);
            return !r && "" !== r || (e[t] = "" === r ? 1 : r), e
        }, e)
    }

    function j(e, t) {
        var r, e = e.html;
        if (t) return null === t.getAttribute("data-vimeo-initialized") && ((r = document.createElement("div")).innerHTML = e, t.appendChild(r.firstChild), t.setAttribute("data-vimeo-initialized", "true")), t.querySelector("iframe");
        throw new TypeError("An element must be provided")
    }

    function C(o, e, t) {
        let a = 1 < arguments.length && void 0 !== e ? e : {},
            s = 2 < arguments.length ? t : void 0;
        return new Promise((t, r) => {
            if (!l(o)) throw new TypeError(`“${o}” is not a vimeo.com url.`);
            let e = `https://${(e=>{var t,r=((e=(e||"").match(/^(?:https?:)?(?:\/\/)?([^/?]+)/))&&e[1]||"").replace("player.","");for(t of[".videoji.hk",".vimeo.work",".videoji.cn"])if(r.endsWith(t))return r;return"vimeo.com"})(o)}/api/oembed.json?url=` + encodeURIComponent(o);
            for (var n in a) a.hasOwnProperty(n) && (e += `&${n}=` + encodeURIComponent(a[n]));
            let i = new("XDomainRequest" in window ? XDomainRequest : XMLHttpRequest);
            i.open("GET", e, !0), i.onload = function() {
                if (404 === i.status) r(new Error(`“${o}” was not found.`));
                else if (403 === i.status) r(new Error(`“${o}” is not embeddable.`));
                else try {
                    var e = JSON.parse(i.responseText);
                    403 === e.domain_status_code ? (j(e, s), r(new Error(`“${o}” is not embeddable.`))) : t(e)
                } catch (e) {
                    r(e)
                }
            }, i.onerror = function() {
                var e = i.status ? ` (${i.status})` : "";
                r(new Error(`There was an error fetching the embed code from Vimeo${e}.`))
            }, i.send()
        })
    }

    function x() {
        let o = (() => {
                var e, t = [
                    ["requestFullscreen", "exitFullscreen", "fullscreenElement", "fullscreenEnabled", "fullscreenchange", "fullscreenerror"],
                    ["webkitRequestFullscreen", "webkitExitFullscreen", "webkitFullscreenElement", "webkitFullscreenEnabled", "webkitfullscreenchange", "webkitfullscreenerror"],
                    ["webkitRequestFullScreen", "webkitCancelFullScreen", "webkitCurrentFullScreenElement", "webkitCancelFullScreen", "webkitfullscreenchange", "webkitfullscreenerror"],
                    ["mozRequestFullScreen", "mozCancelFullScreen", "mozFullScreenElement", "mozFullScreenEnabled", "mozfullscreenchange", "mozfullscreenerror"],
                    ["msRequestFullscreen", "msExitFullscreen", "msFullscreenElement", "msFullscreenEnabled", "MSFullscreenChange", "MSFullscreenError"]
                ];
                let r = 0;
                for (var n = t.length, i = {}; r < n; r++)
                    if ((e = t[r]) && e[1] in document) {
                        for (r = 0; r < e.length; r++) i[t[0][r]] = e[r];
                        return i
                    }
                return !1
            })(),
            r = {
                fullscreenchange: o.fullscreenchange,
                fullscreenerror: o.fullscreenerror
            },
            a = {
                request(i) {
                    return new Promise((e, t) => {
                        let r = function() {
                            a.off("fullscreenchange", r), e()
                        };
                        a.on("fullscreenchange", r);
                        var n = (i = i || document.documentElement)[o.requestFullscreen]();
                        n instanceof Promise && n.then(r).catch(t)
                    })
                },
                exit() {
                    return new Promise((t, r) => {
                        if (a.isFullscreen) {
                            let e = function() {
                                a.off("fullscreenchange", e), t()
                            };
                            a.on("fullscreenchange", e);
                            var n = document[o.exitFullscreen]();
                            n instanceof Promise && n.then(e).catch(r)
                        } else t()
                    })
                },
                on(e, t) {
                    e = r[e];
                    e && document.addEventListener(e, t)
                },
                off(e, t) {
                    e = r[e];
                    e && document.removeEventListener(e, t)
                }
            };
        return Object.defineProperties(a, {
            isFullscreen: {
                get() {
                    return Boolean(document[o.fullscreenElement])
                }
            },
            element: {
                enumerable: !0,
                get() {
                    return document[o.fullscreenElement]
                }
            },
            isEnabled: {
                enumerable: !0,
                get() {
                    return Boolean(document[o.fullscreenEnabled])
                }
            }
        }), a
    }
    let F = {
        role: "viewer",
        autoPlayMuted: !0,
        allowedDrift: .3,
        maxAllowedDrift: 1,
        minCheckInterval: .1,
        maxRateAdjustment: .2,
        maxTimeToCatchUp: 1
    };
    class q extends EventTarget {
        logger;
        constructor(e, t) {
            var r = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : {},
                n = 3 < arguments.length ? arguments[3] : void 0;
            super(), this.logger = n, this.init(t, e, { ...F,
                ...r
            })
        }
        disconnect() {
            this.dispatchEvent(new Event("disconnect"))
        }
        async init(r, n, i) {
            if (await this.waitForTOReadyState(r, "open"), "viewer" === i.role) {
                await this.updatePlayer(r, n, i);
                let e = s(r, "change", () => this.updatePlayer(r, n, i)),
                    t = this.maintainPlaybackPosition(r, n, i);
                this.addEventListener("disconnect", () => {
                    t.cancel(), e.cancel()
                })
            } else {
                await this.updateTimingObject(r, n);
                let e = s(n, ["seeked", "play", "pause", "ratechange"], () => this.updateTimingObject(r, n), "on", "off");
                this.addEventListener("disconnect", () => e.cancel())
            }
        }
        async updateTimingObject(e, t) {
            var [t, r, n] = await Promise.all([t.getCurrentTime(), t.getPaused(), t.getPlaybackRate()]);
            e.update({
                position: t,
                velocity: r ? 0 : n
            })
        }
        async updatePlayer(e, t, r) {
            var {
                position: n,
                velocity: i
            } = e.query();
            "number" == typeof n && t.setCurrentTime(n), "number" == typeof i && (0 === i ? !1 === await t.getPaused() && t.pause() : 0 < i && (!0 === await t.getPaused() && (await t.play().catch(async e => {
                "NotAllowedError" === e.name && r.autoPlayMuted && (await t.setMuted(!0), await t.play().catch(e => console.error("Couldn't play the video from TimingSrcConnector. Error:", e)))
            }), this.updatePlayer(e, t, r)), await t.getPlaybackRate() !== i) && t.setPlaybackRate(i))
        }
        maintainPlaybackPosition(n, i, e) {
            let {
                allowedDrift: o,
                maxAllowedDrift: a,
                minCheckInterval: t,
                maxRateAdjustment: s,
                maxTimeToCatchUp: l
            } = e;
            e = 1e3 * Math.min(l, Math.max(t, a));
            let r = async () => {
                    var e, t, r;
                    0 !== n.query().velocity && !0 !== await i.getPaused() && (e = n.query().position - await i.getCurrentTime(), t = Math.abs(e), this.log("Drift: " + e), t > a ? (await this.adjustSpeed(i, 0), i.setCurrentTime(n.query().position), this.log("Resync by currentTime")) : t > o && (t = t / l, r = s, await this.adjustSpeed(i, (t < r ? (r - t) / 2 : r) * Math.sign(e)), this.log("Resync by playbackRate")))
                },
                u = setInterval(() => r(), e);
            return {
                cancel: () => clearInterval(u)
            }
        }
        log(e) {
            this.logger ? .("TimingSrcConnector: " + e)
        }
        speedAdjustment = 0;
        adjustSpeed = async (e, t) => {
            var r;
            this.speedAdjustment !== t && (r = await e.getPlaybackRate() - this.speedAdjustment + t, this.log("New playbackRate:  " + r), await e.setPlaybackRate(r), this.speedAdjustment = t)
        };
        waitForTOReadyState(r, n) {
            return new Promise(e => {
                let t = () => {
                    r.readyState === n ? e() : r.addEventListener("readystatechange", t, {
                        once: !0
                    })
                };
                t()
            })
        }
    }
    let N = new WeakMap,
        R = new WeakMap,
        S = {};
    class Player {
        constructor(o) {
            let t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {};
            if (window.jQuery && o instanceof jQuery && (1 < o.length && window.console && console.warn && console.warn("A jQuery object with multiple elements was passed, using the first element."), o = o[0]), "undefined" != typeof document && "string" == typeof o && (o = document.getElementById(o)), e = o, !Boolean(e && 1 === e.nodeType && "nodeName" in e && e.ownerDocument && e.ownerDocument.defaultView)) throw new TypeError("You must pass either a valid element or a valid id.");
            if ("IFRAME" === (o = "IFRAME" !== o.nodeName && (e = o.querySelector("iframe")) ? e : o).nodeName && !l(o.getAttribute("src") || "")) throw new Error("The player element passed isn’t a Vimeo embed.");
            if (N.has(o)) return N.get(o);
            this._window = o.ownerDocument.defaultView, this.element = o, this.origin = "*";
            var e = new y((n, i) => {
                var e;
                this._onMessage = e => {
                    var t, r;
                    l(e.origin) && this.element.contentWindow === e.source && ("*" === this.origin && (this.origin = e.origin), (e = k(e.data)) && "error" === e.event && e.data && "ready" === e.data.method ? ((t = new Error(e.data.message)).name = e.data.name, i(t)) : (t = e && "ready" === e.event, r = e && "ping" === e.method, t || r ? (this.element.setAttribute("data-ready", "true"), n()) : _(this, e)))
                }, this._window.addEventListener("message", this._onMessage), "IFRAME" !== this.element.nodeName && C(a(e = M(o, t)), e, o).then(e => {
                    var t, r, n = j(e, o);
                    return this.element = n, this._originalElement = o, t = o, n = n, r = v.get(t), v.set(n, r), v.delete(t), N.set(this.element, this), e
                }).catch(i)
            });
            if (R.set(this, e), N.set(this.element, this), "IFRAME" === this.element.nodeName && P(this, "ping"), S.isEnabled) {
                let e = () => S.exit();
                this.fullscreenchangeHandler = () => {
                    (S.isFullscreen ? b : T)(this, "event:exitFullscreen", e), this.ready().then(() => {
                        P(this, "fullscreenchange", S.isFullscreen)
                    })
                }, S.on("fullscreenchange", this.fullscreenchangeHandler)
            }
            return this
        }
        static isVimeoUrl(e) {
            return l(e)
        }
        callMethod(r) {
            for (var e = arguments.length, n = new Array(1 < e ? e - 1 : 0), t = 1; t < e; t++) n[t - 1] = arguments[t];
            if (null == r) throw new TypeError("You must pass a method name.");
            return new y((e, t) => this.ready().then(() => {
                b(this, r, {
                    resolve: e,
                    reject: t
                }), 0 === n.length ? n = {} : 1 === n.length && (n = n[0]), P(this, r, n)
            }).catch(t))
        }
        get(r) {
            return new y((e, t) => (r = i(r, "get"), this.ready().then(() => {
                b(this, r, {
                    resolve: e,
                    reject: t
                }), P(this, r)
            }).catch(t)))
        }
        set(r, n) {
            return new y((e, t) => {
                if (r = i(r, "set"), null == n) throw new TypeError("There must be a value to set.");
                return this.ready().then(() => {
                    b(this, r, {
                        resolve: e,
                        reject: t
                    }), P(this, r, n)
                }).catch(t)
            })
        }
        on(e, t) {
            if (!e) throw new TypeError("You must pass an event name.");
            if (!t) throw new TypeError("You must pass a callback function.");
            if ("function" != typeof t) throw new TypeError("The callback must be a function.");
            0 === E(this, "event:" + e).length && this.callMethod("addEventListener", e).catch(() => {}), b(this, "event:" + e, t)
        }
        off(e, t) {
            if (!e) throw new TypeError("You must pass an event name.");
            if (t && "function" != typeof t) throw new TypeError("The callback must be a function.");
            T(this, "event:" + e, t) && this.callMethod("removeEventListener", e).catch(e => {})
        }
        loadVideo(e) {
            return this.callMethod("loadVideo", e)
        }
        ready() {
            var e = R.get(this) || new y((e, t) => {
                t(new Error("Unknown player. Probably unloaded."))
            });
            return y.resolve(e)
        }
        addCuePoint(e) {
            return this.callMethod("addCuePoint", {
                time: e,
                data: 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}
            })
        }
        removeCuePoint(e) {
            return this.callMethod("removeCuePoint", e)
        }
        enableTextTrack(e) {
            if (e) return this.callMethod("enableTextTrack", {
                language: e,
                kind: 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : null,
                showing: !(2 < arguments.length && void 0 !== arguments[2]) || arguments[2]
            });
            throw new TypeError("You must pass a language.")
        }
        disableTextTrack() {
            return this.callMethod("disableTextTrack")
        }
        selectAudioTrack(e, t) {
            if (e) return this.callMethod("selectAudioTrack", {
                language: e,
                kind: t
            });
            throw new TypeError("You must pass a language.")
        }
        selectDefaultAudioTrack() {
            return this.callMethod("selectDefaultAudioTrack")
        }
        pause() {
            return this.callMethod("pause")
        }
        play() {
            return this.callMethod("play")
        }
        requestFullscreen() {
            return S.isEnabled ? S.request(this.element) : this.callMethod("requestFullscreen")
        }
        exitFullscreen() {
            return S.isEnabled ? S.exit() : this.callMethod("exitFullscreen")
        }
        getFullscreen() {
            return S.isEnabled ? y.resolve(S.isFullscreen) : this.get("fullscreen")
        }
        requestPictureInPicture() {
            return this.callMethod("requestPictureInPicture")
        }
        exitPictureInPicture() {
            return this.callMethod("exitPictureInPicture")
        }
        getPictureInPicture() {
            return this.get("pictureInPicture")
        }
        remotePlaybackPrompt() {
            return this.callMethod("remotePlaybackPrompt")
        }
        unload() {
            return this.callMethod("unload")
        }
        destroy() {
            return new y(e => {
                var t;
                R.delete(this), N.delete(this.element), this._originalElement && (N.delete(this._originalElement), this._originalElement.removeAttribute("data-vimeo-initialized")), this.element && "IFRAME" === this.element.nodeName && this.element.parentNode && (this.element.parentNode.parentNode && this._originalElement && this._originalElement !== this.element.parentNode ? this.element.parentNode.parentNode.removeChild(this.element.parentNode) : this.element.parentNode.removeChild(this.element)), this.element && "DIV" === this.element.nodeName && this.element.parentNode && (this.element.removeAttribute("data-vimeo-initialized"), t = this.element.querySelector("iframe")) && t.parentNode && (t.parentNode.parentNode && this._originalElement && this._originalElement !== t.parentNode ? t.parentNode.parentNode.removeChild(t.parentNode) : t.parentNode.removeChild(t)), this._window.removeEventListener("message", this._onMessage), S.isEnabled && S.off("fullscreenchange", this.fullscreenchangeHandler), e()
            })
        }
        getAutopause() {
            return this.get("autopause")
        }
        setAutopause(e) {
            return this.set("autopause", e)
        }
        getBuffered() {
            return this.get("buffered")
        }
        getCameraProps() {
            return this.get("cameraProps")
        }
        setCameraProps(e) {
            return this.set("cameraProps", e)
        }
        getChapters() {
            return this.get("chapters")
        }
        getCurrentChapter() {
            return this.get("currentChapter")
        }
        getColor() {
            return this.get("color")
        }
        getColors() {
            return y.all([this.get("colorOne"), this.get("colorTwo"), this.get("colorThree"), this.get("colorFour")])
        }
        setColor(e) {
            return this.set("color", e)
        }
        setColors(e) {
            var t;
            return Array.isArray(e) ? (t = new y(e => e(null)), e = [e[0] ? this.set("colorOne", e[0]) : t, e[1] ? this.set("colorTwo", e[1]) : t, e[2] ? this.set("colorThree", e[2]) : t, e[3] ? this.set("colorFour", e[3]) : t], y.all(e)) : new y((e, t) => t(new TypeError("Argument must be an array.")))
        }
        getCuePoints() {
            return this.get("cuePoints")
        }
        getCurrentTime() {
            return this.get("currentTime")
        }
        setCurrentTime(e) {
            return this.set("currentTime", e)
        }
        getDuration() {
            return this.get("duration")
        }
        getEnded() {
            return this.get("ended")
        }
        getLoop() {
            return this.get("loop")
        }
        setLoop(e) {
            return this.set("loop", e)
        }
        setMuted(e) {
            return this.set("muted", e)
        }
        getMuted() {
            return this.get("muted")
        }
        getPaused() {
            return this.get("paused")
        }
        getPlaybackRate() {
            return this.get("playbackRate")
        }
        setPlaybackRate(e) {
            return this.set("playbackRate", e)
        }
        getPlayed() {
            return this.get("played")
        }
        getQualities() {
            return this.get("qualities")
        }
        getQuality() {
            return this.get("quality")
        }
        setQuality(e) {
            return this.set("quality", e)
        }
        getRemotePlaybackAvailability() {
            return this.get("remotePlaybackAvailability")
        }
        getRemotePlaybackState() {
            return this.get("remotePlaybackState")
        }
        getSeekable() {
            return this.get("seekable")
        }
        getSeeking() {
            return this.get("seeking")
        }
        getTextTracks() {
            return this.get("textTracks")
        }
        getAudioTracks() {
            return this.get("audioTracks")
        }
        getEnabledAudioTrack() {
            return this.get("enabledAudioTrack")
        }
        getDefaultAudioTrack() {
            return this.get("defaultAudioTrack")
        }
        getVideoEmbedCode() {
            return this.get("videoEmbedCode")
        }
        getVideoId() {
            return this.get("videoId")
        }
        getVideoTitle() {
            return this.get("videoTitle")
        }
        getVideoWidth() {
            return this.get("videoWidth")
        }
        getVideoHeight() {
            return this.get("videoHeight")
        }
        getVideoUrl() {
            return this.get("videoUrl")
        }
        getVolume() {
            return this.get("volume")
        }
        setVolume(e) {
            return this.set("volume", e)
        }
        async setTimingSrc(e, t) {
            if (!e) throw new TypeError("A Timing Object must be provided.");
            await this.ready();
            e = new q(this, e, t);
            return P(this, "notifyTimingObjectConnect"), e.addEventListener("disconnect", () => P(this, "notifyTimingObjectDisconnect")), e
        }
    }
    return e || (S = x(), function(e) {
        e = 0 < arguments.length && void 0 !== e ? e : document, e = [].slice.call(e.querySelectorAll("[data-vimeo-id], [data-vimeo-url]"));
        let r = e => {
            "console" in window && console.error && console.error("There was an error creating an embed: " + e)
        };
        e.forEach(t => {
            try {
                var e;
                null === t.getAttribute("data-vimeo-defer") && C(a(e = M(t)), e, t).then(e => j(e, t)).catch(r)
            } catch (e) {
                r(e)
            }
        })
    }(), function(e) {
        let r = 0 < arguments.length && void 0 !== e ? e : document;
        window.VimeoPlayerResizeEmbeds_ || (window.VimeoPlayerResizeEmbeds_ = !0, window.addEventListener("message", e => {
            var t;
            l(e.origin) && e.data && "spacechange" === e.data.event && (t = e.source ? u(e.source, r) : null) && (t.parentElement.style.paddingBottom = e.data.data[0].bottom + "px")
        }))
    }(), function(e) {
        let r = 0 < arguments.length && void 0 !== e ? e : document;
        window.VimeoSeoMetadataAppended || (window.VimeoSeoMetadataAppended = !0, window.addEventListener("message", e => {
            var t;
            l(e.origin) && (t = k(e.data)) && "ready" === t.event && (t = e.source ? u(e.source, r) : null) && o(t.src) && new Player(t).callMethod("appendVideoMetadata", window.location.href)
        }))
    }(), function(e) {
        let t = 0 < arguments.length && void 0 !== e ? e : document;
        if (!window.VimeoCheckedUrlTimeParam) {
            window.VimeoCheckedUrlTimeParam = !0;
            let n = e => {
                "console" in window && console.error && console.error("There was an error getting video Id: " + e)
            };
            window.addEventListener("message", e => {
                if (l(e.origin)) {
                    var r = k(e.data);
                    if (r && "ready" === r.event) {
                        r = e.source ? u(e.source, t) : null;
                        if (r && o(r.src)) {
                            let t = new Player(r);
                            t.getVideoId().then(e => {
                                var e = new RegExp(`[?&]vimeo_t_${e}=([^&#]*)`).exec(window.location.href);
                                e && e[1] && (e = decodeURI(e[1]), t.setCurrentTime(e))
                            }).catch(n)
                        }
                    }
                }
            })
        }
    }(), window.VimeoDRMEmbedsUpdated) || (window.VimeoDRMEmbedsUpdated = !0, window.addEventListener("message", e => {
        var t;
        l(e.origin) && (t = k(e.data)) && "drminitfailed" === t.event && (t = e.source ? u(e.source) : null) && !(e = t.getAttribute("allow") || "").includes("encrypted-media") && (t.setAttribute("allow", e + "; encrypted-media"), (e = new URL(t.getAttribute("src"))).searchParams.set("forcereload", "drm"), t.setAttribute("src", e.toString()))
    })), Player
});